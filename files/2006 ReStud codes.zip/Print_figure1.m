clear all;
% Print figure 1
load([pwd,'\Results\yx.mat']);

% Print figure
tsplot(y,cstr);
legend('off');
xlim([datenum('7-1-1947'),datenum('12-1-2002')]);

 print('-depsc','-tiff','-r600',[pwd,'\Results\Figures and tables\Figure1.eps']);
 pause(5);
 close all;