function yfor=forecast_ols(y,X,I)

% PURPOSE: computes one step ahead forecasts using OLS method


nl=cols(X)-1;  %number of lags (X includes the constant)
T=rows(y);
res=gibbs_norm(y,X,I);
yfor=zeros(I,T+1); %save the recursive OLS forecasts
I=size(res.beta,1);
for j=1:I
    for i=1:T
        yfor(j,i+1)=X(i,:)*res.beta(j,:)';
    end
end
yfor=trimr(yfor',nl,0)';