function [yf,bf]=tvp2_recforc(y,X,tb,tbf,freq,tend,h)

% PURPOSE: computes recursive forecasts for time varying parameter model
% (with Zellner g-prior) when the forecasting horizon is h. tb is the beginning of the sample, 
% tbf is the beginning of the forecasting sample, and te is the end of the
% sample

[n,k]=size(X);
bar=waitbar(0,['TVP recursive forecasts, h=' num2str(h)] );
i=1;
for t=tbf:freq:tend
    yr=y(tb:t,:); Xr=X(tb:t,:);
    % initial values
    priorb0 = zeros(k,1); % diffuse prior for b
    priorv0 = eye(k)*50;  % diffuse prior for sigb
    % do Zellner g-prior variant of the model
    parm = [0.5 % sige
            1.0]; % delta
    info.delta = 1.0; % this turns on Zellner g-prior variant
    info.start = 1;
    info.b0 = priorb0; % match prior used above
    info.v0 = priorv0;
    info.prt = 0; % turn on printing intermediate optimization results
    result = tvp(yr,Xr,parm,info); %do the tvp estimation
    %the general formula with dynamic on the coeffs
    bf(i,:)=result.beta(end,:);
    beta=repmat(bf(i,:),h,1);
    a=trimr(beta(:,1),0,1);
    b=trimr(beta(:,2),1,0);
    term1=beta(end,1) + sum(a.*b);
    term2=prod(beta(:,2))*yr(end);
    yf(i,:)=term1+term2;
    i=i+1;
    waitbar(i/((tend-tbf+1)/freq),bar);
end
close(bar);
    


    

