function [yf,bf]=ols_recforc(y,X,tb,tbf,tend,h,incr)

% PURPOSE: computes recursice forecasts for the recursive ols model
% when the forecasting horizon is h. tb is the beginning of the sample, tbf
% is the beginning of the forecasting sample, and te is the end of the
% sample

[n,k]=size(X);
bar=waitbar(0,['Recursive OLS forecasts, h=' num2str(h)] );
i=1;
for t=tbf:incr:tend
    yr=y(tb:t,:); Xr=X(tb:t,:);
    % initial values
    res=ols(yr,Xr);
    term1=res.beta(1) * (1-(res.beta(2)^h)) / (1-res.beta(2));
    term2=(res.beta(2)^h)*yr(end);
    yf(i,:)=term1+term2;
    bf(i,:)=res.beta;
    i=i+1;
    waitbar(i/(tend-tbf+1),bar);
end
close(bar);
