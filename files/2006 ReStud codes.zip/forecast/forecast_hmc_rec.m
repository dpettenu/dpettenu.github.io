function [ypd_comb,ypd_lastreg,brmat]=forecast_hmc_rec(yr,Xr,cstr,mindist,I,h,rep)

% PURPOSE:  Run HMC samplers for real time recursive forecasts

dr=I/5; % draws discarded in the hid mkv chains

% Some initializations
ypd_comb=zeros((I-dr)*rep,length(h));
ypd_lastreg=zeros((I-dr)*rep,length(h));
brmat = zeros(size(yr,1),1);

% Run the gibbs sampler for the zero break case
result_temp=gibbs_norm(yr,Xr,I);
chp=[1 rows(yr)];
diff_chp=chp(2:end)-chp(1:end-1);

% Run the gibbs sampler for the break cases, number of break indexed by
% M
M=1;
while min(diff_chp) > mindist %minimum distance between breaks is needed
    disp(' ');
    disp(['Testing with # breaks = ',num2str(M)]);
    result=result_temp;
    result_temp=ch_hidmkvch_PT(yr,Xr,M,I);
    % Find location of the breaks
    [~,wet]=findchp_rec(result_temp,cstr);
    [~,jj]=max(wet);
    chp=[1 jj rows(yr)];
    diff_chp=chp(2:end)-chp(1:end-1);
    M=M+1;
end

%Forecasts begin here
disp(' ');
disp(['Estimated number of breaks = ',num2str(M-2)]);
disp(' ');
if M==2 %it means that the loop stopped with the one break model (zero breaks for this sample)
    ypd_c=preddens_nobr(yr,Xr,result,max(h),rep);
    ypd_lr=ypd_c;  %the single regime is also the last one by definition
else
    % here is how we forecast under breaks, and produce composite
    % density
    [~,wet]=findchp_rec(result,cstr);
    [~,jj]=max(wet);
    brmat(jj,1) = 1;
    [ypd_lr,yfor,s2for]=preddens_br(yr,Xr,result,max(h),rep); % this is the last regime density
    ypd_lonb=preddens_lonb_PT(yr,yfor,s2for,Xr,result,max(h),rep);
    ypd_me=preddens_nb_PT(yr,Xr,result,max(h),rep);
    ypd_c=combine_forc(yr,Xr,result,ypd_lr,ypd_me,ypd_lonb,rep); % this is the composite density
end

%store the forecasts, keeping only the horizons we are focusing on to
%save space
for f=1:length(h)
    ypd_comb(:,f)=ypd_c(:,h(f));
    ypd_lastreg(:,f)=ypd_lr(:,h(f));
end



