function ypd=preddens_lonb_PT(y,yfor,s2for,X,result,h,rep)

% PURPOSE: compute the predictive density under break occurance. We use
% the information coming from the meta distributions
% -------------------------------------------------------------------------
% USAGE: ypd=preddens_lonb_PT(y,yfor,X,result,h,rep)
% -------------------------------------------------------------------------
% Written by DP on 9/2/2004

betas=result.betas;
sigma2=result.sigma2;
P=result.P;
pst=result.pst;
s=result.s;
b0=result.b0;
B0=result.B0;
fl=0;
if isfield(result,'v0') == 1
    v0=result.v0;
    d0=result.d0;
    pc=result.pc;
    fl=1;
end
llikf=result.llikf;

nr=cols(b0);
N=rows(s); %number of obs
I=rows(betas); %number of simulations
M=cols(sigma2)-1; %number of breaks

%Some initialization to store the results
ypd=zeros(I*rep,h,h); %predictive density matrix
beta=zeros(I,nr);
sig2=zeros(I,1);
lb=min(reshape(min(betas),nr,M+1)');
ub=max(reshape(max(betas),nr,M+1)');
lb_s=min(min(sigma2));
ub_s=max(max(sigma2));
bar=waitbar(0,'Predictive density computation' );
pc=0;
for j=1:I %for each Gibbs draw I compute the predictive density for each 
          % horizon and store results

    %Draw the betas and the sigma2 for the new regime from the meta distributions
    beta(j,:)=mvnrnd(b0(j,:),B0(:,:,j));
    % check for stationarity
    if nr==2
        while (beta(j,1)) < 0
            beta(j,:)=mvnrnd(b0(j,:),B0(:,:,j));
        end
        if abs(beta(j,2)) > 1          %discard draws that bring non stationarity (would bring an explosive series)
            beta(j,2) = 1;
            beta(j,1)= 0;
        end
    end
    if nr==3
        while (beta(j,3) + beta(j,2) >= 1) | (beta(j,3) - beta(j,2) >= 1) | (abs(beta(j,3)) >= 1) 
%         while max((beta(j,:) < lb) | (beta(j,:) > ub)) == 1
            beta(j,:)=mvnrnd(b0(j,:),B0(:,:,j)); %discard draws that bring non stationarity
        end
    end
    sig2(j)=1/gamm_rnd(1,v0(j)/2,d0(j)/2);
    while (sig2(j) < lb_s) | (sig2(j) > ub_s)  %control the draw for the variance to avoid bad draws
        pc=pc+1;
        sig2(j)=1/gamm_rnd(1,v0(j)/2,d0(j)/2);
    end
   
    % Construct some quantities needed for forecasting
    if beta(j,2)<1
        mu=beta(j,1)/sum([1;-beta(j,2:end)']);
    else
        mu=0;
    end
    F=[beta(j,2:end);eye(nr-1)]; F=F(1:end-1,:);
    phi=eye(h,1);
    for i=2:h
        Fs=F^(i-1);
        phi(i)=Fs(1,1);
    end

    % Compute the forecasts and the forecast error variance and draw from the
    % predictive distribution of yt+h|yt,beta,sigma2
    yf=zeros(h,1);
    s2f=zeros(h,1);
    % Get the last y's to forecast
    ylag=[(y(end-nr+2:end));(yfor(j,:)')];
    for i=1:h-1
        ylag_ii= flipud(ylag(i+1:i+nr-1));
        for ii=i+1:h
            yf(ii)=beta(j,1) + F(1,:)*ylag_ii;
            s2f(ii)=s2for(j,i) + sig2(j)*(sum(phi(1:ii).^2));
            ypd(1+(j-1)*rep:j*rep,ii,i+1)=yf(ii) + sqrt(s2f(ii)) * randn(rep,1);
            yff=yf(ii);
            ylag_ii = [yff;ylag_ii(1:end-1)];
        end
    end
    waitbar(j/I);
end % end of Gibbs sampling loop
close(bar);



