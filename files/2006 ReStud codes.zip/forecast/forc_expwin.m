% PURPOSE: This program computes one step ahead AR(p) forecast recursively
% (expanding window is used) with the observations only from the last
% regime

%clear all; %clc;

% delete forecast_expwind.txt; diary forecast_expwind.txt;
disp(datestr(now)); disp(' ');
% -----------------------------------------------------------*/
%                 Import the data set                        */
% -----------------------------------------------------------*/

I=500;
nlag=1;
nr=nlag+1;

%Import the data 

% [data,varnames]=xlsread('c:/documenti/phd/timmermann/data/datamonthly');
% [data,varnames]=xlsread('z:/dpettenuzzo/data/datamonthly');
data=xlsread('c:/documenti/phd/timmermann/data/riskfree_mod');
cstr=cal(1925,12,12);
N=rows(data);
data=data(1:N,:);

% tbeg=1;
tbeg=ical(1989,9,cstr);  %eliminate for a moment the period 1942-1947 with zero variance
tend=ical(1997,12,cstr); % end of in sample period

y=data(tbeg:end,3);  % 3 month average T-bill
ye=data(tbeg:tend,3);   %estimation sample
yf=data(tend+1:end,3);  %those obs are in the out of sample period
N=rows(ye);
X = [ones(rows(y),1) mlag(y,nlag)];  %intercept and lags  
y=trimr(y,nlag,0);
ye=trimr(ye,nlag,0);
Xe=X(1:N,:);
Xf=X(N+1:end,:);
X=trimr(X,nlag,0);
Xe=trimr(Xe,nlag,0);


mh=rows(yf);
yfo=zeros(I-(0.2*I),mh);
ylag=flipud(ye(end-nr+2:end));

for h=1:mh
    disp(['h=' num2str(h)]);
    res=gibbs_norm(ye,Xe,I);
    yfo(:,h)=(res.beta(:,1) + res.beta(:,2:end) .* ylag) + (sqrt(res.sigma2) .* randn(I-(0.2*I),1));
    ylag=[yf(h);ylag(1:end-1)];
    ye=[ye;yf(h)];
    Xe=[Xe;Xf(h,:)];
end

% diary off;

out=rmsfe(yfo,yf);
% plot([mean(yfo)' yf]);