function [yf,bf]=ols_rollforc(y,X,tb,tbf,tend,wind,h,incr)

% PURPOSE: computes recursive forecasts for the rolling window ols model
% when the forecasting horizon is h and the window size is wind. 
% tb is the beginning of the sample, tbf
% is the beginning of the forecasting sample, and te is the end of the
% sample

[n,k]=size(X);
bar=waitbar(0,['Rolling Window OLS forecasts, h=' num2str(h)] );
i=1;
for t=tbf:incr:tend
    yr=y(t-wind+1:t,:); Xr=X(t-wind+1:t,:);
    % initial values
    res=ols(yr,Xr);
    term1=res.beta(1) * (1-(res.beta(2)^h)) / (1-res.beta(2));
    term2=(res.beta(2)^h)*yr(end);
    yf(i,:)=term1+term2;
    bf(i,:)=res.beta;
    i=i+1;
    waitbar(i/(tend-tbf+1),bar);
end
close(bar);
