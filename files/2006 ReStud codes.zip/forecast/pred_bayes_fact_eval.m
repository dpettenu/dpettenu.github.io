function [plik_c,plik_alt]=pred_bayes_fact_eval(YPD_c,YPD_alt,yf)

% PURPOSE: computes predictive bayes factor for YPD_c against alternative
% --------------------------------------------------------------------
% USAGE: [plik_c,plik_alt]=pred_bayes_fact_eval(YPD_c,YPD_alt,yf)
% --------------------------------------------------------------------
% written by DP on 2 aug 2005

[jj,R,nr]=size(YPD_c);
plik_c=zeros(R,nr); plik_alt=zeros(R,nr);

for i=1:R
    for j=1:nr
        if sum(abs(YPD_c(:,i,j))) > 0
            [xx_c,yy_c]=out_pdf(YPD_c(:,i,j));
            [xx_lr,yy_lr]=out_pdf(YPD_alt(:,i,j));
            ind_c=find(xx_c>yf(i)); 
            if any(ind_c) & ind_c(1) > 1; 
                ind_c=ind_c(1);
                plik_c(i,j)=yy_c(ind_c-1) + (yy_c(ind_c)-yy_c(ind_c-1))/(xx_c(ind_c)-xx_c(ind_c-1)) * (yf(i)-xx_c(ind_c-1));
            else
                plik_c(i,j)=0;
            end
            
            ind_lr=find(xx_lr>yf(i)); 
            if any(ind_lr) & ind_lr(1) > 1
                ind_lr=ind_lr(1);
                plik_alt(i,j)=yy_lr(ind_lr-1) + (yy_lr(ind_lr)-yy_lr(ind_lr-1))/(xx_lr(ind_lr)-xx_lr(ind_lr-1)) * (yf(i)-xx_lr(ind_lr-1));
            else
                plik_alt(i,j)=0;
            end
        else
            plik_c(i,j)=NaN; plik_alt(i,j)=NaN;
        end
    end
end