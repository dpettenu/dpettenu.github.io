function ypd_c=combine_forc(Y,X,result,ypd_lr,ypd_me,ypd_lonb,rep)

% PURPOSE: combine predicitive densities (last regime and meta)
% -------------------------------------------------------------------------
% USAGE: ypd_c=combine_forc(Y,X,result,ypd_lr,ypd_me,ypd_lonb,rep)
% -------------------------------------------------------------------------
% Written by DP on 9/2/2004

%Get the forecast horizon
[I,mh]=size(ypd_me);
%Get an estimate for p_K+1,K+1 from the estimation output of the Gibbs
%Sampler
[p_kp1,n_kp1]=prob_pkp1(Y,X,result,rep);

%Preditive under the diffent scenarios

%Condense results together
ypd_lonb(:,:,1)=ypd_me;

%Combine the forecasts
ypd_c=zeros(I,mh); %combined forecasts for all horizons
% First get the weights (they depend on when the break occurs (i.e. on j)
wet=zeros(I,mh);
for j=1:mh
    wet(:,j)=(p_kp1.^(j-1)) .* (1-p_kp1); % weights
end

for j=1:mh
    for jj=1:mh
        ypd_c(:,j)= ypd_c(:,j) + wet(:,jj) .* ypd_lonb(:,j,jj);  % (if jj(when the break occurs) is greater than j (forecast h.) 
                                                                 %  then ypd_lonb is zero by construction) 
    end
    ypd_c(:,j)= ypd_c(:,j) + (1-(p_kp1.^j)) .* ypd_me(:,j) + (p_kp1.^j) .* ypd_lr(:,j); %assign the weight for the no break case
end
