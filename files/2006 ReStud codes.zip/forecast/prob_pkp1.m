function [y,n]=prob_pkp1(Y,X,result,rep)

%PURPOSE: estimates posterior prbability of regime K+1 from the original
% Gibbs sampling estimates
% -------------------------------------------------------------------------
% USAGE: [y,n]=prob_pkp1(Y,X,result,rep)
% -------------------------------------------------------------------------
% written by DP on 17 feb 2004

%Recover the prior

priordef;

s=result.s; %load the states from the estimated output
N=rows(s); % # of obs
I=cols(s); % # of Gibbs sampling iterations
M=max(result.s(:,2))-1; %# of break points
% Initialize the output var
y=zeros(I*rep,1);
n=zeros(I*rep,1);
for j=1:I
    n(1+(j-1)*rep:j*rep)=sum(s(:,j)==M+1);
    % Fill in the p_kp1 at the jth Gibbs sampling interation
    y(1+(j-1)*rep:j*rep)=beta_rnd(rep,ha0+n(1+(j-1)*rep),hb0+1);
end

