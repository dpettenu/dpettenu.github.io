function ypd_c=combine_2br(ypd_nnb,ypd_lonb,pkp1,pkp2)

% PURPOSE: computes the combined density for the 2 break out of the sample
% scenario.
%--------------------------------------------------------------------------
% USAGE: ypd_c=combine_2br(ypd_nnb,ypd_lonb,pkp1,pkp2)
%--------------------------------------------------------------------------
% written by DP on 12 apr 2004

I=rows(ypd_nnb);
h=cols(ypd_nnb);

for i=1:h %horizon loop
    bar=waitbar(0,['Combining forecasts for h=' num2str(i)] );
    for j=1:I
        w=weight_2br(i,pkp1(j),pkp2(j));
        ypd_c(j,i)=(ypd_nnb(j,i) * w(i+1));
        for s=1:i
            ypd_c(j,i)=ypd_c(j,i) + w(s)*ypd_lonb(j,i,s);
        end
        waitbar(j/I);
    end
    close(bar);
end  %end horizon loop
        
    
