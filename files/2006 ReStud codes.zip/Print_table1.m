% PURPOSE: Print table 1

clear all;

% load data and results
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\allresult_47-02_l1.mat']);

% Specify output for table
out_file = [pwd,'\Results\Figures and tables\Table1.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end
% Run loop to compute marginal likelihood and break dates

% First no break model
xlswrite(out_file,[{'No. breaks'},{'LL'},{'Marginal LL'},{'Break dates'}],'Results','A1');
[m_lik,llikf]=mliknorm_nb(y,X,result_0);
xlswrite(out_file,num2cell([0,llikf,m_lik]),'Results',['A',num2str(2)]);

% Next loop over break models
for nbreak=1:7
    eval(['result = result_',num2str(nbreak),';']);
    [m_lik,llikf] = mliknorm_br(y,X,result);
    [breakdates,chp] = Plot_chp_rec(result,cstr);
    clear('result');
    xlswrite(out_file,[num2cell([nbreak,llikf,m_lik]),breakdates],'Results',['A',num2str(nbreak+2)]);
end

