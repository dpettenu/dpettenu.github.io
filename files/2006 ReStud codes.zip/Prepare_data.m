% PURPOSE: This program loads the data and create the calendar structure
% for the datamonthly data break detection (hierarchical)

addpath(genpath(pwd));
clear all; clc;

disp(datestr(now)); disp(' ');
% -----------------------------------------------------------*/
%                 Import the data set                        */
% -----------------------------------------------------------*/

I=1000;
nlag=1;

%Import the data 

data=xlsread([pwd,'/data/riskfree_mod']);
cstr=cal(1925,12,12);
N=rows(data);
data=data(1:N,:);

% tbeg=1;
tbeg=ical(1947,7,cstr);  %eliminate for a moment the period 1942-1947 with zero variance
tend=ical(2002,12,cstr); % end of in sample period

y=data(tbeg:tend,2);  % 3 month average T-bill
yf=data(tend+1:end,2);  %those obs are in the out of sample period
N=rows(y);
X = [ones(N,1) mlag(y,nlag)];  %intercept and lags  
X=trimr(X,nlag,0);
y=trimr(y,nlag,0);
N=N-nlag;
disp(' ');
disp(['Data sample is: ' tsdate(cstr,tbeg+nlag) ' - ' tsdate(cstr,tend) ' : ' num2str(tend-tbeg-nlag+1) ' obs.']);
disp(' ');
% Ols estimation for comparison
cstr=cal(1947,7+nlag,12);
res=ols(y,X);
disp('');
disp('Ols results');
disp('');
prt(res);

if ~exist([pwd,'\Results'],'dir')
    mkdir([pwd,'\Results']);
end
if ~exist([pwd,'\Results\Figures and tables'],'dir')
    mkdir([pwd,'\Results\Figures and tables']);
end

save([pwd,'\Results\yx.mat'],'y','X','cstr');

