% PURPOSE: Print table 9

clear all;
% Load the data
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\All forecasts.mat']);


% Rearrange y data to be organized by year (1968 to 2001) on the rows and by
% forecast horizon on the columns (12 to 60 months ahead)
yff       = NaN(2001-1968+1,5);
forc_year = zeros(2001-1968+1,5);

for fh=[12 24 36 48 60]
    for t=1968:1:2002-(fh/12)
        forc_year(t-1968+1,fh/12) = t + (fh/12);
        yff(t-1968+1,fh/12)=y(ical(t,12,cstr)+fh);
    end
end

index_70s = zeros(2001-1968+1,5);
index_80s = zeros(2001-1968+1,5);
index_90s = zeros(2001-1968+1,5);

for fh=[12 24 36 48 60]
    index_70s(:,fh/12) = forc_year(:,fh/12)>=1968 & forc_year(:,fh/12)<1980;
    index_80s(:,fh/12) = forc_year(:,fh/12)>=1980 & forc_year(:,fh/12)<1990;
    index_90s(:,fh/12) = forc_year(:,fh/12)>=1990;
end

% Compute bayes factors here
% Composite vs last regime
[plik_c,plik_lr]=pred_bayes_fact_eval(YPD_c,YPD_lr,yff);
plik_c(plik_c==0) = NaN;
plik_lr(plik_lr==0) = NaN;
% % Composite vs RL-AR
% [~,plik_rlar]=pred_bayes_fact_eval(YPD_c,YPD_rlar,yff);
% plik_rlar(plik_rlar==0) = NaN;
% % Composite vs RV-AR
% [~,plik_rvar]=pred_bayes_fact_eval(YPD_c,YPD_rvar,yff);
% plik_rvar(plik_rvar==0) = NaN;

% Now the comparisons, full sample and subsamples
out_cell_fs = NaN(4,3,5);

for fh=[12 24 36 48 60]

    % Composite vs last regime
    out_cell_fs(1,1,fh/12) = nanmean(plik_c(:,fh/12)./plik_lr(:,fh/12));
    out_cell_fs(2,1,fh/12) = nanmean(plik_c(index_70s(:,fh/12)==1,fh/12)./plik_lr(index_70s(:,fh/12)==1,fh/12));
    out_cell_fs(3,1,fh/12) = nanmean(plik_c(index_80s(:,fh/12)==1,fh/12)./plik_lr(index_80s(:,fh/12)==1,fh/12));
    out_cell_fs(4,1,fh/12) = nanmean(plik_c(index_90s(:,fh/12)==1,fh/12)./plik_lr(index_90s(:,fh/12)==1,fh/12));
%     % Composite vs random level AR
%     out_cell_fs(1,2,fh/12) = nanmean(plik_c(:,fh/12)./plik_rlar(:,fh/12));
%     out_cell_fs(2,2,fh/12) = nanmean(plik_c(index_70s(:,fh/12)==1,fh/12)./plik_rlar(index_70s(:,fh/12)==1,fh/12));
%     out_cell_fs(3,2,fh/12) = nanmean(plik_c(index_80s(:,fh/12)==1,fh/12)./plik_rlar(index_80s(:,fh/12)==1,fh/12));
%     out_cell_fs(4,2,fh/12) = nanmean(plik_c(index_90s(:,fh/12)==1,fh/12)./plik_rlar(index_90s(:,fh/12)==1,fh/12));
%     % Composite vs random variance AR
%     out_cell_fs(1,3,fh/12) = nanmean(plik_c(:,fh/12)./plik_rvar(:,fh/12));
%     out_cell_fs(2,3,fh/12) = nanmean(plik_c(index_70s(:,fh/12)==1,fh/12)./plik_rvar(index_70s(:,fh/12)==1,fh/12));
%     out_cell_fs(3,3,fh/12) = nanmean(plik_c(index_80s(:,fh/12)==1,fh/12)./plik_rvar(index_80s(:,fh/12)==1,fh/12));
%     out_cell_fs(4,3,fh/12) = nanmean(plik_c(index_90s(:,fh/12)==1,fh/12)./plik_rvar(index_90s(:,fh/12)==1,fh/12));
    
end

% Write to excel file
out_file = [pwd,'\Results\Figures and tables\Table9.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end

xlswrite(out_file,[{' '},{'Full sample'},{'1970s'},{'1980s'},{'1990s'}],'Results','A1');
xlswrite(out_file,{'h = 12'},'Results','C2');
xlswrite(out_file,[[{'Last regime'};{'RL-AR'};{'RV-AR'}],num2cell(out_cell_fs(:,:,1)')],'Results','A3');
xlswrite(out_file,{'h = 24'},'Results','C6');
xlswrite(out_file,[[{'Last regime'};{'RL-AR'};{'RV-AR'}],num2cell(out_cell_fs(:,:,2)')],'Results','A7');
xlswrite(out_file,{'h = 36'},'Results','C10');
xlswrite(out_file,[[{'Last regime'};{'RL-AR'};{'RV-AR'}],num2cell(out_cell_fs(:,:,3)')],'Results','A11');
xlswrite(out_file,{'h = 48'},'Results','C14');
xlswrite(out_file,[[{'Last regime'};{'RL-AR'};{'RV-AR'}],num2cell(out_cell_fs(:,:,4)')],'Results','A15');
xlswrite(out_file,{'h = 60'},'Results','C18');
xlswrite(out_file,[[{'Last regime'};{'RL-AR'};{'RV-AR'}],num2cell(out_cell_fs(:,:,5)')],'Results','A19');


