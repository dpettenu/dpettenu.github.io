% PURPOSE: Run results for tables 6 and 7

clear all; clc;

% load data
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\chp_6breaks_PT']);

% Break models with 6 breaks, with larger number of iterations
result=ch_hidmkvch_PT_betadep2(y,X,chp);

% Save results
save([pwd,'\Results\result_6_l1_PT_betadep.mat'],'result');
