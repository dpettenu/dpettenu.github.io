function [m_lik,llikf]=mliknorm_nb(y,X,post)

% PURPOSE: This function computes the marginal likelihhod for the Normal
%         inverted gamma prior case using the MC results as in as in Chib 
%         1998 
%**************************************************************************
% USAGE: [m_lik,llikf]=mliknorm_nb(y,X,post)
%**************************************************************************
% Input:
% y = vector n x 1 of dependent variables
% post = is a structure containing the following fields:
% post.sigma2 = vector (I-dr) x 1 of sigma2 draws 
% post.beta = matrix (I-dr) x k of coeffs draws 
%**************************************************************************
% Output:
%
%**************************************************************************
% Written by Davide Pettenuzzo
% Ph.D. Student
% Bocconi University - Milan
% November 18th, 2003

[n k]=size(X);

%Definition of hyperparameters
v0=1;
i=ones(n,1);
M0=eye(n) - inv(i'*i) * i*i';
M=eye(n) - X*invpd(X'*X)*X';
d0=(y'*M*y)/(n-k);     %increases the precision on the sigma2 estimates
b0=zeros(k,1);
c=max(k^2,n);
B0=c*eye(k);


betas=post.beta(:,1:2);
sigma2=post.sigma2(1,1,:);
I=rows(betas);

%Computes the posterior mean for the parameters 
m_betas=mean(betas);
m_sigma2=mean(sigma2);

y=y(:,1);  %get only the first equation dep variable

% 1) Computes the likelihood function at the posterior mean

llikf=sum(log(norm_pdf(y,X*m_betas',ones(n,1)*m_sigma2)));

% 2) evaluate the priors at the posterior mean
% lpr_betas=log(mvnpdf(m_betas',b0,B0));
lpr_betas=-.5*k*log(2*pi) - .5*k*log(det(B0)) - ...
        .5*(m_betas'-b0)'*invpd(B0)*(m_betas'-b0);
lpr_s2=log(igamm_pdf(m_sigma2,v0/2,d0/2));    

% 3) evaluate the posterior at the posterior mean
% First the betas
Bn=invpd(invpd(B0) + (1/m_sigma2)*(X'*X));
m=Bn*(invpd(B0)*b0 + (1/m_sigma2)*(X'*y));

% lpost_betas=log(mvnpdf(m_betas',m,Bn));
lpost_betas=-.5*k*log(2*pi) - .5*k*log(det(Bn)) - ...
        .5*(m_betas'-m)'*invpd(Bn)*(m_betas'-m);

% then sigma2 (need a secondary gibbs chain)
v1=(v0+n);
s2_sec=zeros(I,1);
for j=1:I
    d1=d0 + (y - X*betas(j,:)')'*(y - X*betas(j,:)');
    s2_sec(j)=igamm_pdf(m_sigma2,v1/2,d1/2);  
end
lpost_s2=log(mean(s2_sec));

m_lik=llikf + lpr_betas + lpr_s2 - lpost_betas - lpost_s2;

disp(['ln f(Yn|phi_star) =  ' num2str(llikf)]);
disp(' ');
disp(['ln m(Yn) =            ' num2str(m_lik)]);
