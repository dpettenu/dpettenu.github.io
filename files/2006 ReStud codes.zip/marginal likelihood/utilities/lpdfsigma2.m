function lpost_sigma2=lpdfsigma2(Y,X,bks,m_betas,m_sigma2,v0_o,d0_o)

% PURPOSE: evaluates log pdf for the sigma2's

J=length(bks)-1;
nr=cols(X);
lpost_sigma2=zeros(1,J);
for j=1:J
    Yi=Y(bks(j):bks(j+1)-1,:);
    Xi=X(bks(j):bks(j+1)-1,:);
    v1=v0_o+(bks(j+1)-bks(j));
    if cols(m_betas) == cols(X)  %constant coeffs case
        d1=(d0_o*v0_o) + (Yi - Xi*m_betas')'*(Yi - Xi*m_betas');
    else
        d1=(d0_o*v0_o) + (Yi - Xi*m_betas(1+(j-1)*nr:j*nr)')'*(Yi - Xi*m_betas(1+(j-1)*nr:j*nr)');
    end
    lpost_sigma2(j)=log(igamm_pdf(m_sigma2(j),v1/2,d1/2));
end
disp('');

