function lpdf_v0=lpostv0(Y,X,m_sigma2,m_d0,m_v0)

% PURPOSE: evaluates log pdf for v0 (up to a proportionality constant so we
% need to perform quadrature first to evaluate the integral and get the
% proportionality constant

global rho0 isigma2 t_m_d0;
isigma2=1./m_sigma2;
t_m_d0=m_d0;
r_min=eps; r_max=1000; %specify the range for quadrature to get the proportionality const.
q=quad(@f_quad,r_min,r_max);
lpdf_v0=log(f_quad(m_v0)/q);

function y=f_quad(x)

% PURPOSE: evaluate function for the quadrature

global rho0 isigma2 t_m_d0;
y=zeros(length(x),1);
for i=1:rows(y)
    y(i)=sum(gamm_pdf2(isigma2,x(i),t_m_d0)) * exppdf(x(i),rho0);
end