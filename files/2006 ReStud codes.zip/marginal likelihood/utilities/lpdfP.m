function lpost_P=lpdfP(y,X,M,s,m_P)

% PURPOSE: evaluate log pdf for the transition prob
% matrix

global a b;

post_Pi=zeros(1,M);
[N,k]=size(X); k=k-1;
P=zeros(M+1,M+1);
%Compute the number of one-step transitions from state i to state i in
%the sequence s
clear nii;
for i=1:M
    nii(i)=sum(s==i);
    % Fill in the P matrix at the jth Gibbs sampling interation
    post_Pi(i)=beta_pdf(m_P(i,i),a+nii(i),b+1);
end
lpost_P=log(prodc(post_Pi'));