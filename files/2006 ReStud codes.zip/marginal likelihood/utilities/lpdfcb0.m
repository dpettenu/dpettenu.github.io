function lpost_B0=lpdfcb0(Y,X,bks,m_betas,m_b0,m_B0)

% PURPOSE: evaluate log pdf for B0

global rho R;

J=length(bks)-1;
nr=cols(X);
vbar_be=J+rho;
tt=reshape(m_betas,nr,J); 
tt_m=zeros(nr,nr);
for i=1:J
    tt_m=tt_m+((tt(:,i)-m_b0')*(tt(:,i)-m_b0')');
end
% tt_m=tt-repmat(b0_n',1,J); %coeff in deviation from their mean
Vbar_be=tt_m + R;
lpost_B0=logwish_pdf(inv(m_B0),invpd(Vbar_be),vbar_be);