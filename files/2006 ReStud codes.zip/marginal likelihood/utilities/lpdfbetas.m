function lpost_beta=lpdfbetas(Y,X,bks,m_betas,sigma2_o,b0_o,B0_o)

% PURPOSE: evaluates log pdf for the betas

J=length(bks)-1;
nr=cols(X);
b0_o=b0_o';
post_beta=zeros(1,J);
for j=1:J
    Yi=Y(bks(j):bks(j+1)-1,:);
    Xi=X(bks(j):bks(j+1)-1,:);
    Bn=invpd(invpd(B0_o) + (1/sigma2_o(j))*(Xi'*Xi));
    m=Bn*(invpd(B0_o)*b0_o + (1/sigma2_o(j))*(Xi'*Yi));
    post_beta(j)=exp(-.5*nr*log(2*pi) - .5*nr*log(det(Bn)) - ...
        .5*(m_betas(1+((j-1)*nr):j*nr)'-m)'*invpd(Bn)*(m_betas(1+((j-1)*nr):j*nr)'-m));
end
%check
if (prodc(post_beta')) == 0
    lpost_beta = -Inf;  
else
    lpost_beta=log(prodc(post_beta'));
end
   

