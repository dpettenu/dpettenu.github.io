function lpost_d0=lpdfd0(Y,X,bks,m_sigma2,m_d0,v0_o)

% PURPOSE: evaluates log pdf for d0

global hc0 hd0;

J=length(bks)-1;
isigma2=1./m_sigma2;
lpost_d0=log(gamm_pdf2(m_d0,v0_o*J+hc0,sum(isigma2)+hd0));