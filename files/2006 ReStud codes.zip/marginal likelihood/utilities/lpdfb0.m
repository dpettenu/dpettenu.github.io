function lpost_b0=lpdfb0(Y,X,bks,m_betas,m_b0,B0_o)

% PURPOSE: evaluates log pdf for b0

global mub Vb;

J=length(bks)-1;
nr=cols(X);
tt=reshape(m_betas,nr,J); %useful in the next step
sigmabe=invpd(J*invpd(B0_o) + invpd(Vb));
mube=sigmabe * (invpd(B0_o)*sum(tt,2) + invpd(Vb)*mub);
lpost_b0=-.5*nr*log(2*pi) - .5*nr*log(det(sigmabe)) - ...
        .5*(m_b0'-mube)'*invpd(sigmabe)*(m_b0'-mube);

