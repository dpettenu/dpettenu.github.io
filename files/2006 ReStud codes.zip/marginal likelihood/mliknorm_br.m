function [marglik,llikfu]=mliknorm_br(y,X,result)

% PURPOSE: This function computes the marginal likelihood for the Normal
%         inverted gamma prior case using the MC results as in as in Chib 
%         1996
%**************************************************************************
% USAGE: [marglik,llikfu]=mliknorm_br(y,X,result)
% *************************************************************************
% INPUT:
% y = vector n x 1 of dependent variables
% X = n x k matrix of regressors
% prior: is a structure whose fields are
%   prior.a: a coeff for the beta(a,b) piis distr  
%   prior.b: b coeff for the beta(a,b) piis distr 
%   prior.b0: prior for the regression coeff mean
%   prior.B0: prior for the regression coeff var-cov matrix
%   prior.v0: prior for the Inverted Gamma degrees of freedom
%   prior.d0: prior for the Inverted Gamma precision 
%   prior.n: number of observations
% post = is a structure containing the following fields:
% post.sigma2 = vector (I-dr) x 1 of sigma2 draws 
% post.beta = matrix (I-dr) x k of coeffs draws 
%
% OUTPUT:
%
% m_lik: marginal likelihood function for the model
% llikf: log likelihood function for the model 
%**************************************************************************
% Written by Davide Pettenuzzo
% Ph.D. Student
% Bocconi University - Milan
% Feb 4th, 2004

global a b mub Vb rho R hc0 hd0 rho0;

[N k]=size(X);
% ----------------------------------------------------------------
%Load the posterior draws
% ----------------------------------------------------------------

betas=result.betas;
sigma2=result.sigma2;
P=result.P;
pst=result.pst;
s=result.s;
b0=result.b0;
B0=result.B0;
fl=0;
if isfield(result,'v0') == 1
    v0=result.v0;
    d0=result.d0;
    pc=result.pc;
    fl=1;
end
llikf=result.llikf;
M=rows(P)-1;
I=rows(betas);
tune=5;  %tune for the rejection in the M-H stage

% Means of the posterior distribution for the theta_k and the

m_betas=mean(betas);
m_sigma2=mean(sigma2);
m_P=mean(P,3);
m_b0=mean(b0);
m_B0=mean(B0,3);
m_v0=mean(v0);
m_d0=mean(d0);

% --------------------------------------------------
% Prior definition: 
% --------------------------------------------------

k=k-1; priordef; k=k+1; %careful with the definition of k in ch_hidmkvch

% ----------------------------------------------------------------
% Compute the Likelihood function at the parameter posterior means
% ----------------------------------------------------------------

% First I need the states prob t=1,...,n  p(st|yt,M,theta,P) once again for 
% theta=theta_star and P=P_star

pst_ytl=zeros(M+1,N);
pst_yt=zeros(M+1,N);
pst_star=zeros(M+1,N); %prob of the states
ilikf=zeros(N,M+1);   %store the individual likelihood function under all regimes
%Compute p(s1|Y1,theta,P) first
pst_ytl(:,1)=eye(M+1,1); %degenerate prob distr for p(s1|Y0,theta,P)
fyt_ytl=normgen(y(1),X(1,:),m_betas,m_sigma2,M);
ilikf(1,:)=fyt_ytl';
num=(pst_ytl(:,1).*fyt_ytl);
den=sumc(num);
pst_yt(:,1)=num./den;
%Now repeat the same step for t=2,...,N
for t=2:N
    pst_ytl(:,t)=m_P'*pst_yt(:,t-1);
    %compute f(yt|Yt-1,theta_k) for each state k=1,...,M+1
    fyt_ytl=normgen(y(t),X(t,:),m_betas,m_sigma2,M);
    ilikf(t,:)=fyt_ytl';
    num=(pst_ytl(:,t).*fyt_ytl);
    den=sumc(num);
    pst_yt(:,t)=num./den;
end
% Then I compute the likelihhod function for t=1,..,n
likf=diag(ilikf*pst_ytl);

% ----------------------------------------------------------------
% 1)
llikfu=sum(log(likf));
disp(' ');
disp(['ln f(Yn|phi_star) =  ' num2str(llikfu)]);
disp(' ');
% ----------------------------------------------------------------

% ----------------------------------------------------------------
% Evaluate the prior at the mean of the posterior distribution of
% beta_k sigma2_k and piis
% ----------------------------------------------------------------

%the Pii's
Pr_pii=prodc(beta_pdf(diag(m_P(1:M,1:M)),a,b));

%the betas
for cm=1:M+1
    lPr_betas(cm)=-.5*k*log(2*pi) - .5*k*log(det(m_B0)) - ...
        .5*(m_betas(1+((cm-1)*k):cm*k)'-m_b0')'*invpd(m_B0)*(m_betas(1+((cm-1)*k):cm*k)'-m_b0');
end

% the sigma2's
Pr_s2=igamm_pdf(m_sigma2',m_v0/2,m_d0/2); 

% b0
lPr_b0=-.5*k*log(2*pi) - .5*k*log(det(Vb)) - ...
        .5*(m_b0'-mub)'*invpd(Vb)*(m_b0'-mub);

% B0 (gives troubles for nr > 2. )
lPr_B0=logwish_pdf(invpd(m_B0),R,rho);
if isinf(lPr_B0) == 1
    lPr_B0=0;
end
% v0
lPr_v0=log(exppdf(m_v0,rho0));

% d0
lPr_d0=log(gamm_pdf2(m_d0,hc0,hd0));

% ----------------------------------------------------------------
% 2)
%let B0 out for a while
% lPr_B0=0;
lPr=log(Pr_pii)+sumc(lPr_betas) + sumc(log(Pr_s2))...
    + lPr_b0 + lPr_B0 + lPr_v0 + lPr_d0; 
% ----------------------------------------------------------------

% Now the different blocks for computing log posterior starts

% for the betas I use the result from the original chain
lpost_beta=zeros(I,1);
for j=1:I
    incr=s(:,j)-lag(s(:,j),1);
    bks=[find(incr==1)' N+1];
    lpost_beta(j)=lpdfbetas(y,X,bks,m_betas,sigma2(j,:),b0(j,:),B0(:,:,j));
end
lP_beta=mean(lpost_beta);  %1st piece

%first auxilliary Gibbs Chain to evaluate sigma's component
lpost_sigma2=zeros(I-1,M+1);
bar=waitbar(0,'Mliknorm br - 1st auxilliary chain' );
for j=2:I
    % 1. Sample the state probabilities and the states
    % [pst(:,:,j),s(:,j),junk(j)]=drawstates(y,X,M,m_betas,sigma2(j-1,:),...
    % P(:,:,j-1)); stop for a while...and use the original states 
    % 2. Sample regression parameters
    %For each regime draw from the posterior distr of its parameters
    incr=s(:,j)-lag(s(:,j),1);
    bks=[find(incr==1)' N+1];
    sigma2(j,:)=drawsigma2(y,X,bks,m_betas,v0(j-1,:),d0(j-1,:));
    b0(j,:)=drawb0(y,X,bks,m_betas,B0(:,:,j-1));
    B0(:,:,j)=drawcb0(y,X,bks,m_betas,b0(j,:));
    d0(j,:)=drawd0(y,X,bks,sigma2(j,:),v0(j-1,:));
    [v0(j,:),pc(j)]=drawv0(y,X,sigma2(j,:),d0(j,:),v0(j-1,:),tune);
    % 3. Sample Transition Probability matrix 
    P(:,:,j)=drawP(y,X,M,s(:,j));
    % 4. Now the pdf eval for the sigma2's
    lpost_sigma2(j-1,:)=lpdfsigma2(y,X,bks,m_betas,m_sigma2,v0(j,:),d0(j,:));
    waitbar(j/I);
end %end of gibb sampling loop
close(bar);

lP_sigma2=sum(mean(lpost_sigma2));  %2nd piece

%second auxilliary Gibbs Chain to evaluate b0
lpost_b0=zeros(I-1,1);
bar=waitbar(0,'Mliknorm br - 2nd auxilliary chain' );
for j=2:I
    % 1. Sample the state probabilities and the states
    % [pst(:,:,j),s(:,j),junk(j)]=drawstates(y,X,M,m_betas,m_sigma2,...
    % P(:,:,j-1)); see above loop... 
    % 2. Sample regression parameters
    %For each regime draw from the posterior distr of its parameters
    incr=s(:,j)-lag(s(:,j),1);
    bks=[find(incr==1)' N+1];
    b0(j,:)=drawb0(y,X,bks,m_betas,B0(:,:,j-1));
    B0(:,:,j)=drawcb0(y,X,bks,m_betas,b0(j,:));
    d0(j,:)=drawd0(y,X,bks,m_sigma2,v0(j-1,:));
    [v0(j,:),pc(j)]=drawv0(y,X,m_sigma2,d0(j,:),v0(j-1,:),tune);
    % 3. Sample Transition Probability matrix 
    P(:,:,j)=drawP(y,X,M,s(:,j));
    % 4. Now the pdf eval for  b0
    lpost_b0(j-1)=lpdfb0(y,X,bks,m_betas,m_b0,B0(:,:,j));
    waitbar(j/I);
end %end of gibb sampling loop
close(bar);

lP_b0=mean(lpost_b0);  %3rd piece

%third auxilliary Gibbs Chain to evaluate B0
% NOTE_1: from this chain onward we also can eliminate the draws for the
% states and the Pii's, since they both depends only on the betas and
% sigmas and both from now on are fixed to their posterior mean. So we will
% use the results from the previous chain (s and P)

% NOTE_2: in this case here we don't need to run an additional chain since
% from this particular problem the pdf we compute here is independent from
% the chain draws, as you can see from line 227 no result from the chain
% enters the pdf computation

% lpost_B0=zeros(I-1,1);
% bar=waitbar(0,'Mliknorm br - 3rd auxilliary chain' );
% for j=2:I
%     % 2. Sample regression parameters
%     %For each regime draw from the posterior distr of its parameters
%     incr=s(:,j)-lag(s(:,j),1);
%     bks=[find(incr==1)' N+1];
%     B0(:,:,j)=drawcb0(y,X,bks,m_betas,m_b0);
%     d0(j,:)=drawd0(y,X,bks,m_sigma2,v0(j-1,:));
%     [v0(j,:),pc(j)]=drawv0(y,X,m_sigma2,d0(j,:),v0(j-1,:),tune);
%     % 4. Now the pdf eval for  B0
%     lpost_B0(j-1)=lpdfcb0(y,X,bks,m_betas,m_b0,m_B0);
%     waitbar(j/I);
% end %end of gibb sampling loop
% close(bar);

lP_B0=lpdfcb0(y,X,bks,m_betas,m_b0,m_B0);  %4th piece

%fourth auxilliary Gibbs Chain to evaluate d0
lpost_d0=zeros(I-1,1);
bar=waitbar(0,'Mliknorm br - 4th auxilliary chain' );
for j=2:I
    % 2. Sample regression parameters
    %For each regime draw from the posterior distr of its parameters
    incr=s(:,j)-lag(s(:,j),1);
    bks=[find(incr==1)' N+1];
    d0(j,:)=drawd0(y,X,bks,m_sigma2,v0(j-1,:));
    [v0(j,:),pc(j)]=drawv0(y,X,m_sigma2,d0(j,:),v0(j-1,:),tune);
    % 4. Now the pdf eval for  d0
    lpost_d0(j-1)=lpdfd0(y,X,bks,m_sigma2,m_d0,v0(j-1,:));
    waitbar(j/I);
end %end of gibb sampling loop
close(bar);

lP_d0=mean(lpost_d0);  %5th piece

%Fifth auxilliary Gibbs Chain to evaluate v0
% See NOTE_2 also here

% lpost_v0=zeros(I-1,1);
% bar=waitbar(0,'Mliknorm br - 5th auxilliary chain' );
% for j=2:I
%     % 2. Sample regression parameters
%     [v0(j,:),pc(j)]=drawv0(y,X,m_sigma2,m_d0,v0(j-1,:),tune);
%     % 4. Now the pdf eval for  v0
%     lpost_v0(j-1)=lpostv0(y,X,m_sigma2,m_d0,m_v0);
%     waitbar(j/I);
% end %end of gibb sampling loop
% close(bar);

lP_v0=lpostv0(y,X,m_sigma2,m_d0,m_v0);  %6th piece

%6th auxilliary Gibbs Chain to evaluate P
lpost_P=zeros(I-1,1);
bar=waitbar(0,'Mliknorm br - 6th auxilliary chain' );
for j=2:I
    % 4. Now the pdf eval for  P
    lpost_P(j-1)=lpdfP(y,X,M,s(:,j),m_P);
    waitbar(j/I);
end %end of gibb sampling loop
close(bar);
disp('');


lP_P=mean(lpost_P);  %7th piece

% Now compute the log posterior (just add all the pieces)
%let B0 out for a while
% lP_B0=0;
lpost=lP_beta+lP_sigma2+lP_b0+lP_B0+lP_d0+lP_v0+lP_P;

%Now the Marginal likelihood

marglik=llikfu + lPr - lpost;

disp(' ');
disp(['Marginal likelihood: ' num2str(marglik)]);