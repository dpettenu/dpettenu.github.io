function [beta,sigma2_n]=normpost_cc(Y,X,sigma2_o,prior,bks,varargin)

% PURPOSE: This function performs one step of the Gibbs sampling for the normal
% inverted gamma case (constant coeff case). The input are the vector of dependent variables and
% the independent variable matrix together with the chain previous run for
% sigma2. The output are the betas and the sigma for this run of the chain

% nargin (opt) tells if the variance is constant or not
if nargin == 5
    opt=0; 
elseif nargin == 6
    opt=varargin{1}; %constant var
end
%Recover prior information
v0=prior.v0;
d0=prior.d0;
b0=prior.b0;
B0=prior.B0;

% Normal Inverted gamma 
sigma2in = 1./sigma2_o;
M=cols(bks)-1;

tVar=(invpd(B0) + (matmul(X,sigma2in))' * X);
tMean=invpd(tVar)*(invpd(B0)*b0 + (matmul(X,sigma2in))'*Y);
%   seed = hsec + i + g;
beta=mvnrnd(tMean,invpd(tVar))';

errr = Y - X*beta;

%Modify to account for the constant sigma case

if opt == 1  %constant variance
    v = v0 + (bks(end) - bks(1));
    d = d0 + errr' * errr;
    sigma2_n = 1/(gamm_rnd(1,v/2,d/2));
elseif opt == 0  %variable variance
    i = 2; 
    while i <= M+1;
         u2i=errr(bks(i-1):bks(i)-1);
        v = v0 + (bks(i) - bks(i-1));
        d = v0*d0 + u2i' * u2i;
%       seed = hsec + i + g;
        sigma2_n(i-1) = 1/(gamm_rnd(1,v/2,d/2));
        i = i + 1;
    end
end
 
 beta=beta';