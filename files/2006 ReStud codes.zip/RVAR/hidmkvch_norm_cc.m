function result=hidmkvch_norm_cc(y,X,M,I,varargin)

% PURPOSE: This program uses the hidden markov chain of Chib 1998 to compute the
%         unknown multiple break points for the normal inverted gamma case
%         for the constant coeff but changing variance case
% *************************************************************************
% USAGE: result=hidmkvch_norm_cc(y,X,M,I,varargin)
% *************************************************************************
% INPUT:
% y: dep variable
% X: independent variables
% M: number of breaks to look for
% I: number of Gibbs samplings
% flag: (optional) = 1 load a previous chain as starting values
%                  = 2 random starting values
%                  = 0 external procedure to generate the starting values 
%                     (default)
% *************************************************************************
% Written by DP on 11/16/03

% Input check
if nargin == 6
    flag=varargin{1};
    result_old=varargin{2};
elseif nargin ==5
    flag=varargin{1};
elseif nargin ==4
    flag=0; %standard value
else
    error('wrong number of input');
end

[N,k]=size(X); k=k-1;

% Some initilization for the chain to run
%States 
pst_ytl=zeros(M+1,N);
pst_yt=zeros(M+1,N);
pst=zeros(M+1,N,I); %prob of the states
s=zeros(N,I);       %observed states
%Parameter vectors under the M+1 regimes
betas=zeros(I,(k+1));
sigma2=zeros(I,M+1);
% Transition probability matrix
P=zeros(M+1,M+1,I);
% For the likelihood f at each iteration
llikf=zeros(I,1);

% Priors:
prior=gen_prior_cc(y,X);

% Set initial values for the Gibbs sampling
if flag == 1
    % 1) Load star values from previous results as to continue a previous
    % chain (note: in this case set dr to 0, no burn in observation)
    betas(1,:)=result_old.betas(end,:);
    sigma2(1,:)=result_old.sigma2(end,:);
elseif flag ==0
    % 2) External procedure to compute the initial starting values
    [betas(1,:),sigma2(1,:)]=strvls(y,X,M,5);  % 5 a the option for no coeffs changes but var changes
elseif flag == 2
    % 3) Random initial values
    betas(1,:)=randn(1,(k+1));
    sigma2(1,:)=rand(1,M+1);
end
%Transition prob matrix (random initialization given the structure
%constraints)
% P(:,:,1)=rand(M+1,M+1).*eye(M+1,M+1);
P(:,:,1)=0.5.*eye(M+1,M+1);;  %equal prob of staying or moving from each regime
for i=1:M
    P(i,i+1,1)=1-P(i,i,1);
end
P(M+1,M+1,1)=1; %prob of remaining in the last state once reached is 1

%The Gibbs sampling starts here
bar=waitbar(0,'Hidden Markov Chain' );
for j=2:I
    % 1. Draw the states
    [llikf(j),pst(:,:,j),s(:,j)]=draw_states_cc(y,X,betas(j-1,:),sigma2(j-1,:),P(:,:,j-1),M);
    % 2. Sample for k=1,...,m theta_k prop to prior(theta_k)*L(Y|theta_k)
    incr=s(:,j)-lag(s(:,j),1);
    bks=[find(incr==1)' N+1];
    [Xi,iVar] = indBrkL_ex(X,bks);
    sigma2_o = iVar*sigma2(j-1,:)';  
    [betas(j,:),sigma2(j,:)]=normpost_cc(y,X,sigma2_o,prior,bks);
    % 3. Sample for i=1,...,m pi from Dirichlet distr.
    P(:,:,j)=draw_P(s(:,j),M,prior);
    waitbar(j/I);
end %end of gibb sampling loop
close(bar);

%Store the MCMC drawing into the structure result 
if flag ~= 1
    dr=I/5; %trim the first .. percent of draws
else
    dr=0;
end
result.betas=betas(dr+1:end,:);
result.sigma2=sigma2(dr+1:end,:);
result.P=P(:,:,dr+1:end);
result.pst=pst(:,:,dr+1:end);
result.s=s(:,dr+1:end);
result.llikf=llikf(dr+1:end);