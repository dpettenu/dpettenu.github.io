function sig2_n=drawsig2(y,X,phi_n,sjl,v,lam)

% PURPOSE: draw siga2 for a run of the gibbs sampler for the RVAR model

[n,k]=size(X); p=k-1;

ym=y(p+1:n); Xm=X(p+1:n,:);
s2=sum( ((ym-Xm*phi_n').^2) ./ (sjl(p,p:n-p)'.^2) );
temp=gamm_rnd(1,((n-p)+v)/2,(s2+v*lam)/2);
sig2_n=1/temp;

