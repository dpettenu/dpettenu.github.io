function [ypd,yfor,s2for]=preddens_br_cc(y,X,result,h,rep)

% PURPOSE: compute the predictive density under no break occurance. We use only 
% the information coming from the last regime estimates.
% -------------------------------------------------------------------------
% USAGE: [ypd,yfor,s2for]=preddens_br(y,X,result,h,rep)
% -------------------------------------------------------------------------
% Written by DP on 9/2/2004

betas=result.betas;
sigma2=result.sigma2;
P=result.P;
pst=result.pst;
s=result.s;
llikf=result.llikf;

nr=cols(betas);
N=rows(s); %number of obs
I=rows(betas); %number of simulations
M=cols(sigma2)-1; %number of breaks

%Some initialization to store the results
yfor=zeros(I*rep,h);
s2for=zeros(I,h);
ypd=zeros(I,h); %predictive density matrix

bar=waitbar(0,'Predictive density computation' );
for j=1:I %for each Gibbs draw I compute the predictive density for each 
          % horizon and store results

    %Get the last betas and sigma2 (only the last regime matters)
    %Note: first beta is the drift, then all the lag coeffs
    beta=betas(j,end-nr+1:end); sig2=sigma2(j,end);


    % Get the las y's to forecast
    ylag=flipud(y(end-nr+2:end));

    % Construct some quantities needed for forecasting
%     mu=beta(1)/sum([1;-beta(2:end)']);
    F=[beta(2:end);eye(nr-1)]; F=F(1:end-1,:);
    phi=eye(h,1);
    for i=2:h
        Fs=F^(i-1);
        phi(i)=Fs(1,1);
    end

    % Compute the forecasts and the forecast error variance and draw from the
    % predictive distribution of yt+h|yt,beta,sigma2
    yf=zeros(h,1);
    s2f=zeros(h,1);
    for i=1:h
%         yf(i)=mu + F(1,:)*(ylag - ones(nr-1,1)*mu);
        yf(i)=beta(1) + F(1,:)*ylag;
        ylag=[yf(i);ylag(1:end-1)];
        s2f(i)=sig2*(sum(phi(1:i).^2));
        ypd(1+(j-1)*rep:j*rep,i)=yf(i) + sqrt(s2f(i)) * randn(rep,1);
    end
    yfor(j,:)=yf';
    s2for(j,:)=s2f';
    waitbar(j/I);
end % end of Gibbs sampling loop
close(bar);

