function prior=gen_prior_cc(y,X)

% PURPOSE: Generate the prior for the Bayesian (HMC) break detection 
%          and the costant coeff case.       
% ***************************************************************
% USAGE: prior=gen_prior_cc(y,X)
% ***************************************************************
% INPUT:
%
% y: (nobs x 1) vector for the dependent variable
% X: (nobs x nr) matrix containing the regressors (including 
%     the constant)
% M: number of break points tested
% 
% OUTPUT:
%
% prior: is a structure whose fields are
%   prior.a: a coeff for the beta(a,b) piis distr  
%   prior.b: b coeff for the beta(a,b) piis distr 
%   prior.b0: prior for the regression coeff mean
%   prior.B0: prior for the regression coeff var-cov matrix
%   prior.v0: prior for the Inverted Gamma degrees of freedom
%   prior.d0: prior for the Inverted Gamma precision 
%   prior.n: number of observations
% **************************************************************
% Written by : DP on 11/26/2003                             

k=cols(X);
% Prior definition
% Transition matrix probabilities
% pii distr as a Beta(a,b)
prior.a=1; prior.b=20;  

% Linear regression model

prior.v0=eps;  
prior.d0=eps;     %increases the precision on the sigma2 estimates
prior.b0=zeros(k,1);
prior.B0=1000*eye(k);

