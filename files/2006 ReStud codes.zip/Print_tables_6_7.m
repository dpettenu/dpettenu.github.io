% PURPOSE: Print tables 6 and 7

clear all;

% load data and results
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\result_6_l1_PT_betadep.mat']);


% Print tables 6 and 7
out_file = [pwd,'\Results\Figures and tables\Table6.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end

beta_mean = reshape(mean(result.betas),2,7);
beta_std  = reshape(std(result.betas),2,7);
for i=2:2:14
    beta_prob_0(i/2) = mean(result.betas(:,i) == 1);
end
out_cell.betas_1 = [[{'Mean'};{'Std err'}],num2cell([beta_mean(1,:);beta_std(1,:)])];
out_cell.betas_2 = [[{'Mean'};{'Std err'};{'Pr(psi_j=0)'}],num2cell([beta_mean(2,:);beta_std(2,:);beta_prob_0])];

sigma2_mean = mean(result.sigma2);
sigma2_std  = std(result.sigma2);

out_cell.sigma2 = [[{'Mean'};{'Std err'}],num2cell([sigma2_mean;sigma2_std])];

xlswrite(out_file,[{'Regime'},num2cell((1:1:7))],'Table 6','A1');
xlswrite(out_file,{'Constant'},'Table 6','E2');

xlswrite(out_file,out_cell.betas_1,'Table 6','A3');
xlswrite(out_file,{'AR(1) coefficient'},'Table 6','E5');
xlswrite(out_file,out_cell.betas_2,'Table 6','A6');
xlswrite(out_file,{'Variances'},'Table 6','E9');
xlswrite(out_file,out_cell.sigma2,'Table 6','A10');

% Transition prob matrix is the same as table 4
[~,~,xcc] = xlsread([pwd,'\Results\Figures and tables\Table4.xlsx'],'Table 4','A12:H14');
xlswrite(out_file,{'Transition probability matrix'},'Table 6','E12');
xlswrite(out_file,xcc,'Table 6','A13');

% Hyperparameters
out_cell.b0 = [[{' '},{'Mean'},{'Std err'},{'2.5%'},{'97.5%'}];[[{'mu_0'};{'rho_0'};{'mu_1'};{'rho_1'}],num2cell([mean(result.mu(:,1));mean(result.rho(:,1));mean(result.mu(:,2));mean(result.rho(:,2))]),...
    num2cell([std(result.mu(:,1));std(result.rho(:,1));std(result.mu(:,2));std(result.rho(:,2))]),...
    num2cell([prctile(result.mu(:,1),2.5);prctile(result.rho(:,1),2.5);prctile(result.mu(:,2),2.5);prctile(result.rho(:,2),2.5)]),...
    num2cell([prctile(result.mu(:,1),97.5);prctile(result.rho(:,1),97.5);prctile(result.mu(:,2),97.5);prctile(result.rho(:,2),97.5)])]];

out_file = [pwd,'\Results\Figures and tables\Table7.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end

xlswrite(out_file,out_cell.b0,'Table 7','A1');
Eta_11 = result.Eta(1,1,:); Eta_11 = Eta_11(:);
Eta_22 = result.Eta(2,2,:); Eta_22 = Eta_22(:);
out_cell.Eta = [[{' '},{'Mean'},{'Std err'}];[[{'Eta(1,1)'};{'Eta(2,2)'}],num2cell([mean(Eta_11);mean(Eta_22)]),...
    num2cell([std(Eta_11);std(Eta_22)])]];

xlswrite(out_file,out_cell.Eta,'Table 7','A7');

out_cell.v0d0 = [[{' '},{'Mean'},{'Std err'},{'2.5%'},{'97.5%'}];[[{'v0'};{'d0'}],num2cell([mean(result.v0);mean(result.d0)]),...
    num2cell([std(result.v0);std(result.d0)]),...
    num2cell([prctile(result.v0,2.5);prctile(result.d0,2.5)]),...
    num2cell([prctile(result.v0,97.5);prctile(result.d0,97.5)])]];
xlswrite(out_file,out_cell.v0d0,'Table 7','A11');





