% PURPOSE: Print table 8

% Load the data
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\All forecasts.mat']);


% Rearrange y data to be organized by year (1968 to 2001) on the rows and by
% forecast horizon on the columns (12 to 60 months ahead)

yff       = NaN(2001-1968+1,5);
forc_year = zeros(2001-1968+1,5);

for fh=[12 24 36 48 60]
    for t=1968:1:2002-(fh/12)
        forc_year(t-1968+1,fh/12) = t + (fh/12);
        yff(t-1968+1,fh/12)=y(ical(t,12,cstr)+fh);
    end
end

index_70s = zeros(2001-1968+1,5);
index_80s = zeros(2001-1968+1,5);
index_90s = zeros(2001-1968+1,5);

for fh=[12 24 36 48 60]
    index_70s(:,fh/12) = forc_year(:,fh/12)>=1968 & forc_year(:,fh/12)<1980;
    index_80s(:,fh/12) = forc_year(:,fh/12)>=1980 & forc_year(:,fh/12)<1990;
    index_90s(:,fh/12) = forc_year(:,fh/12)>=1990;
end


% Now rmse calculations, full sample and subsamples
out_cell_fs = NaN(4,8,5);

for fh=[12 24 36 48 60]

    % Composite
    out_cell_fs(1,1,fh/12) = sqrt(nanmean((mean(YPD_c(:,:,fh/12),1)'-yff(:,fh/12)).^2));
    out_cell_fs(2,1,fh/12) = sqrt(nanmean((mean(YPD_c(:,index_70s(:,fh/12)==1,fh/12),1)'-yff(index_70s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(3,1,fh/12) = sqrt(nanmean((mean(YPD_c(:,index_80s(:,fh/12)==1,fh/12),1)'-yff(index_80s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(4,1,fh/12) = sqrt(nanmean((mean(YPD_c(:,index_90s(:,fh/12)==1,fh/12),1)'-yff(index_90s(:,fh/12)==1,fh/12)).^2));
    % Last regime
    out_cell_fs(1,2,fh/12) = sqrt(nanmean((mean(YPD_lr(:,:,fh/12),1)'-yff(:,fh/12)).^2));
    out_cell_fs(2,2,fh/12) = sqrt(nanmean((mean(YPD_lr(:,index_70s(:,fh/12)==1,fh/12),1)'-yff(index_70s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(3,2,fh/12) = sqrt(nanmean((mean(YPD_lr(:,index_80s(:,fh/12)==1,fh/12),1)'-yff(index_80s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(4,2,fh/12) = sqrt(nanmean((mean(YPD_lr(:,index_90s(:,fh/12)==1,fh/12),1)'-yff(index_90s(:,fh/12)==1,fh/12)).^2));
%     % Random level
%     out_cell_fs(1,3,fh/12) = sqrt(nanmean((mean(YPD_rlar(:,:,fh/12),1)'-yff(:,fh/12)).^2));
%     out_cell_fs(2,3,fh/12) = sqrt(nanmean((mean(YPD_rlar(:,index_70s(:,fh/12)==1,fh/12),1)'-yff(index_70s(:,fh/12)==1,fh/12)).^2));
%     out_cell_fs(3,3,fh/12) = sqrt(nanmean((mean(YPD_rlar(:,index_80s(:,fh/12)==1,fh/12),1)'-yff(index_80s(:,fh/12)==1,fh/12)).^2));
%     out_cell_fs(4,3,fh/12) = sqrt(nanmean((mean(YPD_rlar(:,index_90s(:,fh/12)==1,fh/12),1)'-yff(index_90s(:,fh/12)==1,fh/12)).^2));
%     % Random variance
%     out_cell_fs(1,4,fh/12) = sqrt(nanmean((mean(YPD_rvar(:,:,fh/12),1)'-yff(:,fh/12)).^2));
%     out_cell_fs(2,4,fh/12) = sqrt(nanmean((mean(YPD_rvar(:,index_70s(:,fh/12)==1,fh/12),1)'-yff(index_70s(:,fh/12)==1,fh/12)).^2));
%     out_cell_fs(3,4,fh/12) = sqrt(nanmean((mean(YPD_rvar(:,index_80s(:,fh/12)==1,fh/12),1)'-yff(index_80s(:,fh/12)==1,fh/12)).^2));
%     out_cell_fs(4,4,fh/12) = sqrt(nanmean((mean(YPD_rvar(:,index_90s(:,fh/12)==1,fh/12),1)'-yff(index_90s(:,fh/12)==1,fh/12)).^2));
    % TVP
    out_cell_fs(1,5,fh/12) = sqrt(nanmean((YPD_tvp(:,fh/12)-yff(:,fh/12)).^2));
    out_cell_fs(2,5,fh/12) = sqrt(nanmean((YPD_tvp(index_70s(:,fh/12)==1,fh/12)-yff(index_70s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(3,5,fh/12) = sqrt(nanmean((YPD_tvp(index_80s(:,fh/12)==1,fh/12)-yff(index_80s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(4,5,fh/12) = sqrt(nanmean((YPD_tvp(index_90s(:,fh/12)==1,fh/12)-yff(index_90s(:,fh/12)==1,fh/12)).^2));
    % Recursive OLS
    out_cell_fs(1,6,fh/12) = sqrt(nanmean((YPD_rec(:,fh/12)-yff(:,fh/12)).^2));
    out_cell_fs(2,6,fh/12) = sqrt(nanmean((YPD_rec(index_70s(:,fh/12)==1,fh/12)-yff(index_70s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(3,6,fh/12) = sqrt(nanmean((YPD_rec(index_80s(:,fh/12)==1,fh/12)-yff(index_80s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(4,6,fh/12) = sqrt(nanmean((YPD_rec(index_90s(:,fh/12)==1,fh/12)-yff(index_90s(:,fh/12)==1,fh/12)).^2));
    % Rolling window 5 yrs
    out_cell_fs(1,7,fh/12) = sqrt(nanmean((YPD_roll_60m(:,fh/12)-yff(:,fh/12)).^2));
    out_cell_fs(2,7,fh/12) = sqrt(nanmean((YPD_roll_60m(index_70s(:,fh/12)==1,fh/12)-yff(index_70s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(3,7,fh/12) = sqrt(nanmean((YPD_roll_60m(index_80s(:,fh/12)==1,fh/12)-yff(index_80s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(4,7,fh/12) = sqrt(nanmean((YPD_roll_60m(index_90s(:,fh/12)==1,fh/12)-yff(index_90s(:,fh/12)==1,fh/12)).^2));
    % Rolling window 10 yrs
    out_cell_fs(1,8,fh/12) = sqrt(nanmean((YPD_roll_120m(:,fh/12)-yff(:,fh/12)).^2));
    out_cell_fs(2,8,fh/12) = sqrt(nanmean((YPD_roll_120m(index_70s(:,fh/12)==1,fh/12)-yff(index_70s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(3,8,fh/12) = sqrt(nanmean((YPD_roll_120m(index_80s(:,fh/12)==1,fh/12)-yff(index_80s(:,fh/12)==1,fh/12)).^2));
    out_cell_fs(4,8,fh/12) = sqrt(nanmean((YPD_roll_120m(index_90s(:,fh/12)==1,fh/12)-yff(index_90s(:,fh/12)==1,fh/12)).^2));
end

% Write to excel file
out_file = [pwd,'\Results\Figures and tables\Table8.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end

xlswrite(out_file,[{' '},{'Composite'},{'Last regime'},{'Random level'},{'Random variance'},{'TVP'},{'Rec OLS'},{'Rolling win 5 yrs'},{'Rolling win 10 yrs'}],'Results','A1');
xlswrite(out_file,{'h = 12'},'Results','E2');
xlswrite(out_file,[[{'1968-2002'};{'1970s'};{'1980s'};{'1990s'}],num2cell(out_cell_fs(:,:,1))],'Results','A3');
xlswrite(out_file,{'h = 24'},'Results','E8');
xlswrite(out_file,[[{'1968-2002'};{'1970s'};{'1980s'};{'1990s'}],num2cell(out_cell_fs(:,:,2))],'Results','A9');
xlswrite(out_file,{'h = 36'},'Results','E14');
xlswrite(out_file,[[{'1968-2002'};{'1970s'};{'1980s'};{'1990s'}],num2cell(out_cell_fs(:,:,3))],'Results','A15');
xlswrite(out_file,{'h = 48'},'Results','E20');
xlswrite(out_file,[[{'1968-2002'};{'1970s'};{'1980s'};{'1990s'}],num2cell(out_cell_fs(:,:,4))],'Results','A21');
xlswrite(out_file,{'h = 60'},'Results','E26');
xlswrite(out_file,[[{'1968-2002'};{'1970s'};{'1980s'};{'1990s'}],num2cell(out_cell_fs(:,:,5))],'Results','A27');



