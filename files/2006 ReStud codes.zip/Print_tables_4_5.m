% PURPOSE: Print tables 4 and 5

clear all;

% load data and results
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\result_6_l1_PT.mat']);

out_cell = output_hmc(result,cstr);
close all;

% Print tables 4 and 5
out_file = [pwd,'\Results\Figures and tables\Table4.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end

xlswrite(out_file,[{'Regime'},num2cell((1:1:7))],'Table 4','A1');
xlswrite(out_file,{'Constant'},'Table 4','E2');
xlswrite(out_file,out_cell.betas(2:end,:,1),'Table 4','A3');
xlswrite(out_file,{'AR(1) coefficient'},'Table 4','E5');
xlswrite(out_file,out_cell.betas(2:end,:,2),'Table 4','A6');
xlswrite(out_file,{'Variances'},'Table 4','E8');
xlswrite(out_file,out_cell.sigma2(2:end,:),'Table 4','A9');
xlswrite(out_file,{'Transition probability matrix'},'Table 4','E11');
xlswrite(out_file,out_cell.P(2:end,:),'Table 4','A12');

out_file = [pwd,'\Results\Figures and tables\Table5.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end

xlswrite(out_file,out_cell.b0,'Table 5','A1');
xlswrite(out_file,out_cell.B0,'Table 5','A5');
xlswrite(out_file,out_cell.v0d0,'Table 5','A9');
