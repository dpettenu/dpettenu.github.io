function result=ch2_hidmkvch_PT(y,X,M,I,varargin)

% PURPOSE: This program uses the hidden markov chain of Chib 1998 to compute the
%         unknown multiple break points for the normal inverted gamma case
%         in the hierarchical setting for the regime parameters (New
%         parametrization according to Pesaran and Timmermann) and
%         hierachical structure for P.
% *************************************************************************
% USAGE: result=ch_hidmkvch(y,X,M,I)
%     or result=ch_hidmkvch(y,X,M,I,2) to start with random draws
%     or result=ch_hidmkvch(y,X,M,I,result_old) to use a old chain last values
% *************************************************************************
% INPUT:
% y: dep variable
% X: independent variables
% M: number of breaks to look for
% I: number of Gibbs samplings
% result_old: (optional) load the old result and keep going
% *************************************************************************
% Written by DP on 01/12/03

global a b mub Vb rho R ha0 hb0 hc0 hd0 rho0;

% Input check
if nargin == 5
    if isstruct(varargin{1})==1
      result_old=varargin{1}; flag=1;
  else 
      flag=varargin{1};
  end
elseif nargin ==4
    flag=0; %standard value
else
    error('wrong number of input');
end

[N,k]=size(X); k=k-1;

% --------------------------------------------------
% Prior definition: 
% --------------------------------------------------

priordef;

% Display prior
% disp('Regression parameters');  disp('Mean'); ;
% disp('mu_b:  '); disp(mub); 
% disp('V_b:  '); disp(Vb); 
% disp('Variance'); 
% disp('R:  ');  disp(R); 
% disp(['rho:  ' num2str(rho)]);  
% disp('Error term variance'); 
% disp(['c_0:  ' num2str(hc0)]);  disp(['d_0:  ' num2str(hd0)]); 
% disp(['rho_0:  ' num2str(rho0)]); disp(' '); 

% --------------------------------------------------
% Some initilization for the chain 
% --------------------------------------------------

%States 
pst=zeros(M+1,N,I); %prob of the states
s=zeros(N,I);       %observed states
%Parameter vectors under the M+1 regimes
betas=zeros(I,(M+1)*(k+1));
sigma2=zeros(I,M+1);
%Prior hyperparameters 
%(mean var-covar matrix)
b0=zeros(I,k+1);
B0=zeros(k+1,k+1,I);
%Variance
v0=zeros(I,1);
d0=zeros(I,1);
%Transition probability matrix
ap=zeros(I,1);
bp=zeros(I,1);
% Transition probability matrix
P=zeros(M+1,M+1,I);
% For the likelihood f at each iteration
llikf=zeros(I,1);
% For the acceptance ratio in the M-H step inside the Gibbs sampler
pc1=zeros(I,1); pc2=zeros(I,1); pc3=zeros(I,1);

% --------------------------------------------------
% Set initial values for the Gibbs sampling
% --------------------------------------------------

if flag == 1
    % 1) Load star values from previous results as to continue a previous
    % chain (note: in this case set dr to 0, no burn in observation)
    betas(1,:)=result_old.betas(end,:);
    sigma2(1,:)=result_old.sigma2(end,:);
    b0(1,:)=result_old.b0(end,:);
    B0(:,:,1)=result_old.B0(:,:,end);
    P(:,:,1)=result_old.P(:,:,end);
    v0(1)=result_old.v0(end,:);
    d0(1)=result_old.d0(end,:);
    ap(1)=result_old.ap(end,:);
    bp(1)=result_old.bp(end,:);
    s(:,1)=result_old.s(:,end);
elseif flag ==0
    % 2) External procedure to compute the initial starting values
    [betas(1,:),sigma2(1,:)]=strvls(y,X,M,1);
elseif flag == 2
    % 3) Random initial values
    betas(1,:)=randn(1,(M+1)*(k+1));
    sigma2(1,:)=rand(1,M+1);
end

if flag ~= 1 % only if I am not continuing an old chain
    % Meta distribution hyperparameters
    b0(1,:)=randn(1,k+1);
    B0(:,:,1)=diag(rand(1,k+1));
    v0(1)=rand; d0(1)=rand;
    ap(1)=rand; bp(1)=rand;
    %Transition prob matrix (random initialization given the structure
    %constraints)
    % P(:,:,1)=rand(M+1,M+1).*eye(M+1,M+1);
    P(:,:,1)=0.5.*eye(M+1,M+1);;  %equal prob of staying or moving from each regime
    for i=1:M
        P(i,i+1,1)=1-P(i,i,1);
    end
    P(M+1,M+1,1)=1; %prob of remaining in the last state once reached is 1
end

% --------------------------------------------------
%The Gibbs sampling starts here
% --------------------------------------------------

bar=waitbar(0,'Fully Hierarchical Hidden Markov Chain' );
for j=2:I
    % 1. Sample the state probabilities and the states
    [pst(:,:,j),s(:,j),llikf(j)]=drawstates(y,X,M,betas(j-1,:),sigma2(j-1,:),P(:,:,j-1));

    % 2. Sample regression parameters

    %For each regime draw from the posterior distr of its parameters
    incr=s(:,j)-lag(s(:,j),1);
    bks=[find(incr==1)' N+1];
%     [betas(j,:),sigma2(j,:),b0(j,:),B0(:,:,j),v0(j,:),d0(j,:),pc(j)]=...
%     ch_gibbstep(y,X,bks,sigma2(j-1,:),b0(j-1,:),B0(:,:,j-1),v0(j-1,:),d0(j-1,:));
    betas(j,:)=drawbetas_PT(y,X,bks,sigma2(j-1,:),b0(j-1,:),B0(:,:,j-1));
    sigma2(j,:)=drawsigma2(y,X,bks,betas(j,:),v0(j-1,:),d0(j-1,:));
    b0(j,:)=drawb0_PT(y,X,bks,betas(j,:),B0(:,:,j-1));
    B0(:,:,j)=drawcb0(y,X,bks,betas(j,:),b0(j,:));
    d0(j,:)=drawd0(y,X,bks,sigma2(j,:),v0(j-1,:));
    [v0(j,:),pc1(j)]=drawv0(y,X,sigma2(j,:),d0(j,:),v0(j-1,:),tune1);
    % 3. Sample Transition Probability matrix 
    P(:,:,j)=draw_hP(y,X,M,s(:,j),ap(j-1),bp(j-1));
    [ap(j,:),pc2(j)]=drawap(y,X,P(:,:,j),ap(j-1,:),bp(j-1,:),tune2);
    [bp(j,:),pc3(j)]=drawbp(y,X,P(:,:,j),ap(j,:),bp(j-1,:),tune2);
    % 4. Goto 1
    waitbar(j/I);
end %end of gibb sampling loop
close(bar);

% --------------------------------------------------
%Store the MCMC drawing into the structure result 
% --------------------------------------------------

if flag ~= 1
    dr=round(I/4); %trim the first .. percent of draws
else
    dr=0;
end
result.betas=betas(dr+1:end,:);
result.sigma2=sigma2(dr+1:end,:);
result.P=P(:,:,dr+1:end);
result.pst=pst(:,:,dr+1:end);
result.s=s(:,dr+1:end);
result.b0=b0(dr+1:end,:);
result.B0=B0(:,:,dr+1:end);
result.v0=v0(dr+1:end,:);
result.d0=d0(dr+1:end,:);
result.ap=ap(dr+1:end,:);
result.bp=bp(dr+1:end,:);
result.pc=pc1(dr+1:end,:);
result.pc2=pc2(dr+1:end,:);
result.pc3=pc3(dr+1:end,:);
result.llikf=llikf(dr+1:end);