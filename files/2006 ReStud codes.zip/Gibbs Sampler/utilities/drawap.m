function [ap_n,pc]=drawap(Y,X,P_n,ap_o,bp_o,tune)

% PURPOSE: computes one Gibbs sampling loop for v0

global ha0 hb0;

ap_st=gamm_rnd(1,tune,tune/ap_o);
Ja_ne=gamm_pdf2(ap_st,tune,tune/ap_o);
Ja_ol=gamm_pdf2(ap_o,tune,tune/ap_st);
pii=diag(P_n);
p_al_st=prod(beta_pdf(pii(1:end-1),ap_st,bp_o)) * gamm_pdf2(ap_st,ha0,hb0);
p_al_ol=prod(beta_pdf(pii(1:end-1),ap_o,bp_o)) * gamm_pdf2(ap_o,ha0,hb0);
r=min( (p_al_st/Ja_ne) / (p_al_ol/Ja_ol),1);
accept=bino_rnd(1,r,1,1);
if accept == 1
    ap_n=ap_st;
    pc=1;
else
    ap_n=ap_o;
    pc=0;
end