function y=prob_pkp2(result)

%PURPOSE: estimates posterior prbability of regime K+2 from the original
% Gibbs sampling estimates
% -------------------------------------------------------------------------
% USAGE: y=prob_pkp2(result)
% -------------------------------------------------------------------------
% written by DP on 12 apr 2004

ap=result.ap;
bp=result.bp;  %load gibbs output for the posterior hyperpar of P

I=rows(ap); % # of Gibbs sampling iterations
% Initialize the output var
y=zeros(I,1);
for j=1:I
    % Fill in the p_kp2 at the jth Gibbs sampling interation
    y(j)=beta_rnd(1,ap(j),bp(j));
end

