function [betas,sig2]=strvls(Y,X,M,opt)

% PURPOSE: this function computes the starting values for the Hidden Markov
% chain model in order to have the ols result (coeffs and variances)for the 
% equally splitted subsamples of the original data 
% *************************************************************************
% USAGE: [betas,sig2]=strvls(Y,X,M,opt)
% *************************************************************************
% INPUT:
% Y: (n x 1) vector of independent variables
% X: (n x k) matrix of independent variables
% M: number of regimes allowed
% opt: option to allow for different models
%     =1 i.e. all regressor coeffs and variance change
%     =2 i.e. all regressor coeffs change and variance stays const over regimes
%     =3 i.e. only the constant coeff changes and variance changes
%     =4 i.e. only the constant coeff changes and variance stay constant
%             over regimes
%     =5 i.e. only the variance change
%
% OUTPUT:
% betas: (1 x (M+1)*k) vector of starting values for the regression coeffs
% sig2: (1 x (M+1)) vector of starting values for the variaces 
% % **************************************************************************
% Written by DP on 11/16/03

[N,k]=size(X);

if rem(N,(M+1)) > 0
    lb=[0 floor((1:(M)).*(N/(M+1)))] + 1;
    ub=[lb(2:end)-1 N];
elseif rem(N,M+1) == 0
    lb=[0 (1:(M)).*(N/(M+1))] + 1;
    ub=(1:M+1).*(N/(M+1));
end

if opt==1
    betas=zeros(1,k*(M+1));
    sig2=zeros(1,M+1);
    for i=1:M+1
        res=ols(Y(lb(i):ub(i)),X(lb(i):ub(i),:));
        betas(1+(i-1)*(k):i*(k))=res.beta';
        sig2(i)=res.sige;
    end
elseif opt==2
    betas=zeros(1,k*(M+1));
    sig2=zeros(1,1);
    kk = [1 (seqa(1,1,M)'*floor(N/(M+1))) (N+1)];
    [Xs,iVar] = indBrkL_ex(X,kk);
    res=ols(Y,Xs);
    betas=res.beta';
    sig2=res.sige;
elseif opt==3
    betas=zeros(1,M+1+k);
    sig2=zeros(1,M+1);
    kk = [1 (seqa(1,1,M)'*floor(N/(M+1))) (N+1)];
    [ei,iVar] = indBrkL_nt(kk);    Xs = [ei X(:,2:end)];
    res=ols(Y,Xs);
    betas=res.beta';
    err=Y-Xs*betas';
    for i=1:M+1
        ui=err(kk(i):kk(i+1)-1);
        sig2(i)=(ui'*ui) / (rows(Y)-k);
    end
elseif opt==4
    betas=zeros(1,M+1+k);
    sig2=zeros(1,M+1);
    kk = [1 (seqa(1,1,M)'*floor(N/(M+1))) (N+1)];
    [ei,iVar] = indBrkL_nt(kk);    Xs = [ei X(:,2:end)];
    res=ols(Y,Xs);
    betas=res.beta';
    sig2=res.sige;
elseif opt==5
    betas=zeros(1,1+k);
    sig2=zeros(1,M+1);
    kk = [1 (seqa(1,1,M)'*floor(N/(M+1))) (N+1)];
    res=ols(Y,X);
    betas=res.beta';
    err=Y-X*betas';
    for i=1:M+1
        ui=err(kk(i):kk(i+1)-1);
        sig2(i)=(ui'*ui) / (rows(ui)-k);
    end
end
    
