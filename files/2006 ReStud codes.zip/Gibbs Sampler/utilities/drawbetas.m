function betas_n=drawbetas(Y,X,bks,sigma2_o,b0_o,B0_o)

% PURPOSE: computes one Gibbs sampling loop for the betas

J=length(bks)-1;
nr=cols(X);
b0_o=b0_o';
betas_n=zeros(1,nr*J);
for j=1:J
    Yi=Y(bks(j):bks(j+1)-1,:);
    Xi=X(bks(j):bks(j+1)-1,:);
    Bn=invpd(invpd(B0_o) + (1/sigma2_o(j))*(Xi'*Xi));
    m=Bn*(invpd(B0_o)*b0_o + (1/sigma2_o(j))*(Xi'*Yi));
    betas_n(1+(j-1)*nr:j*nr)=mvnrnd(m,Bn);
end
