function out_cell=output_hmc(result,varargin)

% PURPOSE: Shows some output from the hidden markov chain method to
%          detect multiple (M) break points (hierarchical setting)
% ***************************************************************
% USAGE: output_hmc(result,varargin)
% ***************************************************************
% INPUT:
%
% result: is a the structure output from hidmkvch_norm whose field are
%   result.betas: regression coefficients for all the M=1 regimes
%   result.sigma2: regression variances for all the M+1 regimes
%   result.P: tranasition prob matrix
%   result.pst: posterior prob of each observation to be in a 
%               particular state 
%   result.s: state variable for each obs telling in which state 
%             the obs is
%   result.b0: mean of the hyperpars
%   resutl.B0: var covar matrix of the hyperpars
% cstr: calendar strucuture if the data investigated is a time series
%       (optional)
% tbeg: beginning time of the plot (optional, default=1)
% tend: ending time of the plot (optional, default=end of sample)
%
% **************************************************************
% Written by : DP on 11/11/2003                             
 
betas=result.betas;
sigma2=result.sigma2;
P = result.P;
pst=result.pst;
s=result.s;
b0=result.b0;
B0=result.B0;
fl=0;
if isfield(result,'v0') == 1
    v0=result.v0;
    d0=result.d0;
    pc1=result.pc;
    fl=1;
end
if isfield(result,'ap') == 1
    ap=result.ap;
    bp=result.bp;
    pc2=result.pc2;
    pc3=result.pc3;
    fl=2;
end
llikf=result.llikf;

nr=cols(b0);
N=rows(s); %number of obs
I=rows(betas); %number of simulations
M=cols(sigma2)-1; %number of breaks

if nargin == 2
    cstr=varargin{1};
    tbeg=1;
    tend=N;    
elseif nargin == 4
    cstr=varargin{1};
    tbeg=varargin{2};
    tend=varargin{3};
elseif (nargin ~= 1) & (nargin ~= 2) & (nargin ~= 4) 
    error('wrong number of input for the function')
end
dr=0; %no burn in obs
m_b=reshape(mean(betas(dr+1:I,:))',nr,M+1);
sterr_b=reshape(std(betas(dr+1:I,:))',nr,M+1);
sterr_s2=std(sigma2(dr+1:I,:))';
confint_s2=conf(sigma2(dr+1:I,:));
sterr_b0=std(b0(dr+1:I,:))';
confint_b0=conf(b0(dr+1:I,:));
sterr_B0=std(B0(:,:,dr+1:I,:),0,3);

[~,chp] = Plot_chp_rec(result,cstr);
disp(' ');
disp(' ');
%Display some statistics about the gibbs draws
disp('******************************************');
disp(' ');
disp('Descriptive statistics of the Gibbs draws');

info.rnames=strvcat('Regimes','Mean','Std error');
Reg = [];
for i=1:M+1
   tmp = ['Reg ',num2str(i)];
   Reg = strvcat(Reg,tmp);
end;
info.cnames=Reg;
disp(' ');
disp('*************Parameters*******************');
disp(' ');
for i=1:nr
    disp(['        Variable' num2str(i)]);
    disp(' ');
    mprint([m_b(i,:);sterr_b(i,:)],info);
    disp(' ');
    out_cell.betas(:,:,i) = [cellstr(info.rnames), [cellstr(info.cnames)';num2cell([m_b(i,:);sterr_b(i,:)])]];
end

disp('*************Variances*******************');
disp(' ');
mprint([mean(sigma2(dr+1:I,:)); sterr_s2' ],info);
out_cell.sigma2 = [cellstr(info.rnames), [cellstr(info.cnames)';num2cell([mean(sigma2(dr+1:I,:)); sterr_s2' ])]];
disp(' ');
disp('*********Transition prob matrix*************');
disp(' ');
meanP=diag(mean(P(:,:,dr+1:I),3));
stdP=diag(std(P(:,:,dr+1:I),1,3));
chp_diff = [chp(1,:);chp(2:end,:) - chp(1:end-1,:)];
mean_duration = [round(mean(chp_diff,2));NaN];
info.rnames=strvcat('Regimes','Mean','Std error','Mean duration');
mprint([meanP';stdP';mean_duration'],info);
out_cell.P = [cellstr(info.rnames), [cellstr(info.cnames)';num2cell([meanP';stdP';mean_duration'])]];

disp(' ');
disp('******************************************');
disp('      Meta distribution hyperparameters');
disp('******************************************');
disp(' ');
disp('******************Mean*******************');
disp(' ');
disp('    Mean      Std error    95 conf interv');
disp([mean(b0(dr+1:I,:))' sterr_b0 confint_b0 ]);
info.cnames = strvcat('Mean','Std err','2.5%','97.5%');
info.rnames = strvcat(' ','b_0(1)','b_0(2)');
out_cell.b0 = [cellstr(info.rnames), [cellstr(info.cnames)';num2cell([mean(b0(dr+1:I,:))' sterr_b0 confint_b0 ])]];
disp(' ');
disp('*************Variances*******************');
disp(' ');
disp('    Mean      Std error ');
disp([diag(mean(B0(:,:,dr+1:I),3)) diag(sterr_B0) ]);
info.cnames = strvcat('Mean','Std err');
info.rnames = strvcat(' ','B_0(1,1)','B_0(2,2)');
out_cell.B0 = [cellstr(info.rnames), [cellstr(info.cnames)';num2cell([diag(mean(B0(:,:,dr+1:I),3)) diag(sterr_B0) ])]];

disp(' ');
if fl == 1
    disp(' Error variance parameters ');
    disp(' ');
    info.rnames=strvcat(' ','v0','d0');
    info.cnames=strvcat('Mean','Std. err.','2.5%','97.5%');
    disp(' ');
    dd=[mean(v0(dr+1:I,:)) std(v0(dr+1:I,:)) prctile(v0(dr+1:I,:),[2.5 97.5]);...
        mean(d0(dr+1:I,:)) std(d0(dr+1:I,:)) prctile(d0(dr+1:I,:),[2.5 97.5])];    
    mprint(dd,info);
    out_cell.v0d0 = [cellstr(info.rnames), [cellstr(info.cnames)';num2cell(dd)]];
    disp(' ');
    disp(['Acceptance percentage in the M-H steps: ' num2str(mean(pc1))]);
    disp(' ');
end
if fl == 2
    disp(' Transition prob parameters ');
    disp(' ');
    info.rnames=strvcat(' ','ap','bp');
    info.cnames=strvcat('Mean','Std. err.','2.5%','97.5%');
    disp(' ');
    dd=[mean(ap(dr+1:I,:)) std(ap(dr+1:I,:)) prctile(ap(dr+1:I,:),[2.5 97.5]);...
        mean(bp(dr+1:I,:)) std(bp(dr+1:I,:)) prctile(bp(dr+1:I,:),[2.5 97.5])];    
    mprint(dd,info);
    disp(' ');
    disp(['Acceptance percentage in the M-H steps for ap: ' num2str(mean(pc2))]);
    disp(['Acceptance percentage in the M-H steps for bp: ' num2str(mean(pc3))]);
    disp(' ');
end
disp(['Mean Log likelihood: ' num2str(mean(llikf))]);
disp(' ');
% Graph
if nargout == 1 %then graph
    gr=1;
    if nargin == 1
        for i=1:M+1
            x=(1:N)';
            plot(x,mean(pst(i,:,dr+1:I),3),'b-o');
            xlim([1 N]);
            hold on;
        end
        hold off;
        title('Posterior probability of s_t=k given binary data Y_n');
    else
        nobs=N;
       yrs = zeros(nobs,1);
       mth = zeros(nobs,1);
       out = cstr;  %use old calendar for the graph purpose

       %Create the sequences for years and months for the graph
       beg_yr = floor(tbeg/cstr.freq) +  cstr.beg_yr;
       beg_mth = rem(tbeg,cstr.freq) + cstr.beg_per;
       if beg_mth > cstr.freq
            beg_yr=beg_yr+1;
            beg_mth=beg_mth-cstr.freq; 
        end
        for i=1:nobs;
        yrs(i,1) = beg_yr;
        mth(i,1) = beg_mth;
        beg_mth = beg_mth+1;
        if beg_mth > cstr.freq
            beg_yr = beg_yr+1;
            beg_mth = 1;
        end
        end
        ydigit = 'mmmyy';  
        for i=1:M+1
            x=(1:N)';
            plot(datenum(yrs,mth,1),mean(pst(i,:,dr+1:I),3),'b-o');
            hold on;
        end
        hold off;
        set(gca,'tickdir','in');
        datetick('x',ydigit);
        xlim([datenum(yrs(1),mth(1),1) datenum(yrs(end),mth(end),1)]);
    
    end
    %create the legend
    for i=1:M+1
        if i==1
            str=['st=' num2str(i)];
        else
            str=strvcat(str,['st=' num2str(i)]);
        end
    end
    legend(str);
    xlabel('Time');
    ylabel('Pr(s_t|Y_n)');

end






        

