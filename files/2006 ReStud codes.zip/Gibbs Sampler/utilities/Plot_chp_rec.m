function [break_dates,chp]=Plot_chp_rec(result,varargin)

% PURPOSE: A function to print nice graphs of the posterior 
% probability of break occurance       
% ***************************************************************
% USAGE: findchp_rec(result,varargin)
% ***************************************************************
% INPUT:
%
% result: is a the structure output from hidmkvch_norm whose field are
%   result.betas: regression coefficients for all the M=1 regimes
%   result.sigma2: regression variances for all the M+1 regimes
%   result.P: tranasition prob matrix
%   result.pst: posterior prob of each observation to be in a 
%               particular state 
%   result.s: state variable for each obs telling in which state 
%             the obs is
% cstr: calendar strucuture if the data investigated is a time series
%       (optional)
% tbeg: beginning time of the plot (optional, default=1)
% tend: ending time of the plot (optional, default=end of sample)
%
% OUTPUT:
% chp: break occurance for each Gibbs draws
% plot of the break point weights
% **************************************************************
% Written by : DP on 11/11/2003                             

betas=result.betas;
sigma2=result.sigma2;
P=result.P;
pst=result.pst;
s=result.s;

N=rows(s); %number of obs
I=rows(betas); %number of simulations
M=rows(P)-1; %number of breaks

if nargin == 2
    cstr=varargin{1};
    tbeg=0;
    tend=N;    
elseif nargin == 4
    cstr=varargin{1};
    tbeg=varargin{2};
    tend=varargin{3};
elseif (nargin ~= 1) & (nargin ~= 2) & (nargin ~= 4) 
    error('wrong number of input for the function')
end



%Find the change points
chp=zeros(I-1,M);  %matrix to store the break points for each iteration of the Gibbs sampler

incr=s-lag(s,1);
incr=incr(2:end,2:end);  %trim first row and first column 
if sumc(incr < 0)  >0
    error('the states are not increasing over time');
end
if sumc(incr > 1)  >0
    error('the states are not increasing smoothly over time');
end
if sum(incr)  ~= M
    error('more than necessary breaks detected');
end

[i,j]=find(incr==1);

chp=reshape(i,M,I-1);
wet = wetbreak(chp',N);

%some graphs
if nargout == 0
    h = figure;
end
disp(' ');    
disp('Break points:');
disp(' ');
if nargin == 1
    disp(mean(chp,2));
    for i=1:M
        [ii,jj]=max(wet(:,i));
%        disp(tsdate(cstr,jj));
        subplot(M,1,i);  plot(wet(:,i));
        xlim([1 N]);
        title(['Posterior probability of \tau' num2str(i) '=t']);
    end
    
else  
    nobs=N;
    yrs = zeros(nobs,1);
    mth = zeros(nobs,1);
    out = cstr;  %use old calendar for the graph purpose

    %Create the sequences for years and months for the graph
    beg_yr = floor(tbeg/cstr.freq) +  cstr.beg_yr;
    beg_mth = rem(tbeg,cstr.freq) + cstr.beg_per;
    if beg_mth > cstr.freq
        beg_yr=beg_yr+1;
        beg_mth=beg_mth-cstr.freq; 
    end
    for i=1:nobs;
        yrs(i,1) = beg_yr;
        mth(i,1) = beg_mth;
        beg_mth = beg_mth+1;
        if beg_mth > cstr.freq
            beg_yr = beg_yr+1;
            beg_mth = 1;
        end
    end
    ydigit = 'mmmyy';  
    
    for i=1:M
        [ii,jj]=max(wet(:,i));
        disp(tsdate(cstr,jj+tbeg));
        break_dates(i) = cellstr(tsdate(cstr,jj+tbeg));
        if nargout==0 %then display graph
            subplot(M,1,i);  plot(datenum(yrs,mth,1),wet(:,i));
            datetick('x',ydigit);
            xlim([datenum(yrs(1),mth(1),1) datenum(yrs(end),mth(end),1)]);
            if i == M
                set(gcf,'position',get(0,'screensize'))
                set(gcf,'PaperPositionMode','auto')
                print('-depsc','-tiff','-r600',[pwd,'\Results\Figures and tables\Figure2.eps']);
            end
        end
    end
       
end    

