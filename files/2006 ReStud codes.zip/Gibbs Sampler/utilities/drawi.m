function cdf=drawi(pdf)

% PURPOSE: computes empirical cdf from input pdf
% -----------------------------------------------
% USAGE: cdf=drawi(pdf)
% -----------------------------------------------
% written by DP on 22 feb 2004

% create a grid of ngrd points
ngrd=100;
rmin=min(pdf);
rmax=max(pdf);
grid=linspace(rmin,rmax,ngrd);
cdf=zeros(ngrd,1);
for i=1:ngrd
    cdf(i)=mean(pdf <= grid(i));
end
plot(grid,cdf);