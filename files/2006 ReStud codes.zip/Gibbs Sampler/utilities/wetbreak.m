function kWet = wetbreak(kMat,n);

% PURPOSE: Computes the weights for each break point
% *******************************************************
% USAGE kWet = wetbreak(kMat,n)
% *******************************************************
% INPUT
%
% kMat: nofb x nofs, Gibbs draws            
% n: Length of the sample considered     
% OUTPUT
%
% kMat: distribution of break points        
% *******************************************************
%  Written by DP on 11/11/03 after Jeffrey Wang gauss code

nofb = cols(kMat);       % number of breaks      @
nofs = rows(kMat);       % number of simulations @
kWet = zeros(n,nofb);
tIndex = seqa(1,1,n);

i = 1; 
while i <= nofb;
    for j=1:rows(tIndex)
        kWet(j,i) = sumc(kMat(:,i) == tIndex(j))/nofs;
    end
    i = i + 1;
end

