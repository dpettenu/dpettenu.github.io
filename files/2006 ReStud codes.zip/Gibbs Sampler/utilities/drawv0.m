function [v0_n,pc]=drawv0(Y,X,sigma2_n,d0_n,v0_o,tune)

% PURPOSE: computes one Gibbs sampling loop for v0

global rho0;

v0_st=gamm_rnd(1,tune,tune/v0_o);
Ja_ne=gamm_pdf2(v0_st,tune,tune/v0_o);
Ja_ol=gamm_pdf2(v0_o,tune,tune/v0_st);
isigma2=1./sigma2_n;
p_al_st=prod(gamm_pdf2(isigma2,v0_st,d0_n)) * exppdf(v0_st,rho0);
p_al_ol=prod(gamm_pdf2(isigma2,v0_o,d0_n)) * exppdf(v0_o,rho0);
r=min( (p_al_st/Ja_ne) / (p_al_ol/Ja_ol),1);
accept=bino_rnd(1,r,1,1);
if accept == 1
    v0_n=v0_st;
    pc=1;
else
    v0_n=v0_o;
    pc=0;
end