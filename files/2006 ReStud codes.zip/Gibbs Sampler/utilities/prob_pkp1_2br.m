function [y,n]=prob_pkp1_2br(result)

%PURPOSE: estimates posterior prbability of regime K+1 from the original
% Gibbs sampling estimates when the model is fully hierarchical (also for
% the transition probability matrix)
% -------------------------------------------------------------------------
% USAGE: [y,n]=prob_pkp1_2br(result)
% -------------------------------------------------------------------------
% written by DP on 17 feb 2004


s=result.s; %load the states from the estimated output
ap=result.ap;
bp=result.bp;
N=rows(s); % # of obs
I=cols(s); % # of Gibbs sampling iterations
M=max(result.s(:,2))-1; %# of break points
% Initialize the output var
y=zeros(I,1);
n=zeros(I,1);
for j=1:I
    n(j)=sum(s(:,j)==M+1);
    % Fill in the p_kp1 at the jth Gibbs sampling interation
    y(j)=beta_rnd(1,ap(j)+n(j),bp(j)+1);
end

