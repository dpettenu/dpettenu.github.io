function d0_n=drawd0(Y,X,bks,sigma2_n,v0_o)

% PURPOSE: computes one Gibbs sampling loop for d0

global hc0 hd0;

J=length(bks)-1;
isigma2=1./sigma2_n;
d0_n=gamm_rnd(1,v0_o*J+hc0,sum(isigma2)+hd0);
% d0_n=1/gamm_rnd(1,v0_o*J+hc0,sum(sigma2_n)+hd0);
