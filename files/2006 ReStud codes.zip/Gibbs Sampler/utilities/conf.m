function out = conf(mat);

% PURPOSE: computes the 95% empirical confidence region.      
% ***************************************************************
% USAGE: out=conf(mat)
% ***************************************************************
% INPUT:
%
% mat: (n x k) matrix containing the coefficient draws  
%
% OUTPUT:
%
% out: (k x 2) matrix containing for each rows the the lower and 
%      upper bound of the 95% confidence interval
% **************************************************************
% Written by : DP on 11/11/2003 after Wang gauss code                         



k = cols(mat); n = rows(mat);  out = [];
low = floor(n*0.025); upp = floor(n*0.975);
i = 1; 
while i <= k;
    tmp = sort(mat(:,i));
    out = [out;tmp(low) tmp(upp)];
    i = i + 1;
end;
