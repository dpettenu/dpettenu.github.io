function sigma2_n=drawsigma2(Y,X,bks,betas_n,v0_o,d0_o)

% PURPOSE: computes one Gibbs sampling loop for the sigma2's

J=length(bks)-1;
nr=cols(X);
isigma2=zeros(J,1);

for j=1:J
    Yi=Y(bks(j):bks(j+1)-1,:);
    Xi=X(bks(j):bks(j+1)-1,:);
    v1=v0_o+(bks(j+1)-bks(j));
    if cols(betas_n) == cols(X)  %constant coeffs case
        d1=( (d0_o*v0_o) + (Yi - Xi*betas_n')'*(Yi - Xi*betas_n') ) ;
    else
        d1=( (d0_o*v0_o) + (Yi - Xi*betas_n(1+(j-1)*nr:j*nr)')'*(Yi - Xi*betas_n(1+(j-1)*nr:j*nr)') ) ;
    end
    isigma2(j)=gamm_rnd(1,v1/2,d1/2);  %used in the hierarchical stage for the variances
    sigma2_n(j)=1/isigma2(j);
end
