% PURPOSE: Run results for table 1

clear all; clc;

% load data
load([pwd,'\Results\yx.mat']);

% No break model
result_0=gibbs_norm(y,X,500);

% Break models: loop over number of breaks
for n_break=1:7
    result=ch_hidmkvch_PT(y,X,n_break,500);
    eval(['result_',num2str(n_break),' = result;']);
    clear('result');
end

% Save results
save([pwd,'\Results\allresult_47-02_l1.mat'],'result_0','result_1','result_2','result_3','result_4','result_5','result_6','result_7');
