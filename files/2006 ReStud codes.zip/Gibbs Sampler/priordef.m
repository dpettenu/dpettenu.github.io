[N,k]=size(X); k=k-1;

% Transition matrix probabilities
% pii distr as a Beta(a,b)
a=0.5; b=0.5;  %non informative priors

% Linear regression model (hierarchical structure)

% Regression parameters
% Uninformative prior for the prior mean distribution 
mub=zeros(k+1,1);
Vb=1000*eye(k+1);         %hyperpars for betas mean vector
% Prior for the prior variance matrix

% The matrix R tunes the variations in the coefficient estimates under the
% diff regimes: when it goes to 0 there is small difference, a value of 1
% already increases the variations. Sensitivity analysis on it.
rho=2; R=1.001*eye(k+1);   %hyperpars for betas variance covariance matrix

%Prior for the error variance distribution (uninformative)
hc0=1; hd0=1/100; rho0=100;

%Prior for the Transition prob matrix (uninformative)
ha0=1; hb0=1/10;
%Tune var for the rejection of the M-H part (high number increases
%acceptance percentage)
tune=4;
tune1=4;
tune2=3;