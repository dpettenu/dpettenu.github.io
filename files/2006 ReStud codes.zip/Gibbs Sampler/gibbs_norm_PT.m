function pr=gibbs_norm_PT(Y,X,I,vnames)

%**************************************************************************
%This function performs the Gibbs sampler for the normal inverted gamma
%conjugate priors case and the PT parametrization (works only for an AR(1)
%process)
%**************************************************************************
% Input:
%
% Y = vector containing the time series (N x 1) of the dependent variable
% X = matrix (n x k) containing the time series of the regressors 
%     (NB: must include the constant in the first
%     column
% I = number of MCMC iterations 
% vnames = string vector (k+1 x 1) containig the names of the dependent and 
%          independent variables (optional)
%**************************************************************************
% Output:
%
% pr = is a structure containing the following fields:
% pr.sigma2 = vector (I-dr) x 1 of sigma2 draws 
% pr.beta = matrix (I-dr) x k of coeffs draws 
%**************************************************************************
% Written by Davide Pettenuzzo
% July 13th, 2003

[n k] = size(X);

% error checking
if nargin == 4
    dflag=1;
elseif nargin == 3
    stry='Y';
    strc='Intercept';
    strx='X_';
    jj=char(ones(k-1,1)*strx);
    vnamesx=[jj num2str((1:k-1)')];
    vnames=strvcat(stry,strc,vnamesx);
end

dr=round((1/5)*I); %drop out first dr obs
%Definition of hyperparameters
% First possibility (Chib 2001)
v0=1;
i=ones(n,1);
M0=eye(n) - inv(i'*i) * i*i';
M=eye(n) - X*invpd(X'*X)*X';
d0=(Y'*M*Y)/(n-k);     %increases the precision on the sigma2 estimates
% d0=Y'*M0*Y;
b0=zeros(k,1);
c=max(k^2,n);
% c=1e+12;
% Either one of the two choices for B0
% B0=c*invpd(X'*X);
B0=c*eye(k);
% Or alternatively (Wang and Zivot 2000): 
% v0=2.001;
% d0=0.001;
% b0=zeros(k,1);
% B0=1000*eye(k);


v1=(v0+n);
% Set initial values for the Gibbs sampling
betas=zeros(I,k);
sigma2=zeros(I,1);
betas(1,:)=randn(1,k);
sigma2(1)=rand(1);
bar=waitbar(0,'Norm-IG conj. post. draw.' );
for i=2:I
    Bn=invpd(invpd(B0) + (1/sigma2(i-1))*(X'*X));
    m=Bn*(invpd(B0)*b0 + (1/sigma2(i-1))*(X'*Y));
    betas(i,:)=mvnrnd(m,Bn,1);
    while betas(i,1) < 0
        betas(i,:)=mvnrnd(m,Bn,1);
    end
    if (betas(i,2)) > 1  %works only for an AR(1) process
        betas(i,1) = 0;
        betas(i,2)=1;
    end
    d1=v0*d0 + (Y - X*betas(i,:)')'*(Y - X*betas(i,:)');
    temp=gamm_rnd(1,v1/2,d1/2);
    sigma2(i)=1/temp;
    waitbar(i/I);
end
close(bar);
%Disp results
%drop first set of obs
betas_c=betas(dr+1:I,:);
sigma2_c=sigma2(dr+1:I);
% betas_m=mean(betas_c);
% betas_std=std(betas_c);
% disp(' ');
% betas_t=betas_m./betas_std;
% info.rnames=strvcat('Variable',vnames(2:end,:));
% info.cnames=strvcat('Mean','Std. error','t-statistic');
% disp('Posterior summary. Linear model, Conjugate Normal- Inverted Gamma priors');
% disp(' ');
% mprint([betas_m' betas_std' betas_t'],info);
% info.rnames=strvcat('Variance','Sigma2');
% sigma2_m=mean(sigma2_c);
% sigma2_std=std(sigma2_c);
% sigma2_t=sigma2_m./sigma2_std;
% disp(' ');
% mprint([sigma2_m sigma2_std sigma2_t],info);
% Function Output
pr.sigma2=sigma2_c;
pr.beta=betas_c;
