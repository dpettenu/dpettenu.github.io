function rho_n=drawrho_PT(Y,X,bks,betas_n,Eta_o)

% PURPOSE: computes one Gibbs sampling loop for b0 for the Jeffrey priors
% of no unit root for the AR(1) case

global mub Vb;

J=length(bks)-1;
nr=cols(X);
tt=(reshape(betas_n,nr,J)); tt=tt';%useful in the next step
tt_l=mlag(tt,1); 
tt=tt(2:end,:); tt_l=tt_l(2:end,:);
for i=1:nr
    sigmabe=invpd((tt_l(:,i)'*invpd(Eta_o(i,i))*tt_l(:,i)) + invpd(Vb(i,i)));
    mube=sigmabe * (invpd(Eta_o(i,i))*(tt_l(:,i)'*tt(:,i)) + invpd(Vb(i,i))*mub(i));
    rho_n(i)=mvnrnd(mube,sigmabe);
    while rho_n(i) < 0 | rho_n(i) > 1  %impose stationarity for the coeffs dynamic
        rho_n(i)=mvnrnd(mube,sigmabe);
    end
end

