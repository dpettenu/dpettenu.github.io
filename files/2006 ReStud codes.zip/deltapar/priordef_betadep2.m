[N,k]=size(X); k=k-1;

% Transition matrix probabilities
% pii distr as a Beta(a,b)
a=0.5; b=0.5;  %non informative priors

% Linear regression model (hierarchical structure)

% Regression parameters
% Uninformative prior for the prior mean distribution 
mub=zeros(2*k+2,1);
Vb=100*eye(2*k+2);         %hyperpars for betas mean vector

eta_v0=.35; eta_d0=1.4;
%Prior for the error variance distribution (uninformative)
hc0=1; hd0=1/100; rho0=100;
%Prior for the Transition prob matrix (uninformative)
ha0=1; hb0=1/10;
%Tune var for the rejection of the M-H part (high number increases
%acceptance percentage)
tune=4;
tune1=4;
tune2=3;