function [mu_n,rho_n]=drawrho2_PT(Y,X,bks,betas_n,Eta_o)

% PURPOSE: computes one Gibbs sampling loop for b0 for the Jeffrey priors
% of no unit root for the AR(1) case

global mub Vb;

J=length(bks)-1;
nr=cols(X);
tt=(reshape(betas_n,nr,J)); tt=tt';%useful in the next step
tt_l=mlag(tt,1); 
tt=tt(2:end,:); tt_l=tt_l(2:end,:);
mu_n=zeros(nr,1); rho_n=zeros(nr,1);
for i=1:nr
    sigmabe=invpd(([ones(J-1,1) tt_l(:,i)]'*invpd(Eta_o(i,i))*[ones(J-1,1) tt_l(:,i)]) + invpd(Vb(1+2*(i-1):2*i,1+2*(i-1):2*i)));
    mube=sigmabe * (invpd(Eta_o(i,i))*([ones(J-1,1) tt_l(:,i)]'*tt(:,i)) + invpd(Vb(1+2*(i-1):2*i,1+2*(i-1):2*i))*mub(1+2*(i-1):2*i));
    temp=mvnrnd(mube,sigmabe);
    mu_n(i)=temp(1); rho_n(i)=temp(2);
    while rho_n(i) < 0 | rho_n(i) > 1  %impose stationarity for the coeffs dynamic
        temp=mvnrnd(mube,sigmabe);
        mu_n(i)=temp(1); rho_n(i)=temp(2);
    end
end

