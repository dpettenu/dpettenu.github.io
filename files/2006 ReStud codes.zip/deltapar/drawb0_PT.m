function b0_n=drawb0_PT(Y,X,bks,betas_n,B0_o)

% PURPOSE: computes one Gibbs sampling loop for b0 for the Jeffrey priors
% of no unit root for the AR(1) case

global mub Vb;

J=length(bks)-1-1;
nr=cols(X);
tt=reshape(betas_n,nr,J); %useful in the next step
sigmabe=invpd(J*invpd(B0_o) + invpd(Vb));
mube=sigmabe * (invpd(B0_o)*sum(tt,2) + invpd(Vb)*mub);
b0_n=mvnrnd(mube,sigmabe);

