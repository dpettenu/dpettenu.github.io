function Eta_n=drawEta2(Y,X,bks,betas_n,mu_n,rho_n)

% PURPOSE: computes one Gibbs sampling loop for B0

global eta_v0 eta_d0;

J=length(bks)-1;
nr=cols(X);
tt=(reshape(betas_n,nr,J))'; 
v1=J-1+eta_v0;
tt_l=mlag(tt,1); 
tt=tt(2:end,:); tt_l=tt_l(2:end,:);
for i=1:nr
    d1=( (eta_v0*eta_d0) + (tt(:,i) - mu_n(i) - tt_l(:,i)*rho_n(i))'*(tt(:,i) - mu_n(i) - tt_l(:,i)*rho_n(i)) ) ;

    temp=gamm_rnd(1,v1/2,d1/2);  
    Eta_n(i,i)=1/temp;
end