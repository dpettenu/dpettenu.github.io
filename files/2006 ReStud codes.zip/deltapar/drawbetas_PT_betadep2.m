function [betas_n,d_betas_n]=drawbetas_PT_betadep2(Y,X,bks,sigma2_o,mu_o,rho_o,Eta_o)

% PURPOSE: computes one Gibbs sampling loop for the betas
%          Jeffrey prior on no unit root for the AR(1) spec.

J=length(bks)-1;
nr=cols(X);

betas_n=zeros(1,nr*J);
%Uninformative priors for the first regime (no difference involved)
b0_1=zeros(nr,1);
B0_1=1000*eye(nr);
for j=1:J
    if j == 1
        Yi=Y(bks(j):bks(j+1)-1,:);
        Xi=X(bks(j):bks(j+1)-1,:);
        Bn=invpd(invpd(B0_1) + (1/sigma2_o(j))*(Xi'*Xi));
        m=Bn*(invpd(B0_1)*b0_1 + (1/sigma2_o(j))*(Xi'*Yi));
        betas_n(1+(j-1)*nr:j*nr)=mvnrnd(m,Bn);
        while betas_n(1+(j-1)*nr) < 0
            betas_n(1+(j-1)*nr:j*nr)=mvnrnd(m,Bn);
        end
        if (betas_n(2+(j-1)*nr)) > 1
            betas_n(1+(j-1)*nr) = 0;
            betas_n(2+(j-1)*nr)=1;
        end
    else
        Yi=Y(bks(j):bks(j+1)-1,:);
        Xi=X(bks(j):bks(j+1)-1,:);
        %Set the new priors to allow for dependence from the previous
        %segment
        b0_o=mu_o' + diag(rho_o) * (betas_n(1+(j-2)*nr:(j-1)*nr))';
        B0_o=Eta_o;
        Bn=invpd(invpd(B0_o) + (1/sigma2_o(j))*(Xi'*Xi));
        m=Bn*(invpd(B0_o)*b0_o + (1/sigma2_o(j))*(Xi'*Yi));
        betas_n(1+(j-1)*nr:j*nr)=mvnrnd(m,Bn);
        while betas_n(1+(j-1)*nr) < 0
            betas_n(1+(j-1)*nr:j*nr)=mvnrnd(m,Bn);
        end
        if (betas_n(2+(j-1)*nr)) > 1
            betas_n(1+(j-1)*nr) = 0;
            betas_n(2+(j-1)*nr)=1;
        end
    end
            
end
