function result=ch_hidmkvch_PT_betadep(y,X,chp)

% PURPOSE: This program uses the hidden markov chain of Chib 1998 to compute the
%         unknown multiple break points for the normal inverted gamma case
%         in the hierarchical setting for the regime parameters (New
%         parametrization according to Pesaran and Timmermann
% INPUT:
% y: dep variable
% X: independent variables
% *************************************************************************
% Written by DP on 2/8/05

global a b mub Vb eta_v0 eta_d0 hc0 hd0 rho0;

[N,k]=size(X); k=k-1;
[M,I]=size(chp);
flag=0;
% --------------------------------------------------
% Prior definition: 
% --------------------------------------------------

priordef_betadep;

% --------------------------------------------------
% Some initilization for the chain 
% --------------------------------------------------

%Parameter vectors under the M+1 regimes
betas=zeros(I,(M+1)*(k+1));
sigma2=zeros(I,M+1);
%Prior hyperparameters (mean and var-covar matrix)
rho=zeros(I,k+1);
Eta=zeros(k+1,k+1,I);
v0=zeros(I,1);
d0=zeros(I,1);
% For the likelihood f at each iteration
llikf=zeros(I,1);

% --------------------------------------------------
% Set initial values for the Gibbs sampling
% --------------------------------------------------

if flag == 1
    % 1) Load star values from previous results as to continue a previous
    % chain (note: in this case set dr to 0, no burn in observation)
    betas(1,:)=result_old.betas(end,:);
    sigma2(1,:)=result_old.sigma2(end,:);
    rho(1,:)=result_old.rho(end,:);
    Eta(:,:,1)=result_old.Eta(:,:,end);
    v0=result_old.v0(end,:);
    d0=result_old.d0(end,:);
    s(:,1)=result_old.s(:,end);
elseif flag ==0
    % 2) External procedure to compute the initial starting values
    [betas(1,:),sigma2(1,:)]=strvls(y,X,M,1);
elseif flag == 2
    % 3) Random initial values
    betas(1,:)=randn(1,(M+1)*(k+1));
    sigma2(1,:)=rand(1,M+1);
end

if flag ~= 1 % only if I am not continuing an old chain
    % Meta distribution hyperparameters
    rho(1,:)=randn(1,k+1);
    Eta(:,:,1)=diag(rand(1,k+1));
    v0(1)=rand; d0(1)=rand;
end

% --------------------------------------------------
%The Gibbs sampling starts here
% --------------------------------------------------

bar=waitbar(0,'Fully Hierarchical Hidden Markov Chain' );
for j=2:I
 
    % 2. Sample regression parameters
    %For each regime draw from the posterior distr of its parameters
    incr=chp(:,j)';
    bks=[1 incr N+1];
%     betas(j,:)=drawbetas_PT(y,X,bks,sigma2(j-1,:),b0(j-1,:),B0(:,:,j-1));
    betas(j,:)=drawbetas_PT_betadep(y,X,bks,sigma2(j-1,:),rho(j-1,:),Eta(:,:,j-1));
    sigma2(j,:)=drawsigma2(y,X,bks,betas(j,:),v0(j-1,:),d0(j-1,:));
    rho(j,:)=drawrho_PT(y,X,bks,betas(j,:),Eta(:,:,j-1));
    Eta(:,:,j)=drawEta(y,X,bks,betas(j,:),rho(j,:));
%     Eta(:,:,j)=[.25 0; 0 .25];
    d0(j,:)=drawd0(y,X,bks,sigma2(j,:),v0(j-1,:));
    [v0(j,:),pc(j)]=drawv0(y,X,sigma2(j,:),d0(j,:),v0(j-1,:),tune1);
    waitbar(j/I);
end %end of gibb sampling loop
close(bar);

% --------------------------------------------------
%Store the MCMC drawing into the structure result 
% --------------------------------------------------

if flag ~= 1
    dr=round(I/5); %trim the first .. percent of draws
else
    dr=0;
end
result.betas=betas(dr+1:end,:);
result.sigma2=sigma2(dr+1:end,:);
result.rho=rho(dr+1:end,:);
result.Eta=Eta(:,:,dr+1:end);
result.v0=v0(dr+1:end,:);
result.d0=d0(dr+1:end,:);
result.llikf=llikf(dr+1:end);