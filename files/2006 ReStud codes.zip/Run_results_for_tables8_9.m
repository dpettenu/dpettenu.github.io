% PURPOSE: Run recursive estimation and forecasts for break point models

clear all; 
addpath(genpath(pwd));

% Load the data
load([pwd,'\Results\yx.mat']);

%some initializations
tb=1;
tbf=ical(1968,12,cstr);
te=ical(2001,12,cstr);
mindist=18;
I=250;
h=[12 24 36 48 60];
rep=10;

YPD_c         = zeros((I*(4/5))*rep,(te-tbf)/12+1,length(h));
YPD_lr        = zeros((I*(4/5))*rep,(te-tbf)/12+1,length(h));
% YPD_rlar      = zeros((I*(4/5))*rep,(te-tbf)/12+1,length(h));
% YPD_rvar      = zeros((I*(4/5))*rep,(te-tbf)/12+1,length(h));
YPD_tvp       = zeros((te-tbf)/12+1,length(h));
YPD_rec       = zeros((te-tbf)/12+1,length(h));
YPD_roll_60m  = zeros((te-tbf)/12+1,length(h));
YPD_roll_120m = zeros((te-tbf)/12+1,length(h));
brmat         = zeros(size(y,1),(te-tbf)/12+1);

i = 1;
for t=tbf:12:te
    disp(' ');
    disp(['Estimating break point for t=' tsdate(cstr,t)]); 
    yr=y(tb:t);
    Xr=X(tb:t,:);
    [YPD_c(:,i,:),YPD_lr(:,i,:),brmat(1:t,i)]=forecast_hmc_rec(yr,Xr,cstr,mindist,I,h,rep);
    i = i+1;
end

%RL-AR model 
% ...

%RV-AR model 
% ...

% TVP model
i = 1;
for h=[12 24 36 48 60]
    [YPD_tvp(:,i),~]=tvp2_recforc(y,X,tb,tbf,12,te,h);
    i = i+1;
end

% Recursive window and Rolling window OLS
i = 1;
for h=[12 24 36 48 60]
    [YPD_rec(:,i),~]=ols_recforc(y,X,tb,tbf,te,h,12);
    [YPD_roll_60m(:,i),~]=ols_rollforc(y,X,tb,tbf,te,60,h,12);
    [YPD_roll_120m(:,i),~]=ols_rollforc(y,X,tb,tbf,te,120,h,12);
    i = i+1;
end

% Saving
save([pwd,'\Results\All forecasts.mat'],'YPD_c','YPD_lr','YPD_tvp','YPD_rec','YPD_roll_60m','YPD_roll_120m'); 
% save([pwd,'\Results\All forecasts.mat'],'YPD_c','YPD_lr','YPD_rlar','YPD_rvar','YPD_tvp','YPD_rec','YPD_roll_60m','YPD_roll_120m'); 
save([pwd,'\Results\Rec break locations.mat'],'brmat'); 
