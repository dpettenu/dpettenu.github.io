% PURPOSE: Print tables 2 and 3, and figure 2

clear all;
% Tables first
% load data and results
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\result_6_l1.mat']);

out_cell = output_hmc(result,cstr);
close all;

% Print tables 2 and 3
out_file = [pwd,'\Results\Figures and tables\Table2.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end

xlswrite(out_file,[{'Regime'},num2cell((1:1:7))],'Table 2','A1');
xlswrite(out_file,{'Constant'},'Table 2','E2');
xlswrite(out_file,out_cell.betas(2:end,:,1),'Table 2','A3');
xlswrite(out_file,{'AR(1) coefficient'},'Table 2','E5');
xlswrite(out_file,out_cell.betas(2:end,:,2),'Table 2','A6');
xlswrite(out_file,{'Variances'},'Table 2','E8');
xlswrite(out_file,out_cell.sigma2(2:end,:),'Table 2','A9');
xlswrite(out_file,{'Transition probability matrix'},'Table 2','E11');
xlswrite(out_file,out_cell.P(2:end,:),'Table 2','A12');

out_file = [pwd,'\Results\Figures and tables\Table3.xlsx'];
if exist(out_file,'file')
    delete(out_file);
end

xlswrite(out_file,out_cell.b0,'Table 3','A1');
xlswrite(out_file,out_cell.B0,'Table 3','A5');
xlswrite(out_file,out_cell.v0d0,'Table 3','A9');

% Figure 2
Plot_chp_rec(result,cstr);
close all;