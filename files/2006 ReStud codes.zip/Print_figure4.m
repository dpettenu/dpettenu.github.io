% PURPOSE: Plot figure 4

% load data and dates from recursively estimated breaks
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\Rec break locations.mat']);

% Restate some of the parameters from the recursive exercise
tbf=ical(1968,12,cstr);
te=ical(2001,12,cstr);

% Prepare ylabels
year_label = kron((1947:1:2002)',ones(12,1));
year_label = year_label(7:end);
yticks_num = (1950:5:2000);
yticks_mat = num2cell(yticks_num);

yticks_locations = NaN(length(yticks_num),1);
for i=1:length(yticks_num)
    yticks_locations(i) = min(find(year_label==yticks_num(i)));
end

% Do the plotting
temp=brmat' .* repmat((1:1:665),34,1);
plot(temp,'b*');
ylim([5 665]);
xlim([0 35]);
set(gca,'XTick',[1:4:35])
set(gca,'XTickLabel',['Dec68';'Dec72';'Dec76';'Dec80';'Dec84';'Dec88';'Dec92';'Dec96';'Dec00'])
set(gca,'YTick',yticks_locations)
set(gca,'YTickLabel',yticks_mat)

set(gca,'XMinorTick','on')
ylabel('Time of break');
xlabel('Forecasting date');
set(gcf,'position',get(0,'screensize'))
set(gcf,'PaperPositionMode','auto')
print('-depsc','-tiff','-r600',[pwd,'\Results\Figures and tables\Figure4.eps']);
pause(5);
close all;
