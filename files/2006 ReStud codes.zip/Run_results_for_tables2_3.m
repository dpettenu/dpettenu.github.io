% PURPOSE: Run results for tables 2,3 and figure 2

clear all; clc;

% load data
load([pwd,'\Results\yx.mat']);

% Break models with 6 breaks, with larger number of iterations
result=ch_hidmkvch(y,X,n_break,2000);

% Save results
save([pwd,'\Results\result_6_l1.mat'],'result');
