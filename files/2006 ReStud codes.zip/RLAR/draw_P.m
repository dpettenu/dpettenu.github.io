function P_n=draw_P(s_n,M,prior)

%PURPOSE: draw the Transition Probability matrix for the Gibbs Sampler of
%the univariate hidden markov chain
% -------------------------------------------------------------------------
% USAGE: P_n=draw_P(s_n,M,prior)
% -------------------------------------------------------------------------
% written by DP on 21 may 2004 

N=size(s_n,1);
k=max(s_n)-1;  %number of outliers
dr=beta_rnd(1,prior.a+k,prior.b+N-k);
for i=1:M
    % Fill in the P matrix at the jth Gibbs sampling interation
    P_n(i,i)=1-dr;
    P_n(i,i+1)=1-P_n(i,i);  %fulfill the row restrictions
end

P_n(M+1,M+1)=1;  %prob of staying in states M+1 once reached equal to 1
