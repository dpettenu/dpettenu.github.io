function result=hidmkvch_norm_cv(y,X,M,I,varargin)

% PURPOSE: This program uses the hidden markov chain of Chib 1998 to compute the
%         unknown multiple break points for the normal inverted gamma case
%         with constant variance across regimes
% *************************************************************************
% USAGE: result=hidmkvch_norm_cv(y,X,M,I,flag,result_old)
% *************************************************************************
% INPUT:
% y: dep variable
% X: independent variables
% prior: prior structure
% M: number of breaks to look for
% I: number of Gibbs samplings
% flag: (optional) = 1 load a previous chain as starting values
%                  = 2 random starting values
%                  = 0 external procedure to generate the starting values 
%                     (default)
% *************************************************************************
% Written by DP on 11/16/03

% Input check
if nargin == 6
    flag=varargin{1};
    result_old=varargin{2};
elseif nargin ==4
    flag=0; %standard value
else
    error('wrong number of input');
end

[N,k]=size(X); k=k-1;

% Some initilization for the chain to run
%States 
pst_ytl=zeros(M+1,N);
pst_yt=zeros(M+1,N);
pst=zeros(M+1,N,I); %prob of the states
s=zeros(N,I);       %observed states
%Parameter vectors under the M+1 regimes  
betas=zeros(I,(M+1)+(k));
sigma2=zeros(I,1);
% Transition probability matrix
P=zeros(M+1,M+1,I);
% For the likelihood f at each iteration
llikf=zeros(I,1);

% Priors:
prior=gen_prior_cv(y,X,M);

% Set initial values for the Gibbs sampling
if flag == 1
    % 1) Load star values from previous results as to continue a previous
    % chain (note: in this case set dr to 0, no burn in observation)
    betas(1,:)=result_old.betas(end,:);
    sigma2(1,:)=result_old.sigma2(end,:);
elseif flag ==0
    % 2) External procedure to compute the initial starting values
    [betas(1,:),sigma2(1,:)]=strvls(y,X,M,4);
elseif flag == 2
    % 3) Random initial values
    betas(1,:)=randn(1,(M+1)+(k));
    sigma2(1,:)=rand(1,1);
end
% P(:,:,1)=rand(M+1,M+1).*eye(M+1,M+1);
P(:,:,1)=0.5.*eye(M+1,M+1);;  %equal prob of staying or moving from each regime
for i=1:M
    P(i,i+1,1)=1-P(i,i,1);
end
P(M+1,M+1,1)=1; %prob of remaining in the last state once reached is 1

%The Gibbs sampling starts here
bar=waitbar(0,'Hidden Markov Chain - Const variance' );
for j=2:I

% 1. Calculate and store for t=1,...,n  p(st|yt,M,theta,P)
ilikf=zeros(N,M+1);   %store the individual likelihood function under all regimes

%Compute p(s1|Y1,theta,P) first

pst_ytl(:,1)=eye(M+1,1); %degenerate prob distr for p(s1|Y0,theta,P)
fyt_ytl=normgen_constdrift(y(1),X(1,:),betas(j-1,:),sigma2(j-1,:),M); 
ilikf(1,:)=fyt_ytl';
num=(pst_ytl(:,1).*fyt_ytl);
den=sumc(num);
pst_yt(:,1)=num./den;

%Now repeat the same step for t=2,...,N
for t=2:N
    pst_ytl(:,t)=P(:,:,j-1)'*pst_yt(:,t-1);
    %compute f(yt|Yt-1,theta_k) for each state k=1,...,M+1
    fyt_ytl=normgen_constdrift(y(t),X(t,:),betas(j-1,:),sigma2(j-1,:),M); 
    ilikf(t,:)=fyt_ytl';
	num=(pst_ytl(:,t).*fyt_ytl);
    den=sumc(num);
    pst_yt(:,t)=num./den;
end

% Here I compute the likelihood function for t=1,..,n at each iteration j

likf=diag(ilikf*pst_ytl);
llikf(j)=sum(log(likf));

% 2. Sample sn from p(sn|y,M,theta,P)
pst(:,N,j)=flipud(eye(M+1,1)); %degenerate at sn=M+1

% 3. Sample for t=n-1,n-2,...,1 st from p(st|y,M,S^t+1,theta,P)

for t=N-1:-1:2
    s(t+1,j)=discrete(pst(:,t+1,j));     % procedure to generate a discrete random variable
    num=pst_yt(:,t) .* P(:,s(t+1,j),j-1);
    pst(:,t,j)=num ./ sum(num);
end
s(t,j)=discrete(pst(:,t,j));

pst(:,1,j)=eye(M+1,1); %degenerate at s1=1
s(1,j)=1;  %at time 1 the state is equal to 1

% 4. Sample for k=1,...,m theta_k prop to prior(theta_k)*L(Y|theta_k)

%For each regime draw from the posterior distr of its parameters
incr=s(:,j)-lag(s(:,j),1);
bks=[find(incr==1)' N+1];
[Xi,iVar] = indBrkL_nt(X,bks); Xi=[Xi X(:,2:end)];
sigma2_o = repmat(sigma2(j-1,:),N,1);  
[betas(j,:),sigma2(j,:)]=normpost(y,Xi,sigma2_o,prior,bks,1);
% 5. Sample for i=1,...,m pi from Dirichlet distr.
P(:,:,j)=draw_P(s(:,j),M,prior);
% 6. Goto 1
waitbar(j/I);
end %end of gibb sampling loop
close(bar);

%Store the MCMC drawing into the structure result 
if flag ~= 1
    dr=I/5; %trim the first .. percent of draws
else
    dr=0;
end
result.betas=betas(dr+1:end,:);
result.sigma2=sigma2(dr+1:end,:);
result.P=P(:,:,dr+1:end);
result.pst=pst(:,:,dr+1:end);
result.s=s(:,dr+1:end);
result.llikf=llikf(dr+1:end);
