function [ei1,iVar] = indBrkL_nt(X,k);

% PURPOSE: generate the indicator matrix for structural break model
% with the breaks in the intercepts being level shifts (no trend)
% ********************************************************************
%  USAGE: [ei,iVar] = indBrkL(X,k)
% ********************************************************************
%  INPUT
% k: 1 x (nofb+2), vector of break points, with k[1] = 1 
% and k[nofb+2] = T+1.
% 
% OUTPUT
% ei1: n x (2nofb+2), indicator matrix for the constant
% iVar: n x (nofb+1), indicator matrix for the error term
% ********************************************************************
%  Written by DP on 11/11/03 after Jeffrey Wang gauss code

k(1) = 1;                    % change k[1] back to 1 if necessary @
nofb = cols(k)-2;
tim = seqa(1,1,k(nofb+2)-1);            % a time index vector        @
   ei1 = zeros(k(nofb+2)-1,nofb+1);     % the indicator for constant @
   ei2 = zeros(k(nofb+2)-1,nofb+1);     % the indicator for time     @
   
i = 2; 
while i <= nofb+2;
      ei1(:,i-1) = (tim < k(i) & tim >= k(i-1));
      i = i + 1;
end

iVar=ei1;
