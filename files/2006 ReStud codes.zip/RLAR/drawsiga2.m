function siga2_n=drawsiga2(chi,X,phi_n,v,lam)

% PURPOSE: draw siga2 for a run of the gibbs sampler for the RLAR model

[n,p]=size(X);

chi=chi(p+2:n); X=X(p+1:n-1,:);
v1=(n-p)+v;
s2=v*lam + ((chi-X*phi_n')'*(chi-X*phi_n') + v*lam);
temp=gamm_rnd(1,v1/2,s2/2);
siga2_n=1/(temp);

