
clear all;

% load data and results
% Load the data
load([pwd,'\Results\yx.mat']);
load([pwd,'\Results\allresult_47-97_l1.mat']);

% Here are the BMA weights, computed from the LL column in table 1,
% exp(LL)/sum(exp(LL))
BMA_prob = [0.0000;0.0000;0.0000;0.0000;0.0000;0.7665;0.2335];


% Produce composite forecasts from all models, going from one to seven
% breaks, as of 1997:12
h=[1 3 12 24 48 60];
rep = 10;
yr=y(1:ical(1997,12,cstr));
Xr=X(1:ical(1997,12,cstr),:);
for m=1:7
    eval(['result = result_',num2str(m),';']);
    [ypd_lr,yfor,s2for]=preddens_br(yr,Xr,result,max(h),rep); % this is the last regime density
    ypd_lonb=preddens_lonb_PT(yr,yfor,s2for,Xr,result,max(h),rep);
    ypd_me=preddens_nb_PT(yr,Xr,result,max(h),rep);
    ypd_c=combine_forc(yr,Xr,result,ypd_lr,ypd_me,ypd_lonb,rep); % this is the composite density
    eval(['ypd_c_',num2str(m),' = ypd_c;']);
    clear('result','ypd_lr','yfor','s2for','ypd_lonb','ypd_me','ypd_c');
end

% Produce BMA forecast combination
% Prepare matrix with "selection" weights, to combine
% together the densities from the individual models
R = mnrnd(1,BMA_prob',size(ypd_c_1,1)); % random draws from multinomial distribution
[rr,cc] = find(R==1);
[~,rr_sorted] = sort(rr);
cc_sorted = cc(rr_sorted);
BMA_R = cc_sorted;

ypd_c_bma = NaN(size(ypd_c_1,1),size(ypd_c_1,2));

for m=1:7
    eval(['ypd_c = ','ypd_c_',num2str(m),';']);
    this_r = find(BMA_R == m);
    for h=1:max(h)
        ypd_c_bma(this_r,h) = ypd_c(this_r,h);
    end
    clear('ypd_c');
end


h=[1 3 12 24 48 60];
for j=1:length(h)
    [x1,y1]=out_pdf(ypd_c_6(:,h(j))); 
    [x2,y2]=out_pdf(ypd_c_bma(:,h(j))); 
    subplot(3,2,j); 
    hold on; plot(x1,y1,'b--','linewidth',2);
    hold on; plot(x2,y2,'k','linewidth',2);
    if j == 1
        xlabel([num2str(h(j)) ' month ahead']);
    else
        xlabel([num2str(h(j)) ' months ahead']);
    end
    if j == 1
        xlim([4 6.5]);
    elseif j == 2
        xlim([3 7]);
    elseif j == 3
        xlim([2 8]);
    elseif j == 4
        xlim([0 10]);
    elseif j == 5
        xlim([-2 12]);
    elseif j == 6
        xlim([-5 15]);
    end
end
set(gcf,'position',get(0,'screensize'))
set(gcf,'PaperPositionMode','auto')
print('-depsc','-tiff','-r600',[pwd,'\Results\Figures and tables\Figure3.eps']);
pause(5);
close all
