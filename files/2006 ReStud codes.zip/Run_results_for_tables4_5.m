% PURPOSE: Run results for tables 4 and 5

clear all; clc;

% load data
load([pwd,'\Results\yx.mat']);

% Break models with 6 breaks, with larger number of iterations
result=ch_hidmkvch_PT(y,X,6,2000);

% Save results
save([pwd,'\Results\result_6_l1_PT.mat'],'result');

[breakdates,chp] = Plot_chp_rec(result,cstr);
save([pwd,'\Results\chp_6breaks_PT.mat'],'chp');
