function [v0_n,pc]=h_drawv0(Y,X,prior,sigma2_n,d0_n,v0_o)

% PURPOSE: computes one Gibbs sampling loop for v0
% *************************************************************************
% USAGE: [v0_n,pc]=h_drawv0(Y,X,prior,sigma2_n,d0_n,v0_o,tune)
% *************************************************************************
% written by DP on 18 june 2004

m=size(Y,2);
rho0=prior.rho0; tune=prior.tune;

for i=1:m
    v0_st=gamm_rnd(1,1,tune,tune/v0_o(i));
    Ja_ne=gamm_pdf2(v0_st,tune,tune/v0_o(i));
    Ja_ol=gamm_pdf2(v0_o(i),tune,tune/v0_st);
    isigma2=(1./sigma2_n(:,i));
    p_al_st=prod(gamm_pdf2(isigma2,v0_st,d0_n(i)))* exppdf(v0_st,rho0);
    p_al_ol=prod(gamm_pdf2(isigma2,v0_o(i),d0_n(i)))* exppdf(v0_o(i),rho0);
    r=min( (p_al_st/Ja_ne) / (p_al_ol/Ja_ol),1);
    accept=bino_rnd(1,r,1,1);
    if accept == 1
        v0_n(i)=v0_st;
        pc(i)=1;
    else
        v0_n(i)=v0_o(i);
        pc(i)=0;
    end
end