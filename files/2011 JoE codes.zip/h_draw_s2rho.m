function sigma2rho_n=h_draw_s2rho(cor_n,prior,mur_n)

% Recover the prior
ar=prior.ar; br=prior.br;
N=length(cor_n);

% Get the grid
s2rhogrid= linspace(0+rand/100,1-rand/100,100)'; 
length(s2rhogrid);
s2pdf=zeros(length(s2rhogrid),1);

for i=1:length(s2rhogrid)
    s2pdf(i)=sum(log(norm_pdf(cor_n,mur_n*ones(N,1),(s2rhogrid(i))*ones(N,1))./(norm_cdf(1,mur_n,s2rhogrid(i))-norm_cdf(0,mur_n,s2rhogrid(i))))) + log(gamm_pdf2(1/s2rhogrid(i),0.5*ar,0.5*br));
end
if ~isempty(find(isinf(s2pdf))==1) || ~isempty(find(isnan(s2pdf))==1)
    s2pdf(isinf(s2pdf)) = -999;
    s2pdf(isnan(s2pdf)) = -999;
end

s2pdf       = exp(s2pdf-max(s2pdf));
s2cdf       = cumsum(s2pdf);
s2cdf       = s2cdf/s2cdf(end);
sigma2rho_n = s2rhogrid(find(s2cdf>rand,1));

