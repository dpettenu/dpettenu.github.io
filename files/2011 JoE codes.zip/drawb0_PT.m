function b0_n=drawb0_PT(Y,X,bks,prior,betas_n,B0_o)

% PURPOSE: computes one Gibbs sampling loop for b0

mub=prior.mub;
Vb=prior.Vb;

J=length(bks)-1;
nr=cols(X); m=cols(Y);
tt=reshape(betas_n,m*nr,J); %useful in the next step
sigmabe=invpd(J*invpd(B0_o) + invpd(Vb));
mube=sigmabe * (invpd(B0_o)*sum(tt,2) + invpd(Vb)*mub);

upb=mean(Y(:,2))+2.5*std(Y(:,2));
lb=0;
b0_n=mvnrnd(mube,sigmabe);
co=vincoli(b0_n,lb,upb);
while co == 1   
    b0_n=mvnrnd(mube,sigmabe);
    co=vincoli(b0_n,lb,upb);
end
        