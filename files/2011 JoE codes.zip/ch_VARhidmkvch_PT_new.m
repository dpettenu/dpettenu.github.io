function result=ch_VARhidmkvch_PT_new(y,X,M,I,dr,thin_fact,model_var,varargin)

% PURPOSE: This program uses the Hierachical VAR hidden markov chain of 
%          Chib 1998 to compute the unknown multiple break points for the
%          PT specification to deal with unit root behaviour
% *************************************************************************
% USAGE: result=ch_VARhidmkvch_PT(y,X,M,I,dr,thin_fact,model_var,varargin)
% *************************************************************************
% INPUT:
% y: dep variable
% X: independent variables
% M: number of breaks to look for
% I: number of draws in the Gibbs sampler
% dr: number of burnin draws
% thin_fact: thinning factor, how much thinning is applied ex-post to the
%            Gibbs sampler chain
% flag: (optional) = 1 load a previous chain as starting values
%                  = 2 random starting values
%                  = 0 external procedure to generate the starting values 
%                     (default)
% *************************************************************************
% Written by DP on 11/16/03

% Input check
if nargin == 11
    flag=varargin{1};
    result_old=varargin{2};
    flag1=varargin{3};
    bks=varargin{4};
elseif nargin == 10
    flag=varargin{1};
    flag1=varargin{2};
    bks=varargin{3};
elseif nargin == 9
    flag=0; %standard value
    flag1=varargin{1};
    bks=varargin{2};
elseif nargin == 8
    flag=varargin{1};
    flag1=0;
elseif nargin == 7
    flag=0; %standard value
    flag1=0;
else
    error('wrong number of input');
end

[N,k]=size(X); k=k-1;
m=cols(y);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Some initilization for the chain to run 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%States 
pst=zeros(M+1,N,I); %prob of the states
s=zeros(N,I);       %observed states

%Parameter vectors under the M+1 regimes
betas=zeros(I,m*(k+1),M+1);
sigma2=zeros(I,m*m,M+1);

%Prior hyperparameters (mean, var-covar matrix and P matrix)
b0=zeros(I,m*(k+1));
B0=zeros(m*(k+1),m*(k+1),I);
v0=zeros(I,m);
d0=zeros(I,m);
murho=zeros(I,m*(m-1)/2);
sigma2rho=zeros(I,m*(m-1)/2);
ap=zeros(I,1);
bp=zeros(I,1);

% Transition probability matrix
P=zeros(M+1,M+1,I);

% For the likelihood f at each iteration
llikf=zeros(I,1);

% For the acceptance ratio in the M-H step inside the Gibbs sampler
pc1=zeros(I,m); pc2=zeros(I,1); pc3=zeros(I,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate the prior here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eval(['prior=ch_gen_prior_' lower(model_var) '(y,X);'])  % this gives the prior structure for the hierarchical HMC (hierachical only for the regression coeffs so far..)

% Lower and upper bounds for importance sampler
upb = mean(y(:,2))+2.5*std(y(:,2));
lb  = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set initial values for the Gibbs sampler
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if flag == 1
    % 1) Load star values from previous results as to continue a previous
    % chain (note: in this case set dr to 0, no burn in observation)
    betas(1,:,:)=result_old.betas(end,:,:);
    sigma2(1,:,:)=result_old.sigma2(end,:,:);
    b0(1,:)=result_old.b0(end,:);
    B0(:,:,1)=result_old.B0(:,:,end);
    v0(1,:)=result_old.v0(end,:);
    d0(1,:)=result_old.d0(end,:);
    murho(1,:)=result_old.murho(end,:);
    sigma2rho(1,:)=result_old.sigmarho(end,:);
    ap(1)=result_old.ap(end,:);
    bp(1)=result_old.bp(end,:);
    P(:,:,1)=result_old.P(:,:,end);
    s(:,1)=result_old.s(:,end);
elseif flag ==0
    % 2) External procedure to compute the initial starting values
    [betas(1,:,:),sigma2(1,:,:)]=strvls(y,X,M,1);
elseif flag == 2
    % 3) Random initial values
    betas(1,:,:)=randn(1,m*(k+1),M+1);
    sigma2(1,:,:)=randn(1,m*m,M+1);
end

if flag ~= 1 % only if I am not continuing an old chain
    % Meta distribution hyperparameters
    b0(1,:)=randn(1,m*(k+1));
    B0(:,:,1)=diag(rand(1,m*(k+1)));
    v0(1,:)=rand(1,m); d0(1,:)=rand(1,m);
    murho(1,:)=0;
    sigma2rho(1,:)=1;
    ap(1)=rand; bp(1)=rand;
    %Transition prob matrix (random initialization given the structure
    %constraints)
    % P(:,:,1)=rand(M+1,M+1).*eye(M+1,M+1);
    P(:,:,1)=0.5.*eye(M+1,M+1);  %equal prob of staying or moving from each regime
    for i=1:M
        P(i,i+1,1)=1-P(i,i,1);
    end
    P(M+1,M+1,1)=1; %prob of remaining in the last state once reached is 1
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Gibbs sampler starts here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
corr_n = repmat(normt_rnd(0,1,-1,1),M+1,1);

for j=2:I
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % 1. Draw the states
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [llikf(j),pst(:,:,j),s(:,j)]=draw_states(y,X,betas(j-1,:,:),sigma2(j-1,:,:),P(:,:,j-1),M);
    incr=s(:,j)-lag(s(:,j),1);
    bks=[find(incr==1)' N+1];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Loop over the regimes to draw betas, sigma2s, and correlation
    for m=1:M+1
        tmp_Y        = y(s(:,j)==m,:);
        tmp_X        = X(s(:,j)==m,:);
        vY           = tmp_Y(:);
        Z            = kron(eye(size(y,2)),tmp_X);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Sample Beta
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Vpost = inv(inv(B0(:,:,j-1))+Z'*(kron(inv(reshape(sigma2(j-1,:,m),2,2)),eye(length(find(s(:,j)==m)))))*Z);
        bpost = Vpost*(inv(B0(:,:,j-1))*b0(j-1,:)' + Z'*(kron(inv(reshape(sigma2(j-1,:,m),2,2)),eye(length(find(s(:,j)==m)))))*vY);
        betas(j,:,m) = bpost + chol(Vpost)'*randn(4,1);
        co=vincoli(betas(j,:,m),lb,upb);
        while co == 1
            betas(j,:,m) = bpost + chol(Vpost)'*randn(4,1);
            co=vincoli(betas(j,:,m),lb,upb);
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Sample Sigma2s with MH to handle correlation between error terms
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        err           = tmp_Y-tmp_X*reshape(betas(j,:,m),2,2);
        
        v1            = v0(j-1,1)+length(find(s(:,j)==m));
        s12           = (err(:,1)'*err(:,1)+v0(j-1,1)*d0(j-1,1))/v1;
        h1_cand       = gamm_rnd(1,1,.5*v1,.5*v1*s12);
        
        k1 = .5/(1-corr_n(m)^2)*err(:,1)'*err(:,1);
        k2 = corr_n(m)/(1-corr_n(m)^2)*err(:,1)'*err(:,2)/sqrt(sigma2(j-1,4,m));
        
        goh2 = @(x) log(gamm_pdf2(x,.5*v0(j-1,1),.5*d0(j-1,1))) + length(find(s(:,j)==m))/2*log(x) -k1*x + k2*sqrt(x);
        alpMH = goh2(h1_cand) - log(gamm_pdf2(h1_cand,.5*v1,.5*v1*s12)) - goh2(1/sigma2(j-1,1,m))...
                + log(gamm_pdf2(1/sigma2(j-1,1,m),.5*v1,.5*v1*s12));
            
        if alpMH > log(rand)
            sigma2(j,1,m)       = 1/h1_cand;
        else
            sigma2(j,1,m)       = sigma2(j-1,1,m);
        end
        
        v1        = v0(j-1,2)+length(find(s(:,j)==m));
        s12       = (err(:,2)'*err(:,2)+v0(j-1,2)*d0(j-1,2))/v1;
        h2_cand   = gamm_rnd(1,1,.5*v1,.5*v1*s12);
        
        k1 = .5/(1-corr_n(m)^2)*err(:,2)'*err(:,2);
        k2 = corr_n(m)/(1-corr_n(m)^2)*err(:,2)'*err(:,1)/sqrt(sigma2(j-1,1,m));
        
        goh2 = @(x) log(gamm_pdf2(x,.5*v0(j-1,2),.5*d0(j-1,2))) + length(find(s(:,j)==m))/2*log(x) -k1*x + k2*sqrt(x);
        alpMH = goh2(h2_cand) - log(gamm_pdf2(h2_cand,.5*v1,.5*v1*s12)) - goh2(1/sigma2(j-1,4,m))...
            + log(gamm_pdf2(1/sigma2(j-1,4,m),.5*v1,.5*v1*s12));
        if alpMH > log(rand)
            sigma2(j,4,m)       = 1/h2_cand;
        else
            sigma2(j,4,m)       = sigma2(j-1,4,m);
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Sample rho, using griddy Gibbs
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        lrhopri    = @(x) -.5*(x-murho(j-1)).^2/sigma2rho(j-1);
        
        tmprho = sqrt(1/sigma2(j,1,m))*err(:,1);
        k1 = tmprho'*tmprho;
        k2 = tmprho'*err(:,2);
        k3 = err(:,2)'*err(:,2);
        grho = @(x) lrhopri(x) -length(find(s(:,j)==m))/2*log(1-x.^2) + ...
            - (k1 - 2*x*sqrt(1/sigma2(j,4,m))*k2 + (1/sigma2(j,4,m))*k3)./(2*(1-x.^2));
        rhogrid = linspace(-1+rand/100,1-rand/100,300)';
        rhopdf  = grho(rhogrid);
        rhopdf  = exp(rhopdf-max(rhopdf));
        rhocdf  = cumsum(rhopdf);
        rhocdf  = rhocdf/rhocdf(end);
        corr_n(m) = rhogrid(find(rhocdf>rand,1));
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    
    % Combine draws of diag(sigma) and rho
    sigma2(j,:,:)=resh_sigma22(sqrt([squeeze(sigma2(j,1,:)),squeeze(sigma2(j,4,:))]),corr_n);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % 3. Sample Transition Probability matrix 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    P(:,:,j)=draw_hP(y,X,M,s(:,j),ap(j-1),bp(j-1));
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Now the prior hyperparameters
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    b0(j,:)=drawb0_PT(y,X,bks,prior,betas(j,:,:),B0(:,:,j-1));
    B0(:,:,j)=drawcb0(y,X,bks,prior,betas(j,:,:),b0(j,:));
    
    d0(j,:)=h_drawd0(y,X,prior,bks,[squeeze(sigma2(j,1,:)),squeeze(sigma2(j,4,:))],v0(j-1,:));
    [v0(j,:),pc1(j,:)]=h_drawv0(y,X,prior,[squeeze(sigma2(j,1,:)),squeeze(sigma2(j,4,:))],d0(j,:),v0(j-1,:));
    
    murho(j)=h_draw_murho(corr_n,prior,sigma2rho(j-1));
    sigma2rho(j)=h_draw_s2rho(corr_n,prior,murho(j));
    
    [ap(j,:),pc2(j)]=drawap(y,X,prior,P(:,:,j),ap(j-1,:),bp(j-1,:));
    [bp(j,:),pc3(j)]=drawbp(y,X,prior,P(:,:,j),ap(j,:),bp(j-1,:));
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if mod(j,100) == 0
        disp(['iter ' num2str(j) '       '  num2str(bks)]);
    end
    
end %end of gibb sampling loop
toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Store the MCMC drawing into the structure result 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

result.betas=betas(dr+1:thin_fact:end,:,:);
result.sigma2=sigma2(dr+1:thin_fact:end,:,:);
result.P=P(:,:,dr+1:thin_fact:end);
result.b0=b0(dr+1:thin_fact:end,:);
result.B0=B0(:,:,dr+1:thin_fact:end);
result.v0=v0(dr+1:thin_fact:end,:);
result.d0=d0(dr+1:thin_fact:end,:);
result.murho=murho(dr+1:thin_fact:end,:);
result.sigma2rho=sigma2rho(dr+1:thin_fact:end,:);
result.ap=ap(dr+1:thin_fact:end,:);
result.bp=bp(dr+1:thin_fact:end,:);
result.pc1=pc1(dr+1:thin_fact:end,:);
result.pc2=pc2(dr+1:thin_fact:end,:);
result.pc3=pc3(dr+1:thin_fact:end,:);
result.pst=pst(:,:,dr+1:thin_fact:end);
result.s=s(:,dr+1:thin_fact:end);
result.llikf=llikf(dr+1:thin_fact:end);