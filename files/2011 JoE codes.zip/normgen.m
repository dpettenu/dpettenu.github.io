function f=normgen(y,X,beta,sigma2,M)

% PURPOSE: this function computes f(y|X,theta_k) for each regime k=1,...,M+1
% *************************************************************************
% USAGE: f=normgen(y,X,beta,sigma2,M)
% *************************************************************************
% 
% INPUT:
% M is the number of break points, thus M+1 is the number of regimes
% y is a (1 x m)is the dependent var obs at time t
% X    is a (1 x k+1) vector containing the data upon which the function evaluates 
%      the conditional density of y (NB: the constant has to be included in the vector)
% beta is a (k+1*m x M+1) vector of parameter under the diff regimes
% sigma2: is a (m*m x M+1) vector of variances 
% OUTPUT:
% f is a (M+1 x 1) vector which contains the evaluation of y under the diff 
%   regimes
% *************************************************************************
% Written by DP on 11 May 04

m=size(y,2); %number of eqs
k=(size(beta,2)/(m))-1; %number of regressor in each state, without the constant

for i=1:M+1
    be=reshape(beta(:,:,i)',k+1,m);
    s2=reshape(sigma2(:,:,i)',m,m);
    f(i)=mvnpdf(y,X*be,s2);
end

f=f';

