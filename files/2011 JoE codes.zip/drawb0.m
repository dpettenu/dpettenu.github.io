function b0_n=drawb0(Y,X,bks,prior,betas_n,B0_o)

% PURPOSE: computes one Gibbs sampling loop for b0

mub=prior.mub;
Vb=prior.Vb;

J=length(bks)-1;
nr=cols(X); m=cols(Y);
tt=reshape(betas_n,m*nr,J); %useful in the next step
sigmabe=invpd(J*invpd(B0_o) + invpd(Vb));
mube=sigmabe * (invpd(B0_o)*sum(tt,2) + invpd(Vb)*mub);
b0_n=mvnrnd(mube,sigmabe);
        