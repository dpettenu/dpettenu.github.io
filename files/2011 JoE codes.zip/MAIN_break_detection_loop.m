function MAIN_break_detection_loop(I,dr,thin_fact,m_st,M,model_var)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USAGE:  MAIN_break_detection_loop(I,m_st,M,model_var)
% where:
% I  = total number of draws, including burn-in (set to 101000)
% dr = total number of burn in draws (set to 1000)
% thin_fact = thinning factor (set to 25)
% m_st = initial number of breaks (set to zero)
% M = max number of breaks
% model_var = either 'YLD' or 'TBI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
addpath(genpath(pwd));

if ~exist([pwd '\Output\',model_var],'dir')
    mkdir([pwd '\Output\',model_var])
end

load([pwd '\Input data\YX_2007_' model_var '.mat']);
[T,N] = size(Y);


%% Run break detection loop
for m=m_st:M
    
    if m_st==0
        results_nobr=bvar_dp_PT(Y,X,I);
        eval(['save(''' pwd '\Output\' model_var '\result_nobr.mat' ''',''' 'results_nobr' ''');']);
    else

        Npar=(7*(1+m)+m) + 22;
        flag_run=0;
        while flag_run == 0
            try
                result_new=ch_VARhidmkvch_PT_new(Y,X,m,I,dr,thin_fact,model_var);
                flag_run = 1;
            catch me
                disp(me);
            end
        end
        findchp2(result_new,cstr);
        SIC_new(m,1)=mean(result_new.llikf)-0.5*Npar*log(T);
        disp(['Mlik = ',sprintf('%5.1f',mean(result_new.llikf))]);
        disp(['SIC = ',sprintf('%5.1f',SIC_new(m,1))]);
        disp(' ');
        
        % Save results
        eval(['result_new_' num2str(m) ' = result_new;']);
        clear result_new;
        eval(['save(''' pwd '\Output\' model_var '\result_new_' num2str(m) ''',''' 'result_new_' num2str(m) ''');']);
    end
end