function [betas,sig2]=strvls(Y,X,M,opt)

% PURPOSE: this function computes the starting values for the VAR Hidden Markov
% chain model in order to have the ols result (coeffs and variances)for the 
% equally splitted subsamples of the original data 
% *************************************************************************
% USAGE: [betas,sig2]=strvls(Y,X,M,opt)
% *************************************************************************
% INPUT:
% Y: (N x m) vector of independent variables
% X: (N x k) matrix of independent variables
% M: number of regimes allowed
% opt: option to allow for different models
%     =1 i.e. all regressor coeffs and variance change
%     =2 i.e. all regressor coeffs change and variance stays const over regimes
%     =3 i.e. only the constant coeff changes and variance changes
%     =4 i.e. only the constant coeff changes and variance stay constant
%             over regimes
%
% OUTPUT:
% betas: (1 x (M+1)*k) vector of starting values for the regression coeffs
% sig2: (1 x (M+1)) vector of starting values for the variaces 
% % **************************************************************************
% Written by DP on 11/16/03

[N,k]=size(X);
m=cols(Y); % # of eqs

if rem(N,(M+1)) > 0
    lb=[0 floor((1:(M)).*(N/(M+1)))] + 1;
    ub=[lb(2:end)-1 N];
elseif rem(N,M+1) == 0
    lb=[0 (1:(M)).*(N/(M+1))] + 1;
    ub=(1:M+1).*(N/(M+1));
end

if opt==1
    betas=zeros(1,k*m,M+1);
    sig2=zeros(1,m*m,M+1);
    for i=1:M+1
        for ii=1:m
            y(ii).eq=Y(lb(i):ub(i),ii);
            x(ii).eq=X(lb(i):ub(i),:);
        end
        res=sur(m,y,x);
        for ii=1:m
            betas(1,1+(ii-1)*(k):ii*(k),i)=res(ii).beta';
        end
        sig2(1,:,i)=vec(res(1).sigma)';
    end
end
    
