function [bp_n,pc]=drawbp(Y,X,prior,P_n,ap_n,bp_o)

% PURPOSE: computes one Gibbs sampling loop for b

tune=prior.tune2;
ha0=prior.ha0;
hb0=prior.hb0;

bp_st=gamm_rnd(1,1,tune,tune/bp_o);
Ja_ne=gamm_pdf2(bp_st,tune,tune/bp_o);
Ja_ol=gamm_pdf2(bp_o,tune,tune/bp_st); 
pii=diag(P_n);
p_al_st=prod(beta_pdf(pii(1:end-1),ap_n,bp_st)) * gamm_pdf2(bp_st,ha0,hb0);
p_al_ol=prod(beta_pdf(pii(1:end-1),ap_n,bp_o)) * gamm_pdf2(bp_o,ha0,hb0);
r=min( (p_al_st/Ja_ne) / (p_al_ol/Ja_ol),1);
accept=bino_rnd(1,r,1,1);
if accept == 1
    bp_n=bp_st;
    pc=1;
else
    bp_n=bp_o;
    pc=0;
end