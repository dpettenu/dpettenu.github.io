function co=vincoli(beta,lb,upb)

%PURPOSE: returns a 0 or 1 depending if the condition is respected or not

co=( beta(4) >= 1 | beta(3)/(1-beta(4)) < 0);

 
