function prior=ch_gen_prior_tbi(y,X)

% PURPOSE: Generate the prior for the VAR Bayesian (HMC) break detection.       
% ***************************************************************
% USAGE: prior=ch_gen_prior_tbi(y,X)
% ***************************************************************
% INPUT:
%
% y: (nobs x noeq) vector for the dependent variable
% X: (nobs x nreg) matrix containing the regressors (including 
%     the constant)
% 
% OUTPUT:
%
% prior: is a structure whose fields are
%   prior.a: a coeff for the beta(a,b) piis distr  
%   prior.b: b coeff for the beta(a,b) piis distr 
%   prior.mub: hierarch prior for the regression coeff mean (mean)
%   prior.Vb: hierach prior for the regression coeff mean (var covar matrix)
%   prior.rho: hierach prior for the regression coeff var (degrees of freedom) 
%   prior.R: hierach prior for the regression coeff var (scale matrix) 
%   prior.v0: prior for the Inverted Gamma degrees of freedom
%   prior.invH0: prior for the Inverted Gamma precision 
% **************************************************************
% Written by : DP on 14 june 2004                             

[T k]=size(X); k=k-1; %adjust to be consistent with the hierarchical part
m=cols(y);

% Prior definition

% Linear regression model

% Linear regression model (hierarchical structure)

% Regression parameters
% Uninformative prior for the prior mean distribution 
vY=vec(y);
Z=kron(eye(m),X);
% prior.mub=inv(Z'*Z)*(Z'*vY);
prior.mub=zeros(m*(k+1),1);
prior.mub(4)=0.9; % Adjusting for strong persistence in predictor variables
prior.Vb=1000*eye(m*(k+1));         %hyperpars for betas mean vector
prior.Vb(4,4)=1;  % Adjusting for strong persistence in predictor variables

% Prior for the prior variance matrix
% The matrix R tunes the variations in the coefficient estimates under the
% diff regimes: when it goes to 0 there is small difference, a value of 1
% already increases the variations. Sensitivity analysis on it.
prior.rho=m*(k+1)+2; 
prior.R=0.1*eye(m*(k+1));   %hyperpars for betas variance covariance matrix
prior.R(2,2)=1000; %custom made to respect the data
prior.R(3,3)=0.000001;
%Prior for the error variance distribution (uninformative)
prior.hc0=1; prior.hd0=eps; prior.rho0=1/eps;

% Prior for the correlation distribution (uninformative)
prior.mum=0; prior.tau2=100;
prior.ar=1; prior.br=1/100;

%Prior for the Transition prob matrix distribution (uninformative)
prior.ha0=1; prior.hb0=1/10;

%Tune var for the rejection of the M-H part (high number increases
%acceptance percentage)
prior.tune=4;
prior.tune1=2;
prior.tune2=2;


