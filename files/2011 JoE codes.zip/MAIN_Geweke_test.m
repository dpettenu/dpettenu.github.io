%% PURPOSE: Perform Geweke's Getting it Right (JASA 2004) MCMC test on PT algorithm for break detection

Geweke_test_VAR_withbreaks;
Geweke_test_hierarchical;