%% PURPOSE: Perform Geweke's Getting it Right (JASA 2004) MCMC test on hierarchical model

addpath(genpath(pwd));
clear all; 

%% Setup parameters
model_var = 'YLD';
I         = 105000;
burnin    = 5000;
thin_fact = 20;
prior.M   = 9;

%% Load data and prepare prior
load([pwd '\Input data\YX_2007_' model_var '.mat']);
[T,N]     = size(Y);
m         = size(Y,2);
k         = size(X,2)-1;

% b0 
prior.mub     = zeros(m*(k+1),1);
prior.mub(4)  = 0.9; % Adjusting for strong persistence in predictor variables
prior.Vb      = 1000*eye(m*(k+1));        
prior.Vb(4,4) = 1;  % Adjusting for strong persistence in predictor variables

% V0
prior.rho     = m*(k+1)+2; 
prior.R       = diag([0.5 5 0.000001 0.1]);  %custom made to respect the data

% d0_i - proper prior with E(d0_i) = 50
prior.hc0 = 5000;
prior.hd0 = 100;

% v0_i - proper prior with E(v0_i) = 100
prior.he0 = 10000;
prior.hf0 = 100;
%prior.rho0 = 100;

% murho - proper prior with E(murho)=0
prior.mum  = 0; 
prior.tau2 = 0.5;

% sigma2rho - proper prior with E(1/sigma2rho) = 2
prior.ar = 200;
prior.br = 100;

% ap and bp - proper priors with E(ap)=E(bp)~=0.90
prior.ha0=100;
prior.hb0=10;

%Tune var for the acceptance rate of the M-H part (high number increases
%acceptance percentage)
prior.tune  = 1000;
prior.tune2 = 10;


%% 1. Marginal-conditional simulator
Bdraw_prior1     = NaN(prior.M+1,I,4);
Sigmadraw_prior1 = NaN(prior.M+1,I,2);
Rhodraw_prior1   = NaN(prior.M+1,I);
Pdraw_prior1     = zeros(prior.M+1,prior.M+1,I);

b0_prior1            = NaN(4,I);
V0_prior1            = NaN(4,4,I);

v0_prior1            = NaN(I,2);
d0_prior1            = NaN(I,2);

murhodraw_prior1     = NaN(I,1);
sigma2rhodraw_prior1 = NaN(I,1);

ap_prior1            = NaN(I,1);
bp_prior1            = NaN(I,1);

disp('Marginal-Conditional Simulator');
for j=1:I
    if mod(j,I/10)==0
        fprintf('%d %% \t',100*(j/I));
    end
    % 1.a Draw from prior
    
    b0_prior1(:,j)   = prior.mub + chol(prior.Vb)'*randn(4,1);
    V0_prior1(:,:,j) = invpd(wish_rnd(invpd(prior.R),prior.rho));
    
    v0_prior1(j,:)   = gamm_rnd(2,1,.5*prior.he0,.5*prior.hf0);
    d0_prior1(j,:)   = gamm_rnd(2,1,.5*prior.hc0,.5*prior.hd0);

    murhodraw_prior1(j)     = normt_rnd(prior.mum,prior.tau2,-1,1);
    
    sigma2rhodraw_prior1(j) = 1/gamm_rnd(1,1,0.5*prior.ar,0.5*prior.br);

    
    ap_prior1(j,1)        = gamm_rnd(1,1,prior.ha0,prior.hb0);
    bp_prior1(j,1)        = gamm_rnd(1,1,prior.ha0,prior.hb0);

    
    % 1.b Draw data
    for r=1:prior.M+1
        Bdraw_prior1(r,j,:)     = mvnrnd(b0_prior1(:,j),V0_prior1(:,:,j));
        
        Sigmadraw_prior1(r,j,1) = 1/gamm_rnd(1,1,0.5*v0_prior1(j,1),0.5*d0_prior1(j,1));
        Sigmadraw_prior1(r,j,2) = 1/gamm_rnd(1,1,0.5*v0_prior1(j,2),0.5*d0_prior1(j,2));
        
        Rhodraw_prior1(r,j)     = normt_rnd(murhodraw_prior1(j),sigma2rhodraw_prior1(j),-1,1);
        
        if r<prior.M+1
            Pdraw_prior1(r,r,j)=beta_rnd(1,ap_prior1(j,1),bp_prior1(j,1));
            while(isnan(Pdraw_prior1(r,r,j)))
                Pdraw_prior1(r,r,j)=beta_rnd(1,ap_prior1(j,1),bp_prior1(j,1));
            end
            Pdraw_prior1(r,r+1,j)=1-Pdraw_prior1(r,r,j);  %fulfill the row restrictions;
        else
            Pdraw_prior1(r,r,j) = 1; %prob of staying in states M+1 once reached equal to 1
        end
    end
end
disp(' ');

%% 2. Successive conditional simulator
Bdraw_prior2     = NaN(prior.M+1,I,4);
Sigmadraw_prior2 = NaN(prior.M+1,I,2);
Rhodraw_prior2   = NaN(prior.M+1,I);
Pdraw_prior2     = zeros(prior.M+1,prior.M+1,I);

b0_prior2            = NaN(4,I);
V0_prior2            = NaN(4,4,I);

v0_prior2            = NaN(I,2);
d0_prior2            = NaN(I,2);

murhodraw_prior2     = NaN(I,1);
sigma2rhodraw_prior2 = NaN(I,1);

ap_prior2            = NaN(I,1);
bp_prior2            = NaN(I,1);

disp('Successive-Conditional Simulator');
for j=1:I
    if mod(j,I/10)==0
        fprintf('%d %% \t',100*(j/I));
    end
    
    if j==1
        % 2.a(0) Draw from prior
        
        b0_prior2(:,j)   = prior.mub + chol(prior.Vb)'*randn(4,1);
        V0_prior2(:,:,j) = invpd(wish_rnd(invpd(prior.R),prior.rho));
        
        v0_prior2(j,:)   = gamm_rnd(2,1,.5*prior.he0,.5*prior.hf0);
        d0_prior2(j,:)   = gamm_rnd(2,1,.5*prior.hc0,.5*prior.hd0);
        
        murhodraw_prior2(j)     = normt_rnd(prior.mum,prior.tau2,-1,1);
        sigma2rhodraw_prior2(j) = 1/gamm_rnd(1,1,0.5*prior.ar,0.5*prior.br);
        
        ap_prior2(j,1)        = gamm_rnd(1,1,prior.ha0,prior.hb0);
        bp_prior2(j,1)        = gamm_rnd(1,1,prior.ha0,prior.hb0);
        
    else
        tmp_be = squeeze(Bdraw_prior1(:,j,:))';
        % 2.a(0) Draw parameters from posterior kernel
        b0_prior2(:,j) = drawb0(NaN(prior.M+2,2),NaN(prior.M+2,2),NaN(prior.M+2,1),prior,tmp_be,V0_prior2(:,:,j-1));
        V0_prior2(:,:,j) = drawcb0(NaN(prior.M+2,2),NaN(prior.M+2,2),NaN(prior.M+2,1),prior,tmp_be,b0_prior2(:,j)');
        
        [v0_prior2(j,:),pc(j,:)] = h_drawv0_Geweke_test(NaN(prior.M+2,2),NaN(prior.M+2,2),prior,[Sigmadraw_prior2(:,j-1,1),Sigmadraw_prior2(:,j-1,2)],d0_prior2(j-1,:),v0_prior2(j-1,:));
        d0_prior2(j,:)           = h_drawd0(NaN(prior.M+2,2),NaN(prior.M+2,2),prior,NaN(prior.M+2,1),[Sigmadraw_prior2(:,j-1,1),Sigmadraw_prior2(:,j-1,2)],v0_prior2(j,:));
        
        murhodraw_prior2(j)     = h_draw_murho(Rhodraw_prior2(:,j-1),prior,sigma2rhodraw_prior2(j-1));
        sigma2rhodraw_prior2(j) = h_draw_s2rho(Rhodraw_prior2(:,j-1),prior,murhodraw_prior2(j));
        
        [ap_prior2(j,1),pc2(j,1)]=drawap(NaN(prior.M+2,2),NaN(prior.M+2,2),prior,Pdraw_prior2(:,:,j-1),ap_prior2(j-1,:),bp_prior2(j-1,:));
        [bp_prior2(j,1),pc2(j,2)]=drawbp(NaN(prior.M+2,2),NaN(prior.M+2,2),prior,Pdraw_prior2(:,:,j-1),ap_prior2(j-1,:),bp_prior2(j-1,:));
        
        
    end
    
    % 2.b Draw data
    for r=1:prior.M+1
        Bdraw_prior2(r,j,:) = mvnrnd(b0_prior2(:,j),V0_prior2(:,:,j));
        
        Sigmadraw_prior2(r,j,1) = 1/gamm_rnd(1,1,0.5*v0_prior2(j,1),0.5*d0_prior2(j,1));
        Sigmadraw_prior2(r,j,2) = 1/gamm_rnd(1,1,0.5*v0_prior2(j,2),0.5*d0_prior2(j,2));
        
        Rhodraw_prior2(r,j)     = normt_rnd( murhodraw_prior2(j),sigma2rhodraw_prior2(j),-1,1);
        
        if r<prior.M+1
            Pdraw_prior2(r,r,j)=beta_rnd(1,ap_prior2(j,1),bp_prior2(j,1));
            while(isnan(Pdraw_prior2(r,r,j)))
                Pdraw_prior2(r,r,j)=beta_rnd(1,ap_prior2(j,1),bp_prior2(j,1));
            end
            Pdraw_prior2(r,r+1,j)=1-Pdraw_prior2(r,r,j);  %fulfill the row restrictions;
            if isnan(Pdraw_prior2(r,r,j))
                keyboard
            end
        else
            Pdraw_prior2(r,r,j) = 1; %prob of staying in states M+1 once reached equal to 1
        end
    end
     
end
disp(' ');


%% Testing
clear test sd p
col_headers = [{'b0(1)'},{'b0(2)'},{'b0(3)'},{'b0(4)'},{'V0(1,1)'},{'V0(2,2)'},{'V0(3,3)'},{'V0(4,4)'},{'a_p'},{'b_p'},{'mu_rho'},{'sigma2_rho'},...
               {'v0(1)'},{'v0(2)'},{'d0(1)'},{'d0(2)'}];

Mat_prior1 = [b0_prior1(1,burnin+1:thin_fact:end)',b0_prior1(2,burnin+1:thin_fact:end)',b0_prior1(3,burnin+1:thin_fact:end)',...
    b0_prior1(4,burnin+1:thin_fact:end)',squeeze(V0_prior1(1,1,burnin+1:thin_fact:end)),squeeze(V0_prior1(2,2,burnin+1:thin_fact:end)),...
    squeeze(V0_prior1(3,3,burnin+1:thin_fact:end)),squeeze(V0_prior1(4,4,burnin+1:thin_fact:end)),ap_prior1(burnin+1:thin_fact:end,1),...
    bp_prior1(burnin+1:thin_fact:end,1),murhodraw_prior1(burnin+1:thin_fact:end),sigma2rhodraw_prior1(burnin+1:thin_fact:end),...
    v0_prior1(burnin+1:thin_fact:end,1),v0_prior1(burnin+1:thin_fact:end,2),d0_prior1(burnin+1:thin_fact:end,1),d0_prior1(burnin+1:thin_fact:end,2)];

Mat_prior2 = [b0_prior2(1,burnin+1:thin_fact:end)',b0_prior2(2,burnin+1:thin_fact:end)',b0_prior2(3,burnin+1:thin_fact:end)',...
    b0_prior2(4,burnin+1:thin_fact:end)',squeeze(V0_prior2(1,1,burnin+1:thin_fact:end)),squeeze(V0_prior2(2,2,burnin+1:thin_fact:end)),...
    squeeze(V0_prior2(3,3,burnin+1:thin_fact:end)),squeeze(V0_prior2(4,4,burnin+1:thin_fact:end)),ap_prior2(burnin+1:thin_fact:end,1),...
    bp_prior2(burnin+1:thin_fact:end,1),murhodraw_prior2(burnin+1:thin_fact:end),sigma2rhodraw_prior2(burnin+1:thin_fact:end),...
    v0_prior2(burnin+1:thin_fact:end,1),v0_prior2(burnin+1:thin_fact:end,2),d0_prior2(burnin+1:thin_fact:end,1),d0_prior2(burnin+1:thin_fact:end,2)];

% Run the test
for j=1:2*size(Mat_prior1,2)
    if j <= size(Mat_prior1,2)
        [h(j,1),p(j,1),ci(j,:),stats]=ttest2(Mat_prior1(:,j),Mat_prior2(:,j),'vartype','unequal');
    else
        [h(j,1),p(j,1),ci(j,:),stats]=ttest2(Mat_prior1(:,j-size(Mat_prior1,2)).^2,Mat_prior2(:,j-size(Mat_prior1,2)).^2,'vartype','unequal');
    end
    test(j,1) = stats.tstat;
    sd(j,:) = stats.sd;
end

% Print test output
out_test = [{'Parameter'},{'Abs(test stat)'},{'Abs(test stat) > 2.32'},{'Pvalue'}];

out_test = [out_test;[[col_headers';cellstr([char(col_headers),repmat(' squared',length(col_headers),1)])],num2cell([abs(test),abs(test)>2.32,p])]];
disp(out_test);
disp(' ');
disp(' ');
disp('**********************************************************************************************************');
disp(['Max test stat: ',num2str(max(abs(test))),' -- Bonferroni 10% critical value = ',num2str(abs(norminv(0.1/(2*size(test,1))))),' -- Bonferroni 5% critical value = ',num2str(abs(norminv(0.05/(2*size(test,1))))),' -- Bonferroni 1% critical value = ',num2str(abs(norminv(0.01/(2*size(test,1)))))])
disp('**********************************************************************************************************');

xlswrite([pwd '\Output\Geweke test.xls'],out_test,'Hyperparmeters');

%% Save output
save([pwd '\Output\Results_Geweke_hier_VAR_',model_var,'.mat'],'Y','X','prior','I','burnin','thin_fact','*_prior1','*_prior2');


