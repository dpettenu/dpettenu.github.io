function sigma2=resh_sigma22(sigma_n,corr_n)

% PURPOSE: put togheter std_err's and corr's for all the regime and return
% a row vector for each regime in line with the output of the gibb sampling
% -------------------------------------------------------------------------
% USAGE: sigma2=resh_sigma22(sigma_n,corr_n)
% -------------------------------------------------------------------------
%NOTE: so far works only for a 2 x 2 sigma matrix
%written by DP on 25 june 2004

[J m]=size(sigma_n);
if J==1
    sigma2=vec(diag(sigma_n) * [1 corr_n; corr_n 1] *  diag(sigma_n))';
else
    sigma2=zeros(1,m*m,J);
    for i=1:J
        sigma2(1,:,i)=vec(diag(sigma_n(i,:)) * [1 corr_n(i); corr_n(i) 1] *  diag(sigma_n(i,:)))';
    end
end