function f = gamm_pdf2 (x,a,b)

% PURPOSE: returns the pdf at x of the gamma(a,b) distribution
%---------------------------------------------------
% USAGE: pdf = gamm_pdf(x,a,b)
% where: x = a vector  
%        a = a scalar for gamma(a)
%        b = a scalar for exp(-b*x)
%---------------------------------------------------
% RETURNS:
%        a vector of pdf at each element of x of the gamma(a,b) distribution      
% --------------------------------------------------
% SEE ALSO: gamm_cdf, gamm_rnd, gamm_inv
%---------------------------------------------------

%       Anders Holtsberg, 18-11-93
%       Copyright (c) Anders Holtsberg

if nargin ~= 3
error('Wrong # of arguments to gamm_cdf');
end;

if any(any(a<=0))
   error('gamm_pdf: parameter a is wrong')
end

lf = a*log(b) - gammaln(a) + (a-1) * log(x) - b*x;
f=exp(lf);
I0 = find(x<0);
f(I0) = zeros(size(I0));