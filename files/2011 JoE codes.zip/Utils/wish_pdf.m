function pdf = wish_pdf(x, S, v)
% PURPOSE: pdf of the Wishart(S,v) distribution evaluated at x
%defined as in Gelmand, Carlin, Stern and Rubin (2001) page 574
%---------------------------------------------------------------------
% USAGE: pdf = wish_pdf(x, S, v)
% --------------------------------------------------------------------
% written by DP on 14 feb 2004

k=rows(S);
p1=1./ ( (2^((v*k)/2)) .* (pi^(k*(k-1)/4)) .* prod(gamma((v+1-(1:k)')/2)) );
p2=((det(S))^(-v/2)) * ((det(x))^((v-k-1)/2));
p3=exp(-.5*trace(inv(S)*x));

pdf=p1*p2*p3;