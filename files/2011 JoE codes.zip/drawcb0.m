function B0_n=drawcb0(Y,X,bks,prior,betas_n,b0_n)

% PURPOSE: computes one Gibbs sampling loop for B0

rho=prior.rho;
R=prior.R;

J=length(bks)-1;
nr=cols(X); m=cols(Y);
vbar_be=J+rho;
tt=reshape(betas_n,m*nr,J); 
tt_m=zeros(m*nr,m*nr);

for i=1:J
    tt_m=tt_m+((tt(:,i)-b0_n')*(tt(:,i)-b0_n')');
end
% tt_m=tt-repmat(b0_n',1,J); %coeff in deviation from their mean
Vbar_be=tt_m + R;
B0_n=invpd(wish_rnd(invpd(Vbar_be),vbar_be));
