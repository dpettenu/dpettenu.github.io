These codes reproduce the main results in Pettenuzzo, D., Timmermann, A. (2011) Predictability of Stock Returns and Asset Allocation under Structural Breaks, Journal of Econometrics, 164: 60-78. 

This code comes without technical support of any kind. It is expected to reproduce the main results reported in Table 2 of the paper. Under no circumstances should the authors be held responsible for any use (or misuse) of this code.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To produce the output necessary to replicate Table 2, run 

MAIN_break_detection_loop(101000,1000,25,0,10,'YLD');
MAIN_break_detection_loop(101000,1000,25,0,8,'TBI');

Next, run
Print_model_comparison_table('YLD',10,0);
Print_model_comparison_table('TBI',8,0);

This will generate an Excel file version of Table 2 (model comparison and selection of the number of breaks).

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Run 

MAIN_Geweke_test 

to perform the Geweke (JASA 2004) ``Getting it right'' test on both model parameters and hyperparameters of the meta distributions.

