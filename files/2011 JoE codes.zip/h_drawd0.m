function d0_n=h_drawd0(Y,X,prior,bks,sigma2_n,v0_o)

% PURPOSE: computes one Gibbs sampling loop for d0
% *************************************************************************
% USAGE: d0_n=h_drawd0(Y,X,prior,bks,sigma2_n,v0_o)
% *************************************************************************
% written by DP on 18 june 2004

m=size(Y,2);
hc0=prior.hc0; hd0=prior.hd0;

J=length(bks)-1;
for i=1:m
    isigma2=(1./sigma2_n(:,i));
    d0_n(i) = gamm_rnd(1,1,.5*(v0_o(i)*J+hc0),.5*(sum(isigma2)+hd0));
end
