function Print_model_comparison_table(mod_var,M,dr)
% Prepare model selection and comparison table

load([pwd '\Input data\YX_2007_' mod_var '.mat']);
N=size(Y,1);

out = cell(M+2,M+4);
out(1,1) = {'Number of breaks'};
out(1,2) = {'Joint log likelihood'};
out(1,3) = {'SIC'};
out(1,4) = {'Post. probability'};
out(1,5) = {'Break locations'};

out(2:end,1) = num2cell((0:1:M)');

load([pwd '\Output\' upper(mod_var) '\result_nobr'])

results_nobr.beta = results_nobr.beta(dr+1:end,:);
results_nobr.Sigma = results_nobr.Sigma(:,:,dr+1:end);

% Zero breaks first
llikf = mlik_alleq_nb(Y,X,results_nobr);
out(2,2) = num2cell(llikf);
% # of parameters=betas(1+m)*4+sigma2(1+m)*3
Npar=7;
SIC=llikf-0.5*Npar*log(N);
out(2,3) = num2cell(SIC);

for m=1:M
    eval(['load(''' pwd '\Output\' upper(mod_var) '\result_new_' num2str(m) ''');']);
    eval(['result_new_' num2str(m) '.llikf=result_new_' num2str(m) '.llikf(' num2str(dr) '+1:end);']);
    eval(['llik = mean(result_new_' num2str(m) '.llikf);']);
    out(m+2,2) = num2cell(llik);
    % # of parameters=betas(1+m)*4+sigma2(1+m)*3+transition matrix =
    % 7*(m+1)+m
    % m+hyperparameters: b0 4+V0 10+ v0,d0 4 + mu_rho, sigma_rho 2 + a,b
    % 2 = 22
    Npar=(7*(1+m)+m) + 22;
    SIC=llik-0.5*Npar*log(N);
    out(m+2,3) = num2cell(SIC);
    eval(['result_' num2str(m) '.s=result_new_' num2str(m) '.s(:,' num2str(dr) '+1:end);']);
    eval(['[tmp2,list_br] = findchp2(result_new_' num2str(m) ',cstr);']);
    out(m+2,5:5+size(list_br,1)-1) = list_br';
    
end

tmp = cell2mat(out(2:end,3));
tmp = exp(tmp-max(tmp));
tmp = tmp/sum(tmp);
out(2:end,4) = num2cell(tmp);

% Print results
xlswrite([pwd '\Output\Table_model_comparison.xls'],out,upper(mod_var));
    

