%% PURPOSE: Perform Geweke's Getting it Right (JASA 2004) MCMC test on PT algorithm for break detection

addpath(genpath(pwd));
clear all; 

%% Setup parameters
model_var = 'YLD';
I         = 105000;
burnin    = 5000;
thin_fact = 20;
T_sim     = 10;


%% Load data
load([pwd '\Input data\YX_2007_' model_var '.mat']);
[T,N]     = size(Y);

%% Prior
prior.M       = 1;
prior.b    = [0,0,0,0.9]';
prior.V    = diag([0.1,0.1,0.1,0.0001]);
prior.s02  = 0.01;
prior.v0   = 1;
prior.rho0 = 0; 
prior.Vrho = 1;
prior.ap   = 5;
prior.bp   = 10;
lrhopri    = @(x) -.5*(x-prior.rho0).^2/prior.Vrho;

if ~exist([pwd '\Output\'],'dir')
    mkdir([pwd '\Output\'])
end

%% 1. Marginal-conditional simulator
Y_draw_prior1     = NaN(T_sim,I,2);
Bdraw_prior1      = NaN(2,2,I,prior.M+1);
h_prior1          = NaN(2,I,prior.M+1);
rho_prior1        = NaN(I,prior.M+1);
Sigmadraw_prior1  = NaN(2,2,I,prior.M+1);
Pdraw_prior1      = zeros(prior.M+1,prior.M+1,I);

disp('Marginal-Conditional Simulator');
for j=1:I
    if mod(j,I/10)==0
        fprintf('%d %% \t',100*(j/I));
    end
    % 1.a Draw from prior
    
    for m=1:prior.M
        Pdraw_prior1(m,m,j)=beta_rnd(1,prior.ap,prior.bp);
        Pdraw_prior1(m,m+1,j)=1-Pdraw_prior1(m,m,j);  %fulfill the row restrictions;
    end
    Pdraw_prior1(prior.M+1,prior.M+1,j) = 1; %prob of staying in states M+1 once reached equal to 1
    
    sdraw = NaN(T_sim,1);
    sdraw(1,1) = 1;
    for t=2:T_sim-1
        this_m = eye(prior.M+1,sdraw(t-1,1));
        sdraw(t,1) = discrete(Pdraw_prior1(:,:,j)'*this_m(:,end)); 
    end
    sdraw(T_sim,1) = prior.M+1;
    
    for m=1:prior.M+1
        Bdraw_prior1(:,:,j,m) = reshape(prior.b+chol(prior.V)'*randn(length(prior.b),1),2,2);
        
        h_prior1(1,j,m) = gamm_rnd(1,1,.5*prior.v0,.5*prior.s02);
        h_prior1(2,j,m) = gamm_rnd(1,1,.5*prior.v0,.5*prior.s02);
        rho_prior1(j,m) = normt_rnd(prior.rho0,prior.Vrho,-1,1);
        %rho_prior1(j) = 0;
        Sigmadraw_prior1(:,:,j,m) = diag(1./sqrt(h_prior1(:,j,m)))*[1,rho_prior1(j,m);rho_prior1(j,m),1]*diag(1./sqrt(h_prior1(:,j,m)));
    end
    
    % 1.b Draw data
    for t=1:T_sim
        if t==1
            Y_draw_prior1(t,j,:) = mvnrnd(Bdraw_prior1(:,:,j,1)'*[1,mean(Y(:,2))]',Sigmadraw_prior1(:,:,j,1));
        else
            Y_draw_prior1(t,j,:) = mvnrnd(Bdraw_prior1(:,:,j,sdraw(t))'*[1,Y_draw_prior1(t-1,j,2)]',Sigmadraw_prior1(:,:,j,sdraw(t)));
        end
    end
end

%% 2. Successive conditional simulator
Y_draw_prior2     = NaN(T_sim,I,2);
Bdraw_prior2      = NaN(2,2,I,prior.M+1);
h_prior2          = NaN(2,I,prior.M+1);
rho_prior2        = NaN(I,prior.M+1);
Sigmadraw_prior2  = NaN(2,2,I,prior.M+1);
Pdraw_prior2      = zeros(prior.M+1,prior.M+1,I);

nuS       = prior.v0*prior.s02;
invV      = prior.V\eye(4);
disp(' ');
disp('Successive-Conditional Simulator');
for j=1:I
    if mod(j,I/10)==0
        fprintf('%d %% \t',100*(j/I));
    end
    
    if j==1
        % 2.a(0) Draw from prior
        
        for m=1:prior.M
            Pdraw_prior2(m,m,j)=beta_rnd(1,prior.ap,prior.bp);
            Pdraw_prior2(m,m+1,j)=1-Pdraw_prior2(m,m,j);  %fulfill the row restrictions;
        end
        Pdraw_prior2(prior.M+1,prior.M+1,j) = 1; %prob of staying in states M+1 once reached equal to 1
        
        sdraw = NaN(T_sim,1);
        sdraw(1,1) = 1;
        for t=2:T_sim-1
            this_m = eye(prior.M+1,sdraw(t-1,1));
            sdraw(t,1) = discrete(Pdraw_prior2(:,:,j)'*this_m(:,end));
        end
        sdraw(T_sim,1) = prior.M+1;
        
        for m=1:prior.M+1
            Bdraw_prior2(:,:,j,m) = reshape(prior.b+chol(prior.V)'*randn(length(prior.b),1),2,2);
            
            h_prior2(1,j,m) = gamm_rnd(1,1,.5*prior.v0,.5*prior.s02);
            h_prior2(2,j,m) = gamm_rnd(1,1,.5*prior.v0,.5*prior.s02);
            rho_prior2(j,m) = normt_rnd(prior.rho0,prior.Vrho,-1,1);
            %rho_prior1(j) = 0;
            Sigmadraw_prior2(:,:,j,m) = diag(1./sqrt(h_prior2(:,j,m)))*[1,rho_prior2(j,m);rho_prior2(j,m),1]*diag(1./sqrt(h_prior2(:,j,m)));
        end
    else
        
        % 2.a(0) Draw parameters from posterior kernel
        tmp_Y = squeeze(Y_draw_prior2(:,j-1,:));
        tmp_X = [ones(T_sim,1),[mean(Y(:,2));tmp_Y(1:end-1,2)]];
        tmp_be = NaN(1,4,prior.M+1);
        tmp_Si = NaN(1,4,prior.M+1);
        for m=1:prior.M+1
            tmp_be(1,:,m) = reshape(Bdraw_prior2(:,:,j-1,m),4,1);
            tmp_Si(1,:,m) = reshape(Sigmadraw_prior2(:,:,j-1,m),4,1);
        end
        [llikf(j),pst(:,:,j),sdraw]=draw_states(tmp_Y,tmp_X,tmp_be,tmp_Si,Pdraw_prior2(:,:,j-1),prior.M);
        
        for m=1:prior.M+1
            vY        = tmp_Y(sdraw==m,:);
            Z         = tmp_X(sdraw==m,:);
            vY        = vY(:);
            Z         = kron(eye(N),Z);
            
            
            % Sample Beta
            Vpost = inv(invV+Z'*(kron(inv(Sigmadraw_prior2(:,:,j-1,m)),eye(length(find(sdraw==m)))))*Z);
            bpost = Vpost*(invV*prior.b + Z'*(kron(inv(Sigmadraw_prior2(:,:,j-1,m)),eye(length(find(sdraw==m)))))*vY);
            Bdraw_prior2(:,:,j,m) = reshape(bpost + chol(Vpost)'*randn(4,1),2,2);
            
            % Sample Sigma2s, using M-H algorithm
            err           = tmp_Y(sdraw==m,:)-tmp_X(sdraw==m,:)*Bdraw_prior2(:,:,j,m);
            
            v1            = prior.v0+length(find(sdraw==m));
            s12           = (err(:,1)'*err(:,1)+nuS)/v1;
            h1_cand       = gamm_rnd(1,1,.5*v1,.5*v1*s12);
            
            k1 = .5/(1-rho_prior2(j-1,m)^2)*err(:,1)'*err(:,1);
            k2 = rho_prior2(j-1,m)/(1-rho_prior2(j-1,m)^2)*err(:,1)'*err(:,2)/sqrt(Sigmadraw_prior2(2,2,j-1,m));
            
            goh2 = @(x) log(gamm_pdf2(x,.5*prior.v0,.5*prior.s02)) + length(find(sdraw==m))/2*log(x) - k1*x + k2*sqrt(x);
            alpMH = goh2(h1_cand) - log(gamm_pdf2(h1_cand,.5*v1,.5*v1*s12)) - goh2(1/Sigmadraw_prior2(1,1,j-1,m)) ... 
                + log(gamm_pdf2(1/Sigmadraw_prior2(1,1,j-1,m),.5*v1,.5*v1*s12));
            if alpMH > log(rand)
                h_prior2(1,j,m)       = h1_cand;
            else
                h_prior2(1,j,m)       = h_prior2(1,j-1,m);
            end
            
            s12       = (err(:,2)'*err(:,2)+nuS)/v1;
            h2_cand   = gamm_rnd(1,1,.5*v1,.5*v1*s12);
            
            k1 = .5/(1-rho_prior2(j-1,m)^2)*err(:,2)'*err(:,2);
            k2 = rho_prior2(j-1,m)/(1-rho_prior2(j-1,m)^2)*err(:,2)'*err(:,1)/sqrt(Sigmadraw_prior2(1,1,j-1,m));
            
            goh2 = @(x) log(gamm_pdf2(x,.5*prior.v0,.5*prior.s02)) + length(find(sdraw==m))/2*log(x) -k1*x + k2*sqrt(x);
            alpMH = goh2(h2_cand) - log(gamm_pdf2(h2_cand,.5*v1,.5*v1*s12)) - goh2(1/Sigmadraw_prior2(2,2,j-1,m))... 
                + log(gamm_pdf2(1/Sigmadraw_prior2(2,2,j-1,m),.5*v1,.5*v1*s12));
            if alpMH > log(rand)
                h_prior2(2,j,m)       = h2_cand;
            else
                h_prior2(2,j,m)       = h_prior2(2,j-1,m);
            end
            
            % Sample rho - griddy Gibbs
            tmprho = sqrt(h_prior2(1,j,m))*err(:,1);
            k1 = tmprho'*tmprho;
            k2 = tmprho'*err(:,2);
            k3 = err(:,2)'*err(:,2);
            grho = @(x) lrhopri(x) -length(find(sdraw==m))/2*log(1-x.^2) + ...
                - (k1 - 2*x*sqrt(h_prior2(2,j,m))*k2 + h_prior2(2,j,m)*k3)./(2*(1-x.^2));
            rhogrid = linspace(-1+rand/100,1-rand/100,300)';
            rhopdf  = grho(rhogrid);
            rhopdf  = exp(rhopdf-max(rhopdf));
            rhocdf  = cumsum(rhopdf);
            rhocdf  = rhocdf/rhocdf(end);
            rho_prior2(j,m) = rhogrid(find(rhocdf>rand,1));
            %rho_prior2(j) = 0;
            
            Sigmadraw_prior2(:,:,j,m) = diag(1./sqrt(h_prior2(:,j,m)))*[1,rho_prior2(j,m);rho_prior2(j,m),1]*diag(1./sqrt(h_prior2(:,j,m)));
        
        end
        
        Pdraw_prior2(:,:,j)=draw_hP(tmp_Y,tmp_X,prior.M,sdraw,prior.ap,prior.bp);
        
    end
    
    % 2.b Draw data
    for t=1:T_sim
        if t==1
            Y_draw_prior2(t,j,:) = mvnrnd(Bdraw_prior2(:,:,j,1)'*[1,mean(Y(:,2))]',Sigmadraw_prior2(:,:,j,1));
        else
            Y_draw_prior2(t,j,:) = mvnrnd(Bdraw_prior2(:,:,j,sdraw(t))'*[1,Y_draw_prior2(t-1,j,2)]',Sigmadraw_prior2(:,:,j,sdraw(t)));
        end
    end
     
    
    
end
disp(' ');

%% Testing
clear test sd p 
col_headers = [{'\mu_{1,r}'},{'\mu_{2,r}'},{'\beta_{1,r}'},{'\beta_{2,r}'},...
    {'\mu_{1,x}'},{'\mu_{2,x}'},{'\beta_{1,x}'},{'\beta_{2,x}'},{'\sigma_{1,r}^{-2}'},...
    {'\sigma_{2,r}^{-2}'},{'\sigma_{1,x}^{-2}'},{'\sigma_{2,x}^{-2}'},{'\lambda_1'},{'\lambda_2'},{'p_{1,1}'},];

Mat_prior1 = [squeeze(Bdraw_prior1(1,1,burnin+1:thin_fact:end,1)),squeeze(Bdraw_prior1(1,1,burnin+1:thin_fact:end,2)),...
    squeeze(Bdraw_prior1(2,1,burnin+1:thin_fact:end,1)),squeeze(Bdraw_prior1(2,1,burnin+1:thin_fact:end,2)),squeeze(Bdraw_prior1(1,2,burnin+1:thin_fact:end,1)),...
    squeeze(Bdraw_prior1(1,2,burnin+1:thin_fact:end,2)),squeeze(Bdraw_prior1(2,2,burnin+1:thin_fact:end,1)),squeeze(Bdraw_prior1(2,2,burnin+1:thin_fact:end,2)),...
    sqrt(h_prior1(1,burnin+1:thin_fact:end,1))',sqrt(h_prior1(1,burnin+1:thin_fact:end,2))',sqrt(h_prior1(2,burnin+1:thin_fact:end,1))',...
    sqrt(h_prior1(2,burnin+1:thin_fact:end,2))',rho_prior1(burnin+1:thin_fact:end,1),rho_prior1(burnin+1:thin_fact:end,2),squeeze(Pdraw_prior1(1,1,burnin+1:thin_fact:end))];

Mat_prior2 = [squeeze(Bdraw_prior2(1,1,burnin+1:thin_fact:end,1)),squeeze(Bdraw_prior2(1,1,burnin+1:thin_fact:end,2)),...
    squeeze(Bdraw_prior2(2,1,burnin+1:thin_fact:end,1)),squeeze(Bdraw_prior2(2,1,burnin+1:thin_fact:end,2)),squeeze(Bdraw_prior2(1,2,burnin+1:thin_fact:end,1)),...
    squeeze(Bdraw_prior2(1,2,burnin+1:thin_fact:end,2)),squeeze(Bdraw_prior2(2,2,burnin+1:thin_fact:end,1)),squeeze(Bdraw_prior2(2,2,burnin+1:thin_fact:end,2)),...
    sqrt(h_prior2(1,burnin+1:thin_fact:end,1))',sqrt(h_prior2(1,burnin+1:thin_fact:end,2))',sqrt(h_prior2(2,burnin+1:thin_fact:end,1))',...
    sqrt(h_prior2(2,burnin+1:thin_fact:end,2))',rho_prior2(burnin+1:thin_fact:end,1),rho_prior2(burnin+1:thin_fact:end,2),squeeze(Pdraw_prior2(1,1,burnin+1:thin_fact:end))];

% Run the test
for j=1:2*size(Mat_prior1,2)
    if j <= size(Mat_prior1,2)
        [h(j,1),p(j,1),ci(j,:),stats]=ttest2(Mat_prior1(:,j),Mat_prior2(:,j),'vartype','unequal');
    else
        [h(j,1),p(j,1),ci(j,:),stats]=ttest2(Mat_prior1(:,j-size(Mat_prior1,2)).^2,Mat_prior2(:,j-size(Mat_prior1,2)).^2,'vartype','unequal');
    end
    test(j,1) = stats.tstat;
    sd(j,:) = stats.sd;
end

% Print test output
out_test = [{'Parameter'},{'Abs(test stat)'},{'Abs(test stat) > 2.32'},{'Pvalue'}];

out_test = [out_test;[[col_headers';cellstr([char(col_headers),repmat(' ^2',length(col_headers),1)])],num2cell([abs(test),abs(test)>2.32,p])]];
disp(out_test);
disp(' ');
disp(' ');
disp('**********************************************************************************************************');
disp(['Max test stat: ',num2str(max(abs(test))),' -- Bonferroni 10% critical value = ',num2str(abs(norminv(0.1/(2*size(test,1))))),' -- Bonferroni 5% critical value = ',num2str(abs(norminv(0.05/(2*size(test,1))))),' -- Bonferroni 1% critical value = ',num2str(abs(norminv(0.01/(2*size(test,1)))))])
disp('**********************************************************************************************************');
xlswrite([pwd '\Output\Geweke test.xls'],out_test,'Parmeters');

%% Save output
save([pwd '\Output\Results_Geweke_VAR_',model_var,'.mat'],'Y','X','prior','I','burnin','thin_fact','T_sim','*_prior1','*_prior2')