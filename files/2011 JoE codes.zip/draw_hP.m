function P=draw_hP(y,X,M,s,ap_o, bp_o)

% PURPOSE: computes one step of the Gibbs sampling for the transition prob
% matrix in the hierarchical setting


[N,k]=size(X); k=k-1;
P=zeros(M+1,M+1);
%Compute the number of one-step transitions from state i to state i in
%the sequence s
clear nii;
for i=1:M
    nii(i)=sum(s==i)-1; % -1 since the first one is not a transition from regime i to i
    % Fill in the P matrix at the jth Gibbs sampling interation
    P(i,i)=beta_rnd(1,ap_o+nii(i),bp_o+1);
    P(i,i+1)=1-P(i,i);  %fulfill the row restrictions
end
P(M+1,M+1)=1;  %prob of staying in states M+1 once reached equal to 1
