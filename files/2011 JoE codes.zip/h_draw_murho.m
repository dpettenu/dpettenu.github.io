function murho_n=h_draw_murho(cor_n,prior,sigma2rho_o)

% Recover the prior
mum=prior.mum; tau2=prior.tau2;
N=length(cor_n);

% Get the grid
murhogrid= linspace(-1+rand/100,1-rand/100,100)'; 
length(murhogrid);
mupdf=zeros(length(murhogrid),1);

for i=1:length(murhogrid)
    mupdf(i)=sum(log(norm_pdf(cor_n,murhogrid(i)*ones(N,1),sigma2rho_o*ones(N,1))./(norm_cdf(1,murhogrid(i),sigma2rho_o)-norm_cdf(-1,murhogrid(i),sigma2rho_o)))) ...
             + log(norm_pdf(murhogrid(i),mum,tau2));
    
end

mupdf       = exp(mupdf-max(mupdf));
mucdf       = cumsum(mupdf);
mucdf       = mucdf/mucdf(end);

murho_n = murhogrid(find(mucdf>rand,1));